-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-03-2019 a las 09:11:54
-- Versión del servidor: 10.1.28-MariaDB
-- Versión de PHP: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `doggy_center_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `days_`
--

CREATE TABLE `days_` (
  `id_day` int(11) NOT NULL,
  `id_lender` int(11) NOT NULL,
  `id_weekdays` int(11) NOT NULL,
  `day_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `days_`
--

INSERT INTO `days_` (`id_day`, `id_lender`, `id_weekdays`, `day_status`) VALUES
(11, 5, 1, 2),
(12, 5, 2, 2),
(13, 5, 3, 2),
(14, 5, 4, 2),
(15, 5, 5, 2),
(16, 5, 6, 2),
(17, 6, 1, 2),
(18, 6, 3, 2),
(19, 6, 5, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `home_service`
--

CREATE TABLE `home_service` (
  `id_homeservice` int(11) NOT NULL,
  `id_veterinario` int(11) NOT NULL,
  `nombre_servicio` text COLLATE utf8_spanish_ci NOT NULL,
  `precio` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `hora_servicio` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `home_service`
--

INSERT INTO `home_service` (`id_homeservice`, `id_veterinario`, `nombre_servicio`, `precio`, `hora_servicio`) VALUES
(1, 1, 'Consulta', '20.000', '7:00 am - 6:00 pm'),
(4, 1, 'Atencion de partos', '20.000', '7:00 am - 6:00 pm'),
(5, 1, ' Ecografia', '20.000', '7:00 am - 6:00 pm');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hours`
--

CREATE TABLE `hours` (
  `id_hour` int(11) NOT NULL,
  `range_time` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `hours`
--

INSERT INTO `hours` (`id_hour`, `range_time`) VALUES
(1, '6:00 AM - 7:00 AM'),
(2, '7:00 AM - 8:00 AM'),
(3, '8:00 AM - 9:00 AM'),
(4, '9:00 AM - 10:00 AM'),
(5, '10:00 AM - 11:00 AM'),
(6, '11:00 AM - 12:00 AM'),
(7, '12:00 AM - 1:00 AM'),
(8, '1:00 PM - 2:00 PM'),
(9, '2:00 PM - 3:00 PM'),
(10, '3:00 PM - 4:00 PM'),
(11, '4:00 PM - 5:00 PM'),
(12, '5:00 PM - 6:00 PM');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lenders`
--

CREATE TABLE `lenders` (
  `id_lender` int(11) NOT NULL,
  `code_lender` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `name_lender` text COLLATE utf8_spanish_ci NOT NULL,
  `sexo` text COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `city_lender` text COLLATE utf8_spanish_ci NOT NULL,
  `neit_lender` text COLLATE utf8_spanish_ci NOT NULL,
  `phone_` bigint(12) NOT NULL,
  `picture` text COLLATE utf8_spanish_ci NOT NULL,
  `status` text COLLATE utf8_spanish_ci NOT NULL,
  `Cuidador` int(11) NOT NULL,
  `Paseador` int(11) NOT NULL,
  `Grooming` int(11) NOT NULL,
  `type_user` int(11) NOT NULL,
  `state_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `lenders`
--

INSERT INTO `lenders` (`id_lender`, `code_lender`, `name_lender`, `sexo`, `email`, `password`, `city_lender`, `neit_lender`, `phone_`, `picture`, `status`, `Cuidador`, `Paseador`, `Grooming`, `type_user`, `state_user`) VALUES
(3, '90909090', 'Oscar Prestador', 'Hombre', 'oscarp@gmail.com', '123456', 'Cali', 'Ciudad Jardin', 30303030, 'img/user.png', 'no active', 1, 0, 0, 2, 1),
(4, '1659045', 'Oscar Paseador', 'Hombre', 'oscar24@gmail.com', '123456', 'Cali', 'Santa teresita', 3147674969, 'img/user.png', 'no active', 0, 2, 0, 2, 1),
(5, '33424323', 'Oscar Ciudador 40', 'Hombre', 'bio1pas01@yahoo.com', '123456', 'Cali', 'Ciudad Jardin', 353535, 'img/user.png', 'no active', 1, 0, 0, 2, 1),
(6, '989898', 'Jhon Mendez', 'Hombre', 'jhondember0424@gmail.com', '123456', 'Cali', 'Santa Teresita', 70707070, 'img/user.png', 'no active', 1, 0, 0, 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medical_history`
--

CREATE TABLE `medical_history` (
  `id` int(11) NOT NULL,
  `id_pet` int(11) NOT NULL,
  `id_vet` int(11) NOT NULL,
  `name_v` text COLLATE utf8_spanish_ci NOT NULL,
  `sex_v` text COLLATE utf8_spanish_ci NOT NULL,
  `telefono_v` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `city_v` text COLLATE utf8_spanish_ci NOT NULL,
  `direccion_v` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `email_v` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `whatsapp` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `Serivicio_salud` varchar(4) COLLATE utf8_spanish_ci NOT NULL,
  `Certificado_vacunacion` varchar(4) COLLATE utf8_spanish_ci NOT NULL,
  `Hemograma` varchar(4) COLLATE utf8_spanish_ci NOT NULL,
  `Hemoparasitos` varchar(4) COLLATE utf8_spanish_ci NOT NULL,
  `control_v` varchar(4) COLLATE utf8_spanish_ci NOT NULL,
  `en_consultorio` text COLLATE utf8_spanish_ci NOT NULL,
  `domiciliaria` text COLLATE utf8_spanish_ci NOT NULL,
  `Consulta_de_ingreso` varchar(4) COLLATE utf8_spanish_ci NOT NULL,
  `plan_mantenimiento` varchar(4) COLLATE utf8_spanish_ci NOT NULL,
  `Afilicación_EPS` varchar(4) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `months`
--

CREATE TABLE `months` (
  `id_months` int(11) NOT NULL,
  `name_months` text COLLATE utf8_spanish_ci NOT NULL,
  `abbreviation_month` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `months`
--

INSERT INTO `months` (`id_months`, `name_months`, `abbreviation_month`) VALUES
(1, 'ENERO', 'EO'),
(2, 'FEBRERO', 'FO'),
(3, 'MARZO', 'MO'),
(4, 'ABRIL', 'AL'),
(5, 'MAYO', 'MO'),
(6, 'JUNIO', 'JNO'),
(7, 'JULIO', 'JLO'),
(8, 'AGOSTO', 'AGO'),
(9, 'SEPTIEMBRE', 'SBRE'),
(10, 'OCTUBRE', 'OBRE'),
(11, 'NOVIEMBRE', 'NVO'),
(12, 'DICIEMBRE', 'DBRE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `offices_veterinarians`
--

CREATE TABLE `offices_veterinarians` (
  `id_office` int(11) NOT NULL,
  `id_vet` int(11) NOT NULL,
  `address` text COLLATE utf8_spanish_ci NOT NULL,
  `service_hours` text COLLATE utf8_spanish_ci NOT NULL,
  `emergencies` char(1) COLLATE utf8_spanish_ci NOT NULL,
  `home_consultations` char(1) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` bigint(13) NOT NULL,
  `email` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `ciudad` text COLLATE utf8_spanish_ci NOT NULL,
  `neit` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `owners`
--

CREATE TABLE `owners` (
  `id_owner` int(11) NOT NULL,
  `name_owner` text COLLATE utf8_spanish_ci NOT NULL,
  `sexo` text COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `city_owner` text COLLATE utf8_spanish_ci NOT NULL,
  `neit_owner` text COLLATE utf8_spanish_ci NOT NULL,
  `phone_` bigint(12) NOT NULL,
  `picture` text COLLATE utf8_spanish_ci NOT NULL,
  `status` text COLLATE utf8_spanish_ci NOT NULL,
  `type_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `owners`
--

INSERT INTO `owners` (`id_owner`, `name_owner`, `sexo`, `email`, `password`, `city_owner`, `neit_owner`, `phone_`, `picture`, `status`, `type_user`) VALUES
(8, 'Jhon Murillos', 'Hombre', 'codelinesw@gmail.com', '24decadames', 'Cali', 'El diamante', 315, 'img/user.png', 'no active', 2),
(9, 'Jhon Mendez', 'Hombre', 'jhondember242015@gmail.com', '123456', '', '', 315, '', 'no active', 2),
(10, 'Oscar Barberena', 'Hombre', 'biotermicos@gmail.com', 'patimendo', '', '', 315, '', 'no active', 2),
(11, 'Oscar Propietario', 'Hombre', 'bio1pro@yahoo.com', 'patimendo', 'Cali', 'Santa Teresita', 3155750320, '', 'no active', 2),
(12, '', 'Hombre', 'jhondember242015@gmail.com', '24decadames', 'no se', 'no se', 0, '', 'no active', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pets`
--

CREATE TABLE `pets` (
  `id_pet` int(11) NOT NULL,
  `name_pet` text COLLATE utf8_spanish_ci NOT NULL,
  `date_nacimiento` text COLLATE utf8_spanish_ci NOT NULL,
  `color` text COLLATE utf8_spanish_ci NOT NULL,
  `picture` text COLLATE utf8_spanish_ci NOT NULL,
  `id_owner` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `pets`
--

INSERT INTO `pets` (`id_pet`, `name_pet`, `date_nacimiento`, `color`, `picture`, `id_owner`) VALUES
(1, 'Rikudo senins', '2016-02-06', 'Purpura', 'img/dog_service.png', 10),
(2, 'Carlos Hugosadsdsdsds', '2016-02-06', 'Verde', 'img/dog_service.png', 8),
(7, 'Rikudo senins', '2016-02-06', 'Purpura', 'img/dog_service.png', 8),
(8, 'Motato Sanchez', '2016-02-06', 'Purpura', 'img/dog_service.png', 8),
(9, 'Firulais', '2019-01-31', 'Rosado', 'img/dog_service.png', 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id_rol` int(11) NOT NULL,
  `name_rol` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id_rol`, `name_rol`) VALUES
(1, 'Cuidador'),
(2, 'Paseador'),
(3, 'Grooming'),
(4, 'Ninguno');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `schedule_users`
--

CREATE TABLE `schedule_users` (
  `id_schedule` int(11) NOT NULL,
  `id_days` int(11) NOT NULL,
  `id_months` int(11) NOT NULL,
  `id_hour` int(11) NOT NULL,
  `date_create` text COLLATE utf8_spanish_ci NOT NULL,
  `available` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `schedule_users`
--

INSERT INTO `schedule_users` (`id_schedule`, `id_days`, `id_months`, `id_hour`, `date_create`, `available`) VALUES
(85, 11, 1, 1, '18/01/2019 15:59:32', 'y'),
(86, 11, 1, 2, '18/01/2019 15:59:32', 'y'),
(87, 11, 1, 3, '18/01/2019 15:59:32', 'y'),
(88, 11, 1, 4, '18/01/2019 15:59:32', 'y'),
(89, 11, 1, 5, '18/01/2019 15:59:32', 'y'),
(90, 11, 1, 6, '18/01/2019 15:59:32', 'y'),
(91, 11, 1, 7, '18/01/2019 15:59:32', 'y'),
(92, 11, 1, 8, '18/01/2019 15:59:32', 'y'),
(93, 11, 1, 9, '18/01/2019 15:59:32', 'y'),
(94, 11, 1, 10, '18/01/2019 15:59:32', 'y'),
(95, 11, 1, 11, '18/01/2019 15:59:32', 'y'),
(96, 11, 1, 12, '18/01/2019 15:59:32', 'y'),
(97, 12, 1, 1, '18/01/2019 15:59:37', 'y'),
(98, 12, 1, 2, '18/01/2019 15:59:37', 'y'),
(99, 12, 1, 3, '18/01/2019 15:59:37', 'y'),
(100, 12, 1, 4, '18/01/2019 15:59:37', 'y'),
(101, 12, 1, 5, '18/01/2019 15:59:37', 'y'),
(102, 12, 1, 6, '18/01/2019 15:59:37', 'y'),
(103, 12, 1, 7, '18/01/2019 15:59:37', 'y'),
(104, 12, 1, 8, '18/01/2019 15:59:37', 'y'),
(105, 12, 1, 9, '18/01/2019 15:59:37', 'y'),
(106, 12, 1, 10, '18/01/2019 15:59:37', 'y'),
(107, 12, 1, 11, '18/01/2019 15:59:37', 'y'),
(108, 12, 1, 12, '18/01/2019 15:59:37', 'y'),
(109, 13, 1, 1, '18/01/2019 15:59:41', 'y'),
(110, 13, 1, 2, '18/01/2019 15:59:41', 'y'),
(111, 13, 1, 3, '18/01/2019 15:59:41', 'y'),
(112, 13, 1, 4, '18/01/2019 15:59:41', 'y'),
(113, 13, 1, 5, '18/01/2019 15:59:41', 'y'),
(114, 13, 1, 6, '18/01/2019 15:59:41', 'y'),
(115, 13, 1, 7, '18/01/2019 15:59:41', 'y'),
(116, 13, 1, 8, '18/01/2019 15:59:41', 'y'),
(117, 13, 1, 9, '18/01/2019 15:59:41', 'y'),
(118, 13, 1, 10, '18/01/2019 15:59:41', 'y'),
(119, 13, 1, 11, '18/01/2019 15:59:41', 'y'),
(120, 13, 1, 12, '18/01/2019 15:59:41', 'y'),
(121, 14, 1, 1, '18/01/2019 15:59:45', 'y'),
(122, 14, 1, 2, '18/01/2019 15:59:45', 'y'),
(123, 14, 1, 3, '18/01/2019 15:59:45', 'y'),
(124, 14, 1, 4, '18/01/2019 15:59:45', 'y'),
(125, 14, 1, 5, '18/01/2019 15:59:45', 'y'),
(126, 14, 1, 6, '18/01/2019 15:59:45', 'y'),
(127, 14, 1, 7, '18/01/2019 15:59:45', 'y'),
(128, 14, 1, 8, '18/01/2019 15:59:45', 'y'),
(129, 14, 1, 9, '18/01/2019 15:59:45', 'y'),
(130, 14, 1, 10, '18/01/2019 15:59:45', 'y'),
(131, 14, 1, 11, '18/01/2019 15:59:45', 'y'),
(132, 14, 1, 12, '18/01/2019 15:59:45', 'y'),
(133, 15, 1, 1, '18/01/2019 15:59:49', 'y'),
(134, 15, 1, 2, '18/01/2019 15:59:49', 'y'),
(135, 15, 1, 3, '18/01/2019 15:59:49', 'y'),
(136, 15, 1, 4, '18/01/2019 15:59:49', 'y'),
(137, 15, 1, 5, '18/01/2019 15:59:49', 'y'),
(138, 15, 1, 6, '18/01/2019 15:59:49', 'y'),
(139, 15, 1, 7, '18/01/2019 15:59:49', 'y'),
(140, 15, 1, 8, '18/01/2019 15:59:49', 'y'),
(141, 15, 1, 9, '18/01/2019 15:59:49', 'y'),
(142, 15, 1, 10, '18/01/2019 15:59:49', 'y'),
(143, 15, 1, 11, '18/01/2019 15:59:49', 'y'),
(144, 15, 1, 12, '18/01/2019 15:59:49', 'y'),
(145, 16, 1, 1, '18/01/2019 15:59:52', 'y'),
(146, 16, 1, 2, '18/01/2019 15:59:52', 'y'),
(147, 16, 1, 3, '18/01/2019 15:59:52', 'y'),
(148, 16, 1, 4, '18/01/2019 15:59:52', 'y'),
(149, 16, 1, 5, '18/01/2019 15:59:52', 'y'),
(150, 16, 1, 6, '18/01/2019 15:59:52', 'y'),
(151, 16, 1, 7, '18/01/2019 15:59:52', 'y'),
(152, 16, 1, 8, '18/01/2019 15:59:52', 'y'),
(153, 16, 1, 9, '18/01/2019 15:59:52', 'y'),
(154, 16, 1, 10, '18/01/2019 15:59:52', 'y'),
(155, 16, 1, 11, '18/01/2019 15:59:52', 'y'),
(156, 16, 1, 12, '18/01/2019 15:59:52', 'y'),
(157, 17, 1, 1, '31/01/2019 10:17:20', 'y'),
(158, 17, 1, 2, '31/01/2019 10:17:20', 'y'),
(159, 17, 1, 3, '31/01/2019 10:17:20', 'y'),
(160, 17, 1, 4, '31/01/2019 10:17:20', 'y'),
(161, 17, 1, 5, '31/01/2019 10:17:20', 'y'),
(162, 17, 1, 6, '31/01/2019 10:17:20', 'y'),
(163, 17, 1, 7, '31/01/2019 10:17:20', 'y'),
(164, 17, 1, 8, '31/01/2019 10:17:20', 'y'),
(165, 17, 1, 9, '31/01/2019 10:17:20', 'y'),
(166, 17, 1, 10, '31/01/2019 10:17:20', 'y'),
(167, 17, 1, 11, '31/01/2019 10:17:20', 'y'),
(168, 17, 1, 12, '31/01/2019 10:17:20', 'y'),
(169, 18, 1, 1, '31/01/2019 10:17:28', 'y'),
(170, 18, 1, 2, '31/01/2019 10:17:28', 'y'),
(171, 18, 1, 3, '31/01/2019 10:17:28', 'y'),
(172, 18, 1, 4, '31/01/2019 10:17:28', 'y'),
(173, 18, 1, 5, '31/01/2019 10:17:28', 'y'),
(174, 18, 1, 6, '31/01/2019 10:17:28', 'y'),
(175, 18, 1, 7, '31/01/2019 10:17:28', 'y'),
(176, 18, 1, 8, '31/01/2019 10:17:28', 'y'),
(177, 18, 1, 9, '31/01/2019 10:17:28', 'y'),
(178, 18, 1, 10, '31/01/2019 10:17:28', 'y'),
(179, 18, 1, 11, '31/01/2019 10:17:28', 'y'),
(180, 18, 1, 12, '31/01/2019 10:17:28', 'y'),
(181, 19, 1, 1, '31/01/2019 10:17:33', 'y'),
(182, 19, 1, 2, '31/01/2019 10:17:33', 'y'),
(183, 19, 1, 3, '31/01/2019 10:17:33', 'y'),
(184, 19, 1, 4, '31/01/2019 10:17:33', 'y'),
(185, 19, 1, 5, '31/01/2019 10:17:33', 'y'),
(186, 19, 1, 6, '31/01/2019 10:17:33', 'y'),
(187, 19, 1, 7, '31/01/2019 10:17:33', 'y'),
(188, 19, 1, 8, '31/01/2019 10:17:33', 'y'),
(189, 19, 1, 9, '31/01/2019 10:17:33', 'y'),
(190, 19, 1, 10, '31/01/2019 10:17:33', 'y'),
(191, 19, 1, 11, '31/01/2019 10:17:33', 'y'),
(192, 19, 1, 12, '31/01/2019 10:17:33', 'y');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `service_consultorio`
--

CREATE TABLE `service_consultorio` (
  `id_sconsultorio` int(11) NOT NULL,
  `id_veterinario` int(11) NOT NULL,
  `nombre_servicio` text COLLATE utf8_spanish_ci NOT NULL,
  `precio` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `hora_servicio` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `service_consultorio`
--

INSERT INTO `service_consultorio` (`id_sconsultorio`, `id_veterinario`, `nombre_servicio`, `precio`, `hora_servicio`) VALUES
(1, 1, 'Consulta', '20.000', '7:00 am - 6:00 pm'),
(3, 1, 'Cirugias', '20.000', '7:00 am - 6:00 pm'),
(5, 1, 'Hospitalizacion', '20.000', '7:00 am - 6:00 pm'),
(6, 1, 'Odontologia. Profilaxis dental', '20.000', '7:00 am - 6:00 pm');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `service_schedule`
--

CREATE TABLE `service_schedule` (
  `id_service` int(11) NOT NULL,
  `id_pet` int(11) NOT NULL,
  `day_service` text COLLATE utf8_spanish_ci NOT NULL,
  `id_schedule_user` int(11) NOT NULL,
  `id_service_` int(11) NOT NULL,
  `date_create` text COLLATE utf8_spanish_ci NOT NULL,
  `date_end` text COLLATE utf8_spanish_ci NOT NULL,
  `date_update` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tabla_eventos`
--

CREATE TABLE `tabla_eventos` (
  `id_evento` int(11) NOT NULL,
  `titulo` text COLLATE utf8_spanish_ci NOT NULL,
  `date_start` text COLLATE utf8_spanish_ci NOT NULL,
  `date_end` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tabla_eventos`
--

INSERT INTO `tabla_eventos` (`id_evento`, `titulo`, `date_start`, `date_end`) VALUES
(1, 'Cita con obito', '2019-02-27T13:13:55.008', '2019-03-01T13:13:55.008'),
(2, 'Cita con gromming', '2019-03-02T13:13:55.008', '2019-03-04T13:13:55.008');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `type_user`
--

CREATE TABLE `type_user` (
  `id_type_user` int(11) NOT NULL,
  `name_type` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `type_user`
--

INSERT INTO `type_user` (`id_type_user`, `name_type`) VALUES
(1, 'Admin'),
(2, 'Users');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `name_user` text COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `status` text COLLATE utf8_spanish_ci NOT NULL,
  `picture` text COLLATE utf8_spanish_ci NOT NULL,
  `type_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id_user`, `name_user`, `email`, `password`, `status`, `picture`, `type_user`) VALUES
(1, 'Admin', 'admin@gmail.com', 'admin123', 'no active', 'img/user.png', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `veterinarians`
--

CREATE TABLE `veterinarians` (
  `id_vet` int(11) NOT NULL,
  `codigo` bigint(13) NOT NULL,
  `nombre_completo` text COLLATE utf8_spanish_ci NOT NULL,
  `genero` text COLLATE utf8_spanish_ci NOT NULL,
  `telefono` bigint(14) NOT NULL,
  `direccion_vivienda` varchar(70) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `ciudad` text COLLATE utf8_spanish_ci NOT NULL,
  `barrio` text COLLATE utf8_spanish_ci NOT NULL,
  `comentarios` text COLLATE utf8_spanish_ci NOT NULL,
  `picture_` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `veterinarians`
--

INSERT INTO `veterinarians` (`id_vet`, `codigo`, `nombre_completo`, `genero`, `telefono`, `direccion_vivienda`, `email`, `password`, `ciudad`, `barrio`, `comentarios`, `picture_`) VALUES
(1, 202020, 'Oscar veterinario 50', 'Hombre', 23232322, 'Carrera 90# 2-60', 'oscarvet4@gmail.com', '123456', 'Cali', 'Ciudad Jardin', 'Por que estoy interesado', 'img/user.png'),
(2, 2222, 'Pepito rojas', 'Hombre', 123456, 'No la se', 'pepito10@gmail.com', '123456', 'Cali', 'No lo se', 'Por que estoy interesado', 'img/user.png'),
(3, 2222, 'jose florez', 'h', 3147674969, 'Carrera 33a #39-34', 'jhondembevet@gmail.com', '123456', 'Santiago de Cali', 'No lo se', 'Por que estoy interesado', 'img/user.png'),
(4, 2222, 'Martin Lugo', 'Ninguno', 303303030, 'no se', 'martin04@gmail.com', '123456', 'Medellin', 'No lo se', 'Por que estoy interesado', 'img/user.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `weekdays`
--

CREATE TABLE `weekdays` (
  `id_weekday` int(11) NOT NULL,
  `name_weekday` text COLLATE utf8_spanish_ci NOT NULL,
  `abbreviation_weekday` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `weekdays`
--

INSERT INTO `weekdays` (`id_weekday`, `name_weekday`, `abbreviation_weekday`) VALUES
(1, 'LUNES', 'LNS'),
(2, 'MARTES', 'MTS'),
(3, 'MIERCOLES', 'MCS'),
(4, 'JUEVES', 'JVS'),
(5, 'VIERNES', 'VNS'),
(6, 'SABADO', 'SBO');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `days_`
--
ALTER TABLE `days_`
  ADD PRIMARY KEY (`id_day`),
  ADD KEY `id_lender` (`id_lender`),
  ADD KEY `id_weekdays` (`id_weekdays`);

--
-- Indices de la tabla `home_service`
--
ALTER TABLE `home_service`
  ADD PRIMARY KEY (`id_homeservice`),
  ADD KEY `id_vet` (`id_veterinario`);

--
-- Indices de la tabla `hours`
--
ALTER TABLE `hours`
  ADD PRIMARY KEY (`id_hour`);

--
-- Indices de la tabla `lenders`
--
ALTER TABLE `lenders`
  ADD PRIMARY KEY (`id_lender`),
  ADD UNIQUE KEY `id_owner` (`id_lender`),
  ADD KEY `rol` (`Cuidador`),
  ADD KEY `type_user` (`type_user`),
  ADD KEY `id_rol` (`Paseador`),
  ADD KEY `id_roles` (`Grooming`);

--
-- Indices de la tabla `medical_history`
--
ALTER TABLE `medical_history`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `id_pet` (`id_pet`),
  ADD KEY `id_vet` (`id_vet`);

--
-- Indices de la tabla `months`
--
ALTER TABLE `months`
  ADD PRIMARY KEY (`id_months`),
  ADD UNIQUE KEY `id_months` (`id_months`);

--
-- Indices de la tabla `offices_veterinarians`
--
ALTER TABLE `offices_veterinarians`
  ADD PRIMARY KEY (`id_office`),
  ADD KEY `id_vet` (`id_vet`);

--
-- Indices de la tabla `owners`
--
ALTER TABLE `owners`
  ADD PRIMARY KEY (`id_owner`),
  ADD KEY `type_user` (`type_user`);

--
-- Indices de la tabla `pets`
--
ALTER TABLE `pets`
  ADD PRIMARY KEY (`id_pet`),
  ADD KEY `id_owner` (`id_owner`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id_rol`);

--
-- Indices de la tabla `schedule_users`
--
ALTER TABLE `schedule_users`
  ADD PRIMARY KEY (`id_schedule`),
  ADD KEY `id_weekdays` (`id_days`),
  ADD KEY `id_months` (`id_months`),
  ADD KEY `id_hour` (`id_hour`);

--
-- Indices de la tabla `service_consultorio`
--
ALTER TABLE `service_consultorio`
  ADD PRIMARY KEY (`id_sconsultorio`),
  ADD KEY `id_vet` (`id_veterinario`);

--
-- Indices de la tabla `service_schedule`
--
ALTER TABLE `service_schedule`
  ADD PRIMARY KEY (`id_service`),
  ADD KEY `id_pet` (`id_pet`),
  ADD KEY `id_schedule_user` (`id_schedule_user`),
  ADD KEY `id_service_` (`id_service_`);

--
-- Indices de la tabla `tabla_eventos`
--
ALTER TABLE `tabla_eventos`
  ADD PRIMARY KEY (`id_evento`);

--
-- Indices de la tabla `type_user`
--
ALTER TABLE `type_user`
  ADD PRIMARY KEY (`id_type_user`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `type_user` (`type_user`);

--
-- Indices de la tabla `veterinarians`
--
ALTER TABLE `veterinarians`
  ADD PRIMARY KEY (`id_vet`);

--
-- Indices de la tabla `weekdays`
--
ALTER TABLE `weekdays`
  ADD PRIMARY KEY (`id_weekday`),
  ADD UNIQUE KEY `id_weekday` (`id_weekday`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `days_`
--
ALTER TABLE `days_`
  MODIFY `id_day` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `home_service`
--
ALTER TABLE `home_service`
  MODIFY `id_homeservice` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `hours`
--
ALTER TABLE `hours`
  MODIFY `id_hour` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `lenders`
--
ALTER TABLE `lenders`
  MODIFY `id_lender` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `medical_history`
--
ALTER TABLE `medical_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `months`
--
ALTER TABLE `months`
  MODIFY `id_months` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `offices_veterinarians`
--
ALTER TABLE `offices_veterinarians`
  MODIFY `id_office` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `owners`
--
ALTER TABLE `owners`
  MODIFY `id_owner` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `pets`
--
ALTER TABLE `pets`
  MODIFY `id_pet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `schedule_users`
--
ALTER TABLE `schedule_users`
  MODIFY `id_schedule` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=193;

--
-- AUTO_INCREMENT de la tabla `service_consultorio`
--
ALTER TABLE `service_consultorio`
  MODIFY `id_sconsultorio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `service_schedule`
--
ALTER TABLE `service_schedule`
  MODIFY `id_service` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tabla_eventos`
--
ALTER TABLE `tabla_eventos`
  MODIFY `id_evento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `type_user`
--
ALTER TABLE `type_user`
  MODIFY `id_type_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `veterinarians`
--
ALTER TABLE `veterinarians`
  MODIFY `id_vet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `weekdays`
--
ALTER TABLE `weekdays`
  MODIFY `id_weekday` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `days_`
--
ALTER TABLE `days_`
  ADD CONSTRAINT `days__ibfk_1` FOREIGN KEY (`id_lender`) REFERENCES `lenders` (`id_lender`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `days__ibfk_2` FOREIGN KEY (`id_weekdays`) REFERENCES `weekdays` (`id_weekday`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `home_service`
--
ALTER TABLE `home_service`
  ADD CONSTRAINT `home_service_ibfk_1` FOREIGN KEY (`id_veterinario`) REFERENCES `veterinarians` (`id_vet`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `medical_history`
--
ALTER TABLE `medical_history`
  ADD CONSTRAINT `medical_history_ibfk_1` FOREIGN KEY (`id_vet`) REFERENCES `veterinarians` (`id_vet`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `medical_history_ibfk_2` FOREIGN KEY (`id_pet`) REFERENCES `pets` (`id_pet`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `offices_veterinarians`
--
ALTER TABLE `offices_veterinarians`
  ADD CONSTRAINT `offices_veterinarians_ibfk_1` FOREIGN KEY (`id_vet`) REFERENCES `veterinarians` (`id_vet`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `owners`
--
ALTER TABLE `owners`
  ADD CONSTRAINT `owners_ibfk_1` FOREIGN KEY (`type_user`) REFERENCES `type_user` (`id_type_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `pets`
--
ALTER TABLE `pets`
  ADD CONSTRAINT `pets_ibfk_1` FOREIGN KEY (`id_owner`) REFERENCES `owners` (`id_owner`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `schedule_users`
--
ALTER TABLE `schedule_users`
  ADD CONSTRAINT `schedule_users_ibfk_4` FOREIGN KEY (`id_months`) REFERENCES `months` (`id_months`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `schedule_users_ibfk_5` FOREIGN KEY (`id_hour`) REFERENCES `hours` (`id_hour`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `schedule_users_ibfk_6` FOREIGN KEY (`id_days`) REFERENCES `days_` (`id_day`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `service_consultorio`
--
ALTER TABLE `service_consultorio`
  ADD CONSTRAINT `service_consultorio_ibfk_1` FOREIGN KEY (`id_veterinario`) REFERENCES `veterinarians` (`id_vet`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `service_schedule`
--
ALTER TABLE `service_schedule`
  ADD CONSTRAINT `service_schedule_ibfk_3` FOREIGN KEY (`id_pet`) REFERENCES `pets` (`id_pet`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `service_schedule_ibfk_4` FOREIGN KEY (`id_schedule_user`) REFERENCES `schedule_users` (`id_schedule`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `service_schedule_ibfk_5` FOREIGN KEY (`id_service_`) REFERENCES `roles` (`id_rol`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`type_user`) REFERENCES `type_user` (`id_type_user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
