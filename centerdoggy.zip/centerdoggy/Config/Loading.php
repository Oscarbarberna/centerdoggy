<?php namespace Config;
/**
 *  Class where we make the load of the files
 */
class loading
{


  public static function run(){
  	spl_autoload_register(function($class){
  		$rute = str_replace("\\","/",$class) . ".php";

  		if(! file_exists($rute)){
  			throw new Exception("File path '{class}' not found.");
  			
  		}

  		require_once($rute);
  	});
   
  }
}



 ?>
