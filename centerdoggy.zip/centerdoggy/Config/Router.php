<?php namespace Config;


class Router
{


  private $namespaces;



  public static function run(Request $request){

    if($request->getController() == ""){

      $controller = "index". "controller";
      $rute = path . "Controllers" . SPACE . $controller . ".php";
      $method = $request->getMethod();
      $parameter = $request->getParameter();


    }else{
      $controller = $request->getController(). "controller";
      $rute = path . "Controllers" . SPACE . $controller . ".php";
      $method = $request->getMethod();
      $parameter = $request->getParameter();

    }

		if(file_exists($rute)){
			 include_once $rute;
        $controlador = str_replace("controller", "", $controller);
				$contenedor = "Controllers\\".$controlador;
        $object = new $contenedor;
				if(method_exists($object,$method)){
					call_user_func(array($object,$method),$parameter);
				}else{
        
					 call_user_func(array($object,"index"));
				}
		}else{
      include_once("Views/error.php");
    }
  }
}



 ?>
