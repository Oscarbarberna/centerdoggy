<?php namespace Controllers;

class index{

	public function index(){
		include_once('Views/index.php');
	}
}


 ?>