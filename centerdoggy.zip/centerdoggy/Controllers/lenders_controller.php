<?php namespace Controllers;

use Models\Lenders as Lenders;

class lenders_{

	private $lenders;

	public function __construct(){
		$this->lenders = new Lenders();
	}

	public function index(){
		include_once('Views/view_lender.php');
	}


	public function view_lender(){
		include_once('Views/view_lender.php');
	}

	public function load_lenders(){
		$response = $this->lenders->list("nothing");
		if($response){
			if($response->rowCount() > 0){
				echo json_encode($response->fetchAll(\PDO::FETCH_ASSOC));
			}else{
				echo json_encode(array('data' => 'empty'));
			}
		}
	}

	public function load_all_lenders($type_lender){
		$row = $this->lenders->all_user_service($type_lender);
		if($row){
			if($row->rowCount() > 0){
				while($result = $row->fetch()){
							echo '<a href="/centerdoggy/profile/'.$result["id_lender"].'/" class="box_ b_mtx30 box_user" data-iduser="'.$result["id_lender"].'">
									<div class="box_info  box_service">
										<div class="panel_head">
											<div class="container_image_">
												<img src="'.rute__folder.$result["picture"].'" alt="" class="image_avatar">
											</div>
										</div>
										<div class="panel_body">
											<p class="name_">'.$result["name_lender"].'</p>
											<p class="description_short">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Numquam, assumenda.</p>
										</div>
									</div>
								</a>';
						}
			}else{
				echo "No hay prestadores con este perfil";
			}
		}
		

	}


	public function delete(){
		$id_lender = (isset($_POST['id_lender'])) ? $_POST['id_lender'] :  "";
		$this->lenders->set('id',$id_lender);

		$response = $this->lenders->delete();
		if($response){
			if($response->rowCount() > 0){
				echo json_encode(array('process' => 'success'));
			}else{
				echo json_encode(array('process' => 'failed'));
			}
		}	
	}

}


 ?>