<?php namespace Controllers;

use Models\Services as Services;

class portal_salud{

	private $service;

	public function index(){
		include_once('Views/portal_salud.php');
	}

	public function consultas(){
		include_once('Views/consultas.php');
	}

	public function veterinarians(){
		include_once('Views/veterinarians_.php');
	}


	public function offices(){
		include_once('Views/offices_.php');
	}

	public function domicilio(){
		include_once('Views/domicilio.php');
	}


	public function consultorio(){
		include_once('Views/service_consultorios.php');
	}


	public function __construct(){
		$this->service = new Services();
	}

	public function consultas_adomicilio(){
			$response = $this->service->list("adomicilio");
			if($response){
				if($response->rowCount() > 0){
					
					echo json_encode($response->fetchAll(\PDO::FETCH_ASSOC));

				}else{

					echo json_encode(array('data' => 'empty'));
				}
			}
		
	}


	public function consultas_consultorio(){
		$response = $this->service->list("other");
			if($response){
				if($response->rowCount() > 0){
					print_r(json_encode($response->fetchAll(\PDO::FETCH_ASSOC)));
				}else{	
					echo json_encode(array('data' => 'empty'));
				}
			}
	}
}



 ?>