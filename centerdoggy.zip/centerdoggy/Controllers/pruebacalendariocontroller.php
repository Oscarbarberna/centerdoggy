<?php namespace Controllers;

use Models\Calendar as Calendar;

class pruebacalendario{

	private $calendar;

	public function __construct(){
		$this->calendar = new Calendar();
	}

	public function load_info(){
		$data = $this->calendar->load_info();

		echo json_encode($data->fetchAll(\PDO::FETCH_ASSOC));
	}
}


 ?>