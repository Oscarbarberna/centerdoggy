<?php namespace Controllers;

use Models\Veterinarians as Veterinarians;
class veterinarians_{

	private $veterinarians;


	public function index(){
		include_once('Views/veterinarians.php');
	}

	public function __construct(){
		$this->veterinarians = new Veterinarians();
	}

	public function add(){
		include_once('Views/register_veterinarians.php');
	}


	public function view($id){
		if($id == "undefined" || $id == null){
			echo "Page no found";
		}else{
			include_once('Views/view_veterinarian.php');
		}
	}


	public function register(){
		$code =     (isset($_POST['code'])) ? $_POST['code'] : "";
		$this->veterinarians->set("codigo",$code);
		$name_lender =     (isset($_POST['name'])) ? $_POST['name'] : "";
		$this->veterinarians->set("nombre",$name_lender);
		$sex  = 	(isset($_POST['sex'])) ? $_POST['sex'] : "";
		$this->veterinarians->set("genero",$sex);
		$phone 		 = 	   (isset($_POST['phone'])) ? $_POST['phone'] : "";
		$this->veterinarians->set("telefono",$phone);
	    $address 		 = 	   (isset($_POST['address'])) ? $_POST['address'] : "";
		$this->veterinarians->set("direccion",$address);
		$email 		 =     (isset($_POST['email'])) ? $_POST['email'] : "";
		$this->veterinarians->set("email",$email);
		$password 	 = 	   (isset($_POST['password'])) ? $_POST['password'] : "";
		$this->veterinarians->set("password",$password);
		$city_lender = 	   (isset($_POST['city'])) ? $_POST['city'] : "";
		$this->veterinarians->set("ciudad",$city_lender);
		$neit_lender = 	   (isset($_POST['neit'])) ? $_POST['neit'] : "";
		$this->veterinarians->set("barrio",$neit_lender);
		// echo "hola"."\n".$this->veterinarians->get("codigo")."\n".$this->veterinarians->get("nombre")."\n".$this->veterinarians->get("genero")."\n".$this->veterinarians->get("telefono")."\n".$this->veterinarians->get("direccion")."\n".$this->veterinarians->get("email")."\n".$this->veterinarians->get("password")."\n".$this->veterinarians->get("password")."\n".$this->veterinarians->get("ciudad")."\n".$this->veterinarians->get("barrio");
		
		$comentarios = 'Por que estoy interesado';
		$this->veterinarians->set('comentarios',$comentarios);
		$picture = "img/user.png";
		$this->veterinarians->set("picture",$picture);
		$response = $this->veterinarians->add();

		if($response){
			if($response->rowCount() > 0){
				echo "success";
			}else{
				echo "failed";
			}
		}
		
	}

	public function list(){
		$response = $this->veterinarians->list();
		if($response){
			if($response->rowCount() > 0){
				echo json_encode($response->fetchAll(\PDO::FETCH_ASSOC));
			}else{
				echo json_encode(array('data'=>'empty'));
			}
		}
	}


	public function get_info_vet(){
		$url = $_SERVER['REQUEST_URI'];
		$split = explode("/", $url);

		if(count($split) >= 4){	
			$this->veterinarians->set("id_vet",$split[4]);
			$response = $this->veterinarians->list_for_id();


			return $response->fetch();
			
			
			
		}
		
	}

	public function edit_vet(){

		$id = (isset($_POST['id_vet'])) ? $_POST['id_vet'] : '';
		$this->veterinarians->set("id_vet",$id);
		$name_lender =     (isset($_POST['name'])) ? $_POST['name'] : "";
		$this->veterinarians->set("nombre",$name_lender);
		$sex  = 	(isset($_POST['sex'])) ? $_POST['sex'] : "";
		$this->veterinarians->set("genero",$sex);
		$email 		 =     (isset($_POST['email'])) ? $_POST['email'] : "";
		$this->veterinarians->set("email",$email);
		$city_lender = 	   (isset($_POST['city'])) ? $_POST['city'] : "";
		$this->veterinarians->set("ciudad",$city_lender);
		$neit_lender = 	   (isset($_POST['neit'])) ? $_POST['neit'] : "";
		$this->veterinarians->set("barrio",$neit_lender);
		$phone 		 = 	   (isset($_POST['phone'])) ? $_POST['phone'] : "";
		$this->veterinarians->set("telefono",$phone);
		$response = $this->veterinarians->edit_info();

		if($response){
			if($response->rowCount() > 0 ){
				echo "success";
			}else{
				echo "failed";
			}
		}
	}

	public function delete(){
		$id_vet = (isset($_POST['id_vet'])) ? $_POST['id_vet'] :  "";
		$this->veterinarians->set('id_vet',$id_vet);

		$response = $this->veterinarians->delete();
		if($response){
			if($response->rowCount() > 0){
				echo json_encode(array('process' => 'success'));
			}else{
				echo json_encode(array('process' => 'failed'));
			}
		}
	}


	public function search_for_name(){
		$name = (isset($_POST['name'])) ? $_POST['name'] : "none";
		$this->veterinarians->set('nombre',$name);
		$response = $this->veterinarians->search_for_name();

		if($response){
			if($response->rowCount() > 0){
				echo json_encode($response->fetchAll(\PDO::FETCH_ASSOC));
			}else{
				echo "empty";
			}
		}
	}
}


 ?>