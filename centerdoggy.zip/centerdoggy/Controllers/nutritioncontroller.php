<?php namespace Controllers;


class nutrition{

	public function index(){
		include_once('Views/nutrition.php');
	}
}


 ?>