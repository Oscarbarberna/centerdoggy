<?php namespace Controllers;


class pets{

	public function index(){
		include_once('Views/pets.php');
	}
}



 ?>