<?php namespace Controllers;



class signout{


	public function close_sesion($id){
		session_start();
		if(isset($_SESSION['id_user']) || isset($_SESSION['email'])){
			if($_SESSION['id_user'] == $id){
				session_destroy();
				unset($_SESSION['id_user']);
				header('Location: http://localhost:8089/centerdoggy/signin/');
			}else{
				session_destroy();
				unset($_SESSION['email']);
				header('Location: http://localhost:8089/centerdoggy/signin/');
			}
		}else{
			session_destroy();
			unset($_SESSION['email']);
			header('Location: http://localhost:8089/centerdoggy/signin/');
		}
	}


}




 ?>