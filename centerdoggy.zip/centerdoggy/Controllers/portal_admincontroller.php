<?php namespace Controllers;


class portal_admin{

	public function index(){
		include_once('Views/portal_admin.php');
	}
}




 ?>