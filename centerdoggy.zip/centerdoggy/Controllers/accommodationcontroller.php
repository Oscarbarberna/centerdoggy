<?php namespace Controllers;


class accommodation{

	public function index(){
		include_once('Views/accommodation.php');
	}
}


 ?>