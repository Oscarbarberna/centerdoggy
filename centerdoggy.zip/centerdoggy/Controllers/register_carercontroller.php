<?php namespace Controllers;

use Models\Lenders;

class register_carer{

	private $lenders;

	public function index(){
		include_once('Views/register_carer.php');
	}

	public function __construct(){
		$this->lenders = new Lenders();
	}

	public function add_lender(){
		$code_lender =     (isset($_POST['code_lender'])) ? $_POST['code_lender'] : "";
		$this->lenders->set("code",$code_lender);
		$name_lender =     (isset($_POST['name_lender'])) ? $_POST['name_lender'] : "";
		$this->lenders->set("name",$name_lender);
		$sex 		 = 	   (isset($_POST['sex'])) ? $_POST['sex'] : "";
		$this->lenders->set("sex",$sex);
		$email 		 =     (isset($_POST['email'])) ? $_POST['email'] : "";
		$this->lenders->set("email",$email);
		$password 	 = 	   (isset($_POST['password'])) ? $_POST['password'] : "";
		$this->lenders->set("password",$password);
		$city_lender = 	   (isset($_POST['city_lender'])) ? $_POST['city_lender'] : "";
		$this->lenders->set("city_lender",$city_lender);
		$neit_lender = 	   (isset($_POST['neit_lender'])) ? $_POST['neit_lender'] : "";
		$this->lenders->set("neit_lender",$neit_lender);
		$phone 		 = 	   (isset($_POST['phone'])) ? $_POST['phone'] : "";
		$this->lenders->set("phone",$phone);
		$picture = "img/user.png";
		$this->lenders->set("picture",$picture);
		$status 	 =      "no active";
		$this->lenders->set("status",$status);
		$rol 		 = 		(isset($_POST['rol'])) ? $_POST['rol'] : "";
		$roles = array_filter(explode("-",preg_replace('/[^0-9]+/',"-",str_replace(")","",str_replace("(", "", $rol)))),"strlen");
		$datos = "";
		
		if(count($roles) == 1){
			if($roles[1] == 1){
				$datos = array(
					'Cuidador' => $roles[1],
					'Paseador' => 0,
					'Grooming' => 0
				);
			}else if($roles[1] == 2){
				$datos = array(
					'Cuidador' => 0,
					'Paseador' => $roles[1],
					'Grooming' => 0
				);
			}else{
				$datos = array(
					'Cuidador' => 0,
					'Paseador' => 0,
					'Grooming' => $roles[1]
				);
			}
		}else if(count($roles) == 2){
			if($roles[1] == 1 && $roles[2] == 2){
				$datos = array(
					'Cuidador' => $roles[1],
					'Paseador' => $roles[2],
					'Grooming' => 0
				);	
			}else if($roles[1] == 2 && $roles[2] == 3){
				$datos = array(
					'Cuidador' => 0,
					'Paseador' => $roles[1],
					'Grooming' => $roles[2]
				);
			}else{
				$datos = array(
					'Cuidador' => $roles[1],
					'Paseador' => 0,
					'Grooming' => $roles[2]
				);
			}
			
		}else{
			$datos = array(
					'Cuidador' => $roles[1],
					'Paseador' => $roles[2],
					'Grooming' => $roles[3]
				);
		}
		$this->lenders->set("rol",$datos);
		$type_user 	 = 2;
		$this->lenders->set("type_user",$type_user);
		$state = 1;
		$this->lenders->set("state",$state);
		$call = $this->lenders->add();

		if($call){
			if($call->rowCount() > 0){
				session_start();
				$_SESSION["email"] = $email;
				echo "success";
			}else{
				echo "failed";
			}
		}

	}

	public function edit_lender($arg){
		
		$id_user = 0;

		if($arg == "default"){
			$id_user = isset($_SESSION['id_user']) ? $_SESSION['id_user'] : "";
			$name_lender =     (isset($_POST['name_lender'])) ? $_POST['name_lender'] : "";
			$this->lenders->set("name",$name_lender);
			$this->lenders("id",$id_user);
			$response = $this->lenders->edit();

				if($response){
						if($response->rowCount() > 0){
							echo "success";
						}else{
							echo "failed";
						}
				}
		}else{
			$id_user =  isset($_POST['id_user']) ? $_POST['id_user'] : "";
			$this->lenders("id",$id_user);
			$response = $this->lenders->edit();

				if($response){
						if($response->rowCount() > 0){
							echo "success";
						}else{
							echo "failed";
						}
				}


		}


	}


	public function delete_lender(){
		$id_user =  isset($_POST['id_user']) ? $_POST['id_user'] : "";
		$response = $this->lenders->delete();

		if($response){
			if($response->rowCount() > 0){
				echo "success";
			}else{
				echo "failed";
			}
		}
	}
}



 ?>