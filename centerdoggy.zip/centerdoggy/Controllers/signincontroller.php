<?php namespace Controllers;


use Models\Users as Users;

class signin{

	private $users;

	public function __construct(){
		$this->users = new Users();
	}


	public function index(){
		include_once('Views/signin.php');
	}


	public function signin(){
		$email = isset($_POST['email']) ? $_POST['email'] : "";
		$password = isset($_POST['password']) ? $_POST['password'] : "";
		if(empty($email) && empty($password)){
			echo "failed";
		}else{
			$this->users->set("email",$email);
			$this->users->set("password",$password);
			$result = $this->users->signin();

			if($result){
				if($result->rowCount() > 0){
					$row = $result->fetch();
					$response = "";
					if($row["type_user"] == 1){
						$response = array(
										"URL" => "http://localhost:8089/centerdoggy/portal_admin/",
										"res" => "ok"
										 );
					}else{
						$response = array("res" => "failed");
					}
					session_start();
					$_SESSION['email'] = $row['email'];
					$_SESSION['id_user'] = $row['id_user'];
					$_SESSION['location'] = "admin";
					echo json_encode($response);
					
				}else{
					$this->users->set("email",$email);
					$this->users->set("password",$password);
					$result = $this->users->loginowners();
					if($result->rowCount() > 0){
						$row = $result->fetch();
						if($row["type_user"] == 2){
							$response = array(
									 "URL" => "http://localhost:8089/centerdoggy/portal_modules/",
									 "res" => "ok"
							);
							
						}else{
							$response = array(
									 "res" => "failed"
							);
						}
						session_start();
						$_SESSION['email'] = $row['email'];
						$_SESSION['id_user'] = $row['id_owner'];
						$_SESSION['location'] = "owners";
						echo json_encode($response);
					
					}else{
						$this->users->set("email",$email);
						$this->users->set("password",$password);
						$result = $this->users->loginlenders();
						if($result->rowCount() > 0){
							$row = $result->fetch();
							if($row["type_user"] == 2){
								$response = array(
									"URL" => "http://localhost:8089/centerdoggy/portal_lenders/",
									"res" => "ok"
								);
							}else{
								$response = array(
									"res" => "failed"
								);
							}
							session_start();
							$_SESSION['email'] = $row['email'];
							$_SESSION['id_user'] = $row['id_lender'];
							$_SESSION['location'] = "lenders";
							echo json_encode($response);
					
						}else{
							$response = array(
									"res" => "failed"
								);
							echo json_encode($response);	
						}
					}
				}
			}
		}
	}

}


 ?>