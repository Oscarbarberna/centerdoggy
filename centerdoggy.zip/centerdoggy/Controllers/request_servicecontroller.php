<?php namespace Controllers;

use Models\Calendar as Calendar;

class request_service{

	private $calendar;

	public function __construct(){
		$this->calendar = new Calendar();
	}
	public function index(){
		include_once('Views/request_service.php');
	}

	public function list_request_service($id){
		$id_user = (isset($_SESSION['id_user'])) ? $_SESSION['id_user'] : '';
		$this->calendar->set('id_user',$id_user);
		$id_service = (isset($id)) ? $id : "";
		$this->calendar->set('id_service',$id_service);
		$response = $this->calendar->list_request_service();

		if($response){
			if($response->rowCount() > 0){
				$count = 1;
				while($row = $response->fetch()){
					if(($count % 2)){
						echo '<div class="list_info ">
							<li class="list_ list_id">
								<p class="info_">'.$count.'</p>
							</li>
							<li class="list_">
								<p class="info_">'.$row["name_owner"].'</p>
							</li>
							<li class="list_">
								<p class="info_">'.$row["name_pet"].'</p>
							</li>
							<li class="list_">
								<p class="info_">'.$row["day_service"].'</p>
							</li>
							<li class="list_">
								<p class="info_">Activo</p>
							</li>
							<li class="list_">
								<div class="input_button">
									<button type="button" class="button_ b_wgreen_">Finalizar</button>
								</div>
							</li>
						</div>';
					}else{
						echo '<div class="list_info color">
							<li class="list_ list_id">
								<p class="info_">'.$count.'</p>
							</li>
							<li class="list_">
								<p class="info_">'.$row["name_owner"].'</p>
							</li>
							<li class="list_">
								<p class="info_">'.$row["name_pet"].'</p>
							</li>
							<li class="list_">
								<p class="info_">'.$row["day_service"].'</p>
							</li>
							<li class="list_">
								<p class="info_">Activo</p>
							</li>
							<li class="list_">
								<div class="input_button">
									<button type="button" class="button_ b_wgreen_">Finalizar</button>
								</div>
							</li>
						</div>';
					}
					
						$count++;
				}
			}else{
				echo "No hay solicitudes para este servicio";
			}
		}
	}



}



 ?>