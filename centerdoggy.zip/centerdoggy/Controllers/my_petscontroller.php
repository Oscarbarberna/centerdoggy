<?php namespace Controllers;

use Models\Pets as Pets;

class my_pets{

	private $pets;

	public function __construct(){
		$this->pets = new Pets();
	}


	public function index(){
		include_once('Views/my_pets.php');
	}

	public function add(){
		include_once('Views/new_pet.php');
	}

	public function new_pet(){
		include_once('Views/register_pet.php');
	}
	public function view(){
		include_once('Views/view_pet.php');
	}


	public function add_pet(){
		session_start();
		$name     = (isset($_POST["name"])) ? $_POST["name"] : "";
		$this->pets->set("name_pet",$name);
		$date     = (isset($_POST["date"])) ? $_POST["date"] : "";
		$this->pets->set("date_pet",$date);
		$color    = (isset($_POST["color"])) ? $_POST["color"] : "";
		$this->pets->set("color",$color);
		$picture  = (isset($_POST["picture"])) ? $_POST["picture"] : "";
		$this->pets->set("picture",$picture);
		$id_owner = (isset($_SESSION['id_user'])) ? $_SESSION['id_user'] : "empty";
		$id_owner_ = (isset($_POST['id_owner'])) ? $_POST['id_owner'] : 0;
		if($id_owner == "empty"){
			$this->pets->set("id_owner",$id_owner_);	
		}else{
			$this->pets->set("id_owner",$id_owner);
		}
		
		$response = $this->pets->add_pets();

		if($response){
			if($response->rowCount() > 0){
				echo "success";
			}else{
				echo "failed";
			}
		}
	}

	public function load_all_pets(){
		session_start();
		$id = isset($_SESSION["id_user"]) ? $_SESSION["id_user"] : "";

		$this->pets->set("id_owner",$id);
		$response = $this->pets->load_allPets();
		if($response){
			if($response->rowCount() > 0){
				echo json_encode($response->fetchAll(\PDO::FETCH_ASSOC));
			}else{
				echo json_encode(array('data' => 'empty'));
			}
		}
		
	}


	public function list(){
		$response = $this->pets->list();

		if($response){
			if($response->rowCount() > 0){
				echo json_encode($response->fetchAll(\PDO::FETCH_ASSOC));
			}else{
				echo json_encode(array('data' => 'empty'));
			}
		}
	}


	public function delete(){
		$id_pet = (isset($_POST['id_pet'])) ? $_POST['id_pet'] :  "";
		$this->pets->set('id_pet',$id_pet);

		$response = $this->pets->delete();
		if($response){
			if($response->rowCount() > 0){
				echo json_encode(array('process' => 'success'));
			}else{
				echo json_encode(array('process' => 'failed'));
			}
		} 
	}

	public function get_info_(){

		$url = $_SERVER['REQUEST_URI'];
		$split = explode("/", $url);

		if(count($split) >= 5){	
			$this->pets->set("id_pet",$split[4]);
			$result = $this->pets->list_();	
			

			return $result->fetch();
		}
	}


	public function update_info(){
		$id_pet = isset($_POST['id_pet']) ? $_POST['id_pet'] : "";
		$this->pets->set("id_pet",$id_pet);
		$name_pet = isset($_POST['name_pet']) ? $_POST['name_pet'] : "";
		$this->pets->set("name_pet",$name_pet);
		$fecha_nacimiento = $_POST['fecha_nacimiento'] ? $_POST['fecha_nacimiento'] : "";
		$this->pets->set("date_pet",$fecha_nacimiento);
		$color = isset($_POST['color']) ? $_POST['color'] : "";
		$this->pets->set("color",$color);
		$picture = isset($_POST['picture']) ? $_POST['picture'] : "";
		$this->pets->set("picture",$picture);
		$response = $this->pets->update_info();
		if($response){
			if($response->rowCount() > 0){
				echo "success";
			}else{
				echo "failed";
			}	
		}

	}


}




 ?>