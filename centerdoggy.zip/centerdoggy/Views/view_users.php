<?php 
session_start();

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header" style="border-bottom:1px solid #dedede; height: 80px;">
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section c_green">Premium</a></li>
			<li class="list_"><a href="#" class="link_section">Como funciona</a></li>
			<li class="list_"><a href="signin.html" class="link_section button_ b_green btn_option_user">Mi perfil</a>
				    <div class="sub_options_ sub_user">
                <div class="list_option">
                    <a href="/centerdoggy/profile/<?php echo $_SESSION['id_user']; ?>" class="link_">Mis perfil</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/my_pets/" class="link_">Mis mascotas</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Configuraciones</a>
                </div>
                <div class="list_option">
                  <a href="/center_doggy/signout/close_sesion/" class="link_">Salir</a>
                </div>
            </div>
			</li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_">
		<div class="container_info_profile">
       <div class="panel_left">
         <div class="panel_head">
              <div class="grid_photo">
                  <div class="container_image">
                    <img src="http://localhost:8089/center_doggy/Views/img/user.png" alt="" class="image_user">
                  </div>
                  <p class="name_pet"><?php   
                    if(empty($this->load_info_current_user()["name_lender"])){
                      echo $this->load_info_current_user()["name_owner"];
                    }else{
                      echo $this->load_info_current_user()["name_lender"];
                    } ?>
                    </p>
              </div>
         </div>
         <div class="panel_body">
           <div class="container_form form_white" style="margin-top:10px; height:620px;">
               <form action="" class="form_ form_rgone form_view_info_user">
                 <h2 class="title_" style="position:relative;top:-60px;color:#41BB5F;font-family: 'Poppins Bold';">Otra informacion</h2>
                   <div class="input_group">
                       <input type="text" name="code_us" id="code_indentify" class="textfield code_us" autofocus="On" value="<?php   
                    if(empty($this->load_info_current_user()["city_lender"])){
                      echo $this->load_info_current_user()["city_owner"];
                    }else{
                      echo $this->load_info_current_user()["city_lender"];
                    } ?>">
                       <label for="code_indentify" class="lb_info">Ciudad</label>
                   </div>
                   <div class="input_group" style="margin-top:35px;">
                       <input type="text" name="name_us" id="" class="textfield name_us" value="<?php   
                    if(empty($this->load_info_current_user()["neit_lender"])){
                      echo $this->load_info_current_user()["neit_owner"];
                    }else{
                      echo $this->load_info_current_user()["neit_lender"];
                    } ?>">
                       <label for="name_complete" class="lb_info">Barrio de influencia</label>
                   </div>
                   <div class="input_group" style="margin-top:35px;">
                       <input type="text" name="phone_us" id="number_phone" class="textfield phone_us" value="<?php echo $this->load_info_current_user()["sexo"]; ?>">
                       <label for="number_phone" class="lb_info">Sexo</label>
                   </div>
                   <div class="input_group">
                     <div class="input_button">
                       <button type="submit" class="button_ b_green btn_snd">Editar</button>
                     </div>
                   </div>
               </form>
               <div class="form_loader">
                   <div class="container_loader" style="top:60px;">
                       <div class="bar_loader">
                         <div class="loader"></div>
                           <img src="img/padlock.svg" alt="">
                       </div>
                       <p class="info_">cargando la informacion ...</p>
                   </div>
               </div>
           </div>
         </div>
       </div>
       <div class="panel_right">
         <div class="container_form form_white" style="margin-top:10px; height:620px;">
             <form action="" class="form_ form_rgone form_view_info_user">
               <h2 class="title_" style="position:relative;top:-60px; color:#41BB5F; font-family: 'Poppins Bold';" >Informacion breve</h2>
                 <div class="input_group">
                     <input type="text" name="code_us" id="code_indentify" class="textfield code_us" autofocus="On" value="<?php   
                    if(empty($this->load_info_current_user()["code_lender"])){
                      echo 0;
                    }else{
                      echo $this->load_info_current_user()["code_lender"];
                    } ?>">
                     <label for="code_indentify" class="lb_info">CC:</label>
                 </div>
                 <div class="input_group" style="margin-top:35px;">
                     <input type="text" name="name_us" id="" class="textfield name_us" value="<?php   
                    if(empty($this->load_info_current_user()["name_lender"])){
                      echo $this->load_info_current_user()["name_owner"];
                    }else{
                      echo $this->load_info_current_user()["name_lender"];
                    } ?>">
                     <label for="name_complete" class="lb_info">Nombres y Apellidos</label>
                 </div>
                 <div class="input_group" style="margin-top:35px;">
                     <input type="text" name="phone_us" id="number_phone" class="textfield phone_us" value="<?php echo $this->load_info_current_user()["phone_"]; ?>">
                     <label for="number_phone" class="lb_info">Telefono Celular</label>
                 </div>
                 <div class="input_group" style="margin-top:35px;">
                     <input type="text" name="email_us" id="email_" class="textfield email_us" value="<?php echo $this->load_info_current_user()["email"]; ?>">
                       <label for="email_" class="lb_info">Correo electronico</label>
                 </div>
                 <div class="input_group"  style="display:none;">
                     <select name="rol_us" id="rol_us" class="textfield rol_us">
                       <option value="default">Selecciona el rol que deseas desempeñar</option>
                       <option value="1">Cuidador</option>
                       <option value="2">Paseador</option>
                       <option value="3">Spa Grooming</option>
                     </select>
                 </div>
                 
                 <div class="input_group">
                   <div class="input_button">
                     <button type="submit" class="button_ b_green btn_snd">Editar</button>
                   </div>
                 </div>
             </form>
             <div class="form_loader">
                 <div class="container_loader" style="top:60px;">
                     <div class="bar_loader">
                       <div class="loader"></div>
                         <img src="img/padlock.svg" alt="">
                     </div>
                     <p class="info_">cargando la informacion ...</p>
                 </div>
             </div>
         </div>
       </div>
     </div>
	</div>
  <script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
  <script>
    document.querySelector('.btn_option_user').addEventListener("click", function(e){
      e.preventDefault();
      $('.sub_user').toggle();
    });
  </script>
</body>
</html>