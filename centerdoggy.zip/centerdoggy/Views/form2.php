<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon_/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header border-bottom">
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_ right-30"><div class="input_button"><a href="signin.html" class=" button_  b_notification"><i class="icon-bell"></i></a></div></li>
			<li class="list_ right-30"><a href="#" class="link_section">Jhon Murillo Mendez</a></li>		
		</ul>
	</nav>
</header>
<body>
	<div class="container_">
		<div class="pane_menu_navigation">
			<div class="section_logo">
				<a href="#" class="logo_portal"><i class="icon-dog-paw"></i></a>
			</div>
			<div class="navigation">
				<li class="list_"><a href="/centerdoggy/portal_admin/" class="section_"><i class="icon-home"></i></a></li>
				<li class="list_"><a href="/centerdoggy/lenders/" class="section_ active"><i class="icon-avatar"></i></a></li>
				<li class="list_"><a href="/centerdoggy/pets/" class="section_"><i class="icon-zynga-logotype"></i></a></li>
				<li class="list_"><a href="/centerdoggy/veterinarians_/" class="section_"><i class="icon-pet"></i></a></li>
				<li class="list_"><a href="/centerdoggy/offices_/" class="section_"><i class="icon-hotel"></i></a></li>
			</div>
		</div>
		<div class="content_info pane_section">
			<div class="content_title center p-x30 m_bottomx60">
				<h2 class="title_ t_green">Estos los Prestadores, que trabajan con nosotros</h2>
				<p class="info_">Administra los usuarios del sistemas!</p>
			</div>
			
			<span class="alert_">Upps! Ha ocurrido un error dificilisimo</span>
			<div class="container_form form_center form_white form_shadow" style="width:80%;">
				<form action="/centerdoggy/register_carer/add_lender/" class="form_" method="POST">
					<div class="division_fields">
						<div class="input_group"><input type="text" name="" id="field_codes" class="textfield field_codes" placeholder="Lugar y Fecha de nacimiento"></div>
					<div class="input_group"><input type="text" name="" id="field_name" class="textfield field_name" placeholder="Estado civil"></div>	
					</div>
					
					<div class="input_group">
						<select name="" id="field_sex" class="textfield field_sex">
							<option value="default">Selecciona tu sexo</option>
							<option value="Hombre">Hombre</option>
							<option value="Mujer">Mujer</option>
						</select>
					</div>
					
					<div class="input_group"><input type="password" name="" id=" field_password" class="textfield field_password" placeholder="Password"></div>
					<div class="input_group" style="display: flex; align-items: center;">
						<div class="input_checkbox input_auto" style="visibility: visible;"><input type="checkbox" name="select_one" class="select_days_" id="select_one" data-rol="-1"><label for="select_one" class="checkbox_"><i class="icon-checkmark"></i></label>Cuidador</div>
						<div class="input_checkbox input_auto" style="visibility: visible;"><input type="checkbox" name="select_one" class="select_days_" id="select_two" data-rol="-2"><label for="select_two" class="checkbox_"><i class="icon-checkmark"></i></label>Paseador</div>
						<div class="input_checkbox input_auto" style="visibility: visible;"><input type="checkbox" name="select_one" class="select_days_" id="select_three" data-rol="-3"><label for="select_three" class="checkbox_"><i class="icon-checkmark"></i></label>Grooming</div>
					</div>
					<div class="division_fields">	
						<div class="input_group">
									<select name="" id="field_city" class="textfield field_city">
											<option value="default">Ciudad de tu ubicación</option>
											<option value="Cali">Santiago de Cali</option>
											<option value="Bogota">Bogota</option>
											<option value="Medellin">Medellin</option>
									</select>
						</div>
						<div class="input_group"><input type="text" name="" id=" field_neit" class="textfield field_neit" placeholder="Barrio de influencia"></div>
					</div>
					<div class="input_group">
						<div class="input_button">
							<button type="submit" class="button_ b_green btn_snd btn_send__">Guardar</button>
						</div>
					</div>
				</form>
				<div class="form_loader">
	              <div class="container_loader">
	                  <div class="bar_loader">
	                    <div class="loader"></div>
	                      <img src="<?php echo rute__folder;?>img/padlock.svg" alt="">
	                  </div>
	                  <p class="info_">Estamos registrandote...</p>
	              </div>
          		</div>
			</div>
		</div>
		
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>
		document.querySelector('.btn_controls').addEventListener("click", function(e){
			e.preventDefault();
			$('.sub_controls_').toggle();
		});
		
	</script>
</body>
</html>