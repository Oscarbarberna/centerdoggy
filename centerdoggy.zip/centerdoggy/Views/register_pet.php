<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon_/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header border-bottom">
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_ right-30"><div class="input_button"><a href="signin.html" class=" button_  b_notification"><i class="icon-bell"></i></a></div></li>
			<li class="list_ right-30"><a href="#" class="link_section">Jhon Murillo Mendez</a></li>		
		</ul>
	</nav>
</header>
<body>
	<div class="window_modal">
		<div class="container_select" style="height:170px;">
			<button type="button" class="btn_close">x</button>
			<p class="info_select">¿Deseas eliminar esta mascota?</p>
			<div class="container_button" style="width: 90%; display: flex; justify-content: center;">
				<div class="input_button">
					<a href="#drop" class="button_ b_green direction_info btn_delete_">Eliminar</a>
				</div>
				<div class="input_button">
					<a href="#cancel" class="button_ b_wgreen load_schedule">Cancelar</a>
				</div>
			</div>
		</div>
	</div>
	<div class="container_">
		<div class="pane_menu_navigation">
			<div class="section_logo">
				<a href="#" class="logo_portal"><i class="icon-dog-paw"></i></a>
			</div>
			<div class="navigation">
				<li class="list_"><a href="/centerdoggy/portal_admin/" class="section_"><i class="icon-home"></i></a></li>
				<li class="list_"><a href="/centerdoggy/lenders/" class="section_"><i class="icon-avatar"></i></a></li>
				<li class="list_"><a href="/centerdoggy/pets/" class="section_ active"><i class="icon-zynga-logotype"></i></a></li>
				<li class="list_"><a href="/centerdoggy/veterinarians_/" class="section_"><i class="icon-pet"></i></a></li>
				<li class="list_"><a href="/centerdoggy/offices_/" class="section_"><i class="icon-hotel"></i></a></li>
			</div>
		</div>
		<div class="content_info pane_section">
			<div class="content_title center p-x30 m_bottomx60">
				<h2 class="title_ t_green">Agrega nuevas mascotas</h2>
				<p class="info_">Administra las mascotas que estan dentro del portal</p>
			</div>
			<span class="alert_">Upps! Ha ocurrido un error dificilisimo</span>
			<div class="container_form form_center form_white form_shadow" style="width:80%;">
				<form action="/centerdoggy/register_carer/add_lender/" class="form_" method="POST">
					<div class="input_group" style="margin-top:5px; margin-bottom: 70px;"><input type="text" name="id_owner" id="field_owner" class="textfield field_owner" placeholder="Busca un propietario" data-owner="0" onkeyup="search_veterinarians();"><label for="feild_owner" class="lb_info">Busca el propietario de la mascota</label><div class="sub_options_ sub_controls_">
            		</div>
            		</div>
					<div class="input_group" style="margin-top:5px; margin-bottom: 70px;" style="margin-top:35px;">
                     <input type="text" name="name_pet" id="name_pet" class="textfield name_pet">
                     <label for="name_complete" class="lb_info">Nombre de la mascota</label>
                 </div>
                 <div class="input_group" style="margin-top:5px; margin-bottom: 70px;" style="margin-top:35px;">
                     <input type="date" name="date_pet"  min="1990-01-01" max="5000-12-31" id="date_pet" class="textfield date_pet">
                     <label for="date_pet" class="lb_info">Fecha de nacimiento</label>
                 </div>
                 <div class="input_group" style="margin-top:5px; margin-bottom: 70px;" style="margin-top:35px;">
                     <input type="text" name="color_pet" id="color_pet" class="textfield color_pet">
                       <label for="color_pet" class="lb_info">Color</label>
                 </div>
                 <div class="input_group" style="margin-top:5px; margin-bottom: 70px;">
                    <div class="input_button">
                        <input type="file" name="picture_pet" id="picture_pet" style="display: none;" class="picture_pet">  
                        <label for="picture_pet" class="button_ b_wgreen" style="cursor: pointer;">Añadir una foto</label>
                    </div>
                     <label for="code_indentify" class="lb_info" style="left:0px;">Foto</label>
                 </div>
					<div class="input_group" style="margin-top:-26px;">
						<div class="input_button">
							<button type="submit" class="button_ b_green btn_snd btn_send__">Guardar</button>
						</div>
					</div>
				</form>
				<div class="form_loader">
	              <div class="container_loader">
	                  <div class="bar_loader">
	                    <div class="loader"></div>
	                      <img src="<?php echo rute__folder;?>img/padlock.svg" alt="">
	                  </div>
	                  <p class="info_">Estamos registrandote...</p>
	              </div>
          		</div>
			</div>
		</div>
		
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>
		

		function choose(e){
			console.log(e);
			var id_owner = e.dataset.id;
			e.parentNode.parentNode.parentNode.children[0].value = e.textContent;
			e.parentNode.parentNode.parentNode.children[0].dataset.owner = e.dataset.id;
			console.log(e.parentNode.parentNode.parentNode.children[0]);
			document.querySelector('.sub_controls_').style.display = 'none';
		}

		function search_veterinarians(e){

			var text_to_search = document.querySelector('.field_owner').value;
			
			
			$('.sub_controls_').css({
				'display' :'block',
				'width'   : '100%',
				'left'    : '0px',
				'right'   : '0px'
			});

			if(text_to_search == "" || text_to_search.length == 0){

			}else{
				$.ajax({
					url:'/centerdoggy/portal_owner/search_owner_for_name/',
					type:"POST",
					data:{name:text_to_search},
					success: function(response){
						
						if(response == "empty"){
							$('.sub_controls_').html('<div class="list_option"><a href="/centerdoggy/offices/add/" class="link_" onclick="choose(this); return false;">No existen veterinarios con este nombre, intenta colocando el nombre completo</a></div>');
						}else{
							var data_ = JSON.parse(response);
							let dom = "";
							data_.map(function(item,index){
								
								dom += `<div class="list_option"><a href="/centerdoggy/offices/add/" class="link_" data-id="${item.id_owner}" onclick="choose(this); return false;">${item.name_owner}</a></div>`;
								
							});
							$('.sub_controls_').html(dom);
						}
						
					}
				})	
			}
			
		}

		var file = "img/dog_service.png";
        //add_pet
        document.querySelector('.picture_pet').addEventListener('change', e =>{
           file = this.files[0];
        });

		document.querySelector('.btn_send__').addEventListener('click', function(e){
			e.preventDefault();
			var owner = document.querySelector('.field_owner');
			var name     = document.querySelector('.name_pet').value;
            var date_pet = document.querySelector('.date_pet').value;
            var color    = document.querySelector('.color_pet').value;
            var picture  = file;

			if(owner.value == "" && name == "" && date_pet == "" && color == ""){

			}else if(name == ""){

            }else if(date_pet == ""){
                console.log('date empty');
            }else if(color == ""){
                console.log('color empty');
            }else{
				
				

				$.ajax({
					url:'/centerdoggy/my_pets/add_pet/',
					type:'POST',
					data:{id_owner:owner.dataset.owner,name:name,date:date_pet,color:color,picture:file},
					beforeSend: function(){
						document.querySelector('.form_loader').style.visibility = 'visible';
					},

					complete: function(){
						document.querySelector('.form_loader').style.visibility = 'hidden';
					},

					success: function(response){
						console.log(response);
						if(response == "failed"){

						}else{
							document.querySelector('.alert_').innerHTML = '<strong>Felicidades</strong> La mascota se registro correctamente!';
							document.querySelector('.alert_').classList.remove('alert_error');
							document.querySelector('.alert_').classList.add('alert_success');

						}
					}
				}).done(function(){
					$('input').val('');
				});
			}	

		});	
	</script>
</body>
</html>