<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header">
	<a href="/centerdoggy/" class="logo_icono" style="position:absolute;left:15px;top:10px;z-index: 200;">
		<h1 class="name_company">PET_CENTER</h1>
	</a>
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="/centerdoggy/" class="link_section">Nuestros servicios</a></li>
			<li class="list_"><a href="/centerdoggy/" class="link_section">Como funciona</a></li>
			<li class="list_"><div class="input_button"><a href="/centerdoggy/signin/" class=" button_ b_green">Iniciar Sesión</a></div></li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_">
		<div class="content_info main_info">
			<div class="container_image"></div>
			<div class="panel_info">
				<h1 class="title_main">Contacta a los mejores cuidadores,paseadores y especializados en grooming para tu mascot</h1>
				<p class="info_">¿Necesitas quien cuide de tu mascota cuando te encuentras a distancia de tu hogar</p>
				<div class="container_button center">
					<div class="input_button"><a href="/centerdoggy/register_owner/" class="button_ b_green">Soy propietario</a></div>
					<div class="input_button"><a href="/centerdoggy/register_carer/" class="button_ b_dark">Soy prestador</a></div>
				</div>
			</div>

		</div>
		<div class="content_info bg_gray">
			<div class="content_title center">
				<h2 class="title_ t_green">Nuestros serviciós</h2>
				<p class="info_">Mira lo que te brinda pet_center</p>
			</div>
			<div class="content_box flex" style="margin-bottom: 55px;">
				<a href="/centerdoggy/portal_owner/" class="box_">
					<div class="box_info  box_service dark">
					<img src="<?php echo rute__folder;?>img/help.png" alt="" class="image_ t-x30">
					<h3 class="title_info t-x40">Prestadores</h3>
					</div>
				</a>
				<a href="/centerdoggy/portal_salud/" class="box_">
					<div class="box_info  box_service dark">
					<img src="<?php echo rute__folder;?>img/icon_wellness.png" alt="" class="image_ t-x30">
					<h3 class="title_info t-x40">Salud</h3>
					</div>
				</a>
				<a href="/centerdoggy/nutrition/" class="box_">
					<div class="box_info  box_service dark">
					<img src="<?php echo rute__folder;?>img/food_dog.png" alt="" class="image_ t-x30">
					<h3 class="title_info t-x40">Nutrición</h3>
					</div>
				</a>
				<a href="/centerdoggy/accommodation/" class="box_">
					<div class="box_info  box_service dark">
					<img src="<?php echo rute__folder;?>img/pet-shop.png" alt="" class="image_ t-x30">
					<h3 class="title_info t-x40">Alojamiento</h3>
					</div>
				</a>
			</div>
		</div>
		<div class="content_info">
			<div class="content_title center" style="margin-top: 60px;">
				<h2 class="title_ t_green">¿Que tan facil es?</h2>
				<p class="info_">Mira lo facil que puede ser cuidar de tu mascota sin estar en casa</p>
			</div>
			<div class="content_box flex">
				<div class="box_info w-x30">
					<img src="<?php echo rute__folder; ?>img/boy_propietario.png" alt="" class="image_">
					<h3 class="title_info">Ingresar como propiertario</h3>
					<p class="info_">De esta manera podras ingresar como propietario de la mascota que deseas registrar.</p>
				</div>
				<div class="box_info w-x30">
					<img src="<?php echo rute__folder; ?>img/register_dog.png" alt="" class="image_">
					<h3 class="title_info">Registra a tus mascotas</h3>
					<p class="info_">De esta manera podras ingresar como propietario de la mascota que deseas registrar.</p>
				</div>
				<div class="box_info w-x30">
					<img src="<?php echo rute__folder; ?>img/choose_service.png" alt="" class="image_">
					<h3 class="title_info">Escoje un servicio</h3>
					<p class="info_">De esta manera podras ingresar como propietario de la mascota que deseas registrar.</p>
				</div>
			</div>
		</div>
		<div class="content_info bg_gray">
			<div class="content_title center p-x70">
				<h2 class="title_ t_green">¿Por que usar center_doggy?</h2>
				<p class="info_ c_grayl">Mira lo facil que puede ser cuidar de tu mascota sin estar en casa</p>
			</div>
			<div class="content_box flex">
				<div class="box_info w-x30">
					<img src="<?php echo rute__folder; ?>img/icon_security.png" alt="" class="image_">
					<h3 class="title_info">Seguridad</h3>
					<p class="info_ c_grayl">De esta manera podras ingresar como propietario de la mascota que deseas registrar.</p>
				</div>
				<div class="box_info w-x30">
					<img src="<?php echo rute__folder; ?>img/icon_wellness.png" alt="" class="image_">
					<h3 class="title_info">Atencion y bienestar</h3>
					<p class="info_ c_grayl">De esta manera podras ingresar como propietario de la mascota que deseas registrar.</p>
				</div>
				<div class="box_info w-x30">
					<img src="<?php echo rute__folder; ?>img/icon_clock.png" alt="" class="image_">
					<h3 class="title_info">Servició a tiempo</h3>
					<p class="info_ c_grayl">De esta manera podras ingresar como propietario de la mascota que deseas registrar.</p>
				</div>
			</div>
		</div>
		<div class="content_info">
			<div class="content_title center p-x70 m_bottomx60">
				<h2 class="title_ t_green">¿Que opionan nuestros usuarios?</h2>
				<p class="info_ c_grayl">Mira lo facil que puede ser cuidar de tu mascota sin estar en casa</p>
			</div>
			<div class="content_box flex wrap" style="justify-content: center;">
				<div class="box_testimonies">
        <div class="panel_head" style="background:#fff;">
          <div class="container_division_info_user">
              <div class="panel_left">
                <div class="container_image"><img src="https://cdn-images-1.medium.com/fit/c/120/120/1*RjtxJVETiqFVHZiHkjuOKg.png" alt="" class="image_user"></div>
              </div>
              <div class="panel_right">
                <a href="#" class="direction_profile name_user">Jhon Murillo Mendez</a>
                <p class="short_description_user">Estudiante</p>
              </div>
            </div>
        </div>
        <div class="panel_body">
          <p class="info_testimonies">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis enim omnis, numquam tempore, non dolorum impedit. Similique adipisci, repudiandae.</p>
        </div>
      </div>
      <div class="box_testimonies">
        <div class="panel_head" style="background:#fff;">
          <div class="container_division_info_user">
              <div class="panel_left">
                <div class="container_image"><img src="https://cdn-images-1.medium.com/fit/c/120/120/1*RjtxJVETiqFVHZiHkjuOKg.png" alt="" class="image_user"></div>
              </div>
              <div class="panel_right">
                <a href="#" class="direction_profile name_user">Jhon Murillo Mendez</a>
                <p class="short_description_user">Estudiante</p>
              </div>
            </div>
        </div>
        <div class="panel_body">
          <p class="info_testimonies">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis commodi culpa, corrupti, nobis, reiciendis recusandae provident.</p>
        </div>
      </div>
      <div class="box_testimonies box_extend">
        <div class="panel_head" style="background:#fff;">
          <div class="container_division_info_user">
              <div class="panel_left">
                <div class="container_image"><img src="https://cdn-images-1.medium.com/fit/c/120/120/1*RjtxJVETiqFVHZiHkjuOKg.png" alt="" class="image_user"></div>
              </div>
              <div class="panel_right">
                <a href="#" class="direction_profile name_user">Jhon Murillo Mendez</a>
                <p class="short_description_user">Estudiante</p>
              </div>
            </div>
        </div>
        <div class="panel_body">
          <p class="info_testimonies">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis laborum nulla eligendi voluptas soluta ab odio voluptatum sit! Porro tempore deleniti recusandae saepe! Cupiditate libero reprehenderit iste labore esse quam, Perspiciatis laborum nulla eligendi voluptas soluta ab odio voluptatum sit! Porro tempore deleniti recusandae saepe! Cupiditate libero reprehenderit iste labore esse quam.</p>
        </div>
      </div>
			</div>
		</div>
		<div class="content_info bg_purple">
			<div class="content_title center p-x70 m_bottomx60">
				<h2 class="title_ t_green t_white">¿Quieres ser parte de pet_center?</h2>
				<p class="info_ c_white">Mira lo sencillo que son los pasos para postularte</p>
			</div>
			<div class="content_box flex wrap" style="justify-content: center;">
				<div class="box_info w-x30 box_white">
					<img src="<?php echo rute__folder; ?>img/register_.png" alt="" class="image_">
					<h3 class="title_info">Registate</h3>
					<p class="info_ c_grayl">De esta manera podras ingresar como propietario de la mascota que deseas registrar.</p>
				</div>
				<div class="box_info w-x30 box_white">
					<img src="<?php echo rute__folder; ?>img/candidate_.png" alt="" class="image_">
					<h3 class="title_info">Candidato</h3>
					<p class="info_ c_grayl">De esta manera podras ingresar como propietario de la mascota que deseas registrar.</p>
				</div>
				<div class="box_info w-x30 box_white">
					<img src="<?php echo rute__folder; ?>img/approved_.png" alt="" class="image_">
					<h3 class="title_info">Admitido</h3>
					<p class="info_ c_grayl">De esta manera podras ingresar como propietario de la mascota que deseas registrar.</p>
				</div>
				<div class="box_info w-x30 box_white b_m15">
					<img src="<?php echo rute__folder; ?>img/certificate_.png" alt="" class="image_">
					<h3 class="title_info">Certificación laboral</h3>
					<p class="info_ c_grayl">De esta manera podras ingresar como propietario de la mascota que deseas registrar.</p>
				</div>
				<div class="content_title content_absolute absolute_bottom">
					<div class="input_button">
						<a href="#" class="button_ b_white_p">Registarme ahora</a>
					</div>
				</div>
			</div>
		</div>
		<div class="content_info">
			<div class="content_title center p-x70 m_bottomx60">
				<h2 class="title_ t_green">¿Que estas esperando para hacer parte de Pet_center?</h2>
				<p class="info_">Mira lo sencillo que son los pasos para postularte</p>
			</div>
			<div class="content_box flex">
				<div class="box_info w-x30 box_white b_m15 h_250px">
					<img src="<?php echo rute__folder; ?>img/owner_dog.png" alt="" class="image_">
					<h3 class="title_info">Ingresar como propiertario</h3>
					<div class="input_button">
						<a href="/centerdoggy/register_owner/" class="button_ b_green">Registrarme ahora</a>
					</div>
				</div>
				<div class="box_info w-x30 box_white b_m15 h_250px">
					<img src="<?php echo rute__folder; ?>img/prestador_.png" alt="" class="image_">
					<h3 class="title_info">Ingresar como  prestador</h3>
					<div class="input_button">
						<a href="/centerdoggy/register_carer/" class="button_ b_dark">Registrarme ahora</a>
					</div>
				</div>
			</div>
		</div>
		<div class="content_info bg_gray">
			<footer class="footer">
				<div class="pane_info">
					<a href="#" class="logo_icono">
						<h1 class="name_company">PET_CENTER</h1>
					</a>
					<p class="short_info">Derechos reservados 2018 SeitConsultores. Hecho con ♥ en Colombia</p>
				</div>
				<div class="pane_info pane_division">
					<div class="panes_">
						<h4 class="type_">Producto</h4>
						<li class="list_option"><a href="#" class="section">¿Por que Pet_center?</a></li>
						<li class="list_option"><a href="#" class="section">Planes y precios</a></li>
					</div>
					<div class="panes_">
						<h4 class="type_">Recursos</h4>
						<li class="list_option"><a href="#" class="section">Centro de ayuda</a></li>
						<li class="list_option"><a href="#" class="section">Guias</a></li>
					</div>
					<div class="panes_">
						<h4 class="type_">Compañia</h4>
						<li class="list_option"><a href="#" class="section">Acerca de</a></li>
						<li class="list_option"><a href="#" class="section">Empleo</a></li>
					</div>
				</div>
			</footer>
		</div>
	</div>
</body>
</html>