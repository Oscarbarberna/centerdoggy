<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon_/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header border-bottom">
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_ right-30"><div class="input_button"><a href="signin.html" class=" button_  b_notification"><i class="icon-bell"></i></a></div></li>
			<li class="list_ right-30"><a href="#" class="link_section link_option_">Jhon Murillo Mendez</a></li>		
		</ul>
	</nav>
</header>
<body>
	<div class="window_modal">
		<div class="container_select" style="height:170px;">
			<button type="button" class="btn_close">x</button>
			<p class="info_select">¿Deseas eliminar esta mascota?</p>
			<div class="container_button" style="width: 90%; display: flex; justify-content: center;">
				<div class="input_button">
					<a href="#drop" class="button_ b_green direction_info btn_delete_">Eliminar</a>
				</div>
				<div class="input_button">
					<a href="#cancel" class="button_ b_wgreen load_schedule">Cancelar</a>
				</div>
			</div>
		</div>
	</div>
	<div class="container_">
		<div class="pane_menu_navigation">
			<div class="section_logo">
				<a href="#" class="logo_portal"><i class="icon-dog-paw"></i></a>
			</div>
			<div class="navigation">
				<li class="list_"><a href="/centerdoggy/portal_admin/" class="section_"><i class="icon-home"></i></a></li>
				<li class="list_"><a href="/centerdoggy/lenders/" class="section_"><i class="icon-avatar"></i></a></li>
				<li class="list_"><a href="/centerdoggy/pets/" class="section_"><i class="icon-zynga-logotype"></i></a></li>
				<li class="list_"><a href="/centerdoggy/veterinarians_/" class="section_"><i class="icon-pet"></i></a></li>
				<li class="list_"><a href="/centerdoggy/offices_/" class="section_ active"><i class="icon-hotel"></i></a></li>
			</div>
		</div>
		<div class="content_info pane_section">
			<div class="content_title center p-x30 m_bottomx60">
				<h2 class="title_ t_green">Estos son los consultorios que estan registrados en el portal</h2>
				<p class="info_">Administra los consultorios del sistema, desde esté apartado!</p>
			</div>
			<div class="container_search">
				<div class="input_group">
					<input type="text" name="" id="" class="textfield" placeholder="Busca a un veterinario...">
				</div>
				<div class="input_controls">
					<button type="button" class="controls_ btn_controls"><span aria-label="Más acciones" class="recents-item__actions-button button-secondary mc-overflow-button mc-button mc-button-secondary"><span class="mc-button-content"><svg width="32" height="32" viewBox="0 0 32 32" class="mc-icon-template-actionable mc-overflow-button-icon"><g fill="none" fill-rule="evenodd"><g fill="#637282"><circle cx="10.5" cy="16.5" r="1.5"></circle><circle cx="15.5" cy="16.5" r="1.5"></circle><circle cx="20.5" cy="16.5" r="1.5"></circle></g></g></svg></span></span></button>
					<div class="sub_options_ sub_controls_">
		                <div class="list_option">
		                    <a href="/centerdoggy/offices_/add/" class="link_">Agregar</a>
		                </div>
		                <div class="list_option">
		                  <a href="#" class="link_ btn_drop">Eliminar</a>
		                </div>
            		</div>
				</div>
				<div class="input_button">
					<button type="button" class="button_ b_green">Buscar</button>
				</div>
			</div>
			<div class="content_box flex wrap" id="content_veterinarians" style="justify-content: center;"></div>
		</div>
		
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>
		document.querySelector('.btn_controls').addEventListener("click", function(e){
			e.preventDefault();
			$('.sub_controls_').toggle();
		});

		fetch('/centerdoggy/offices_/list_all/',{
			method:'POST'	
		})
		.then(response => {
				return response.json();
		})
		.then(result => {
			if(result.hasOwnProperty("data")){
				if(result.data == "empty"){
					console.log('No hay datos');
					document.getElementById('content_veterinarians').innerHTML = '<div style="display:block; padding:25px;"><p>Aun no hay consultorios tu o tus mascotas</p></div>';
				}
			}else{
				console.log(result);
				var dom = "";
				 result.map((item,index) => {
				 		dom += `<a href="#" class="box_ b_mtx30 box_consultorios">
					<div class="box_info  box_service">
						<div class="panel_head">
							<div class="input_checkbox" style="right:35px;">
								<input type="checkbox" name="check_select" id="select_this_${result[index].id_vet}" data-id="${result[index].id_vet}" onchange="select_(this);">
								<label for="select_this_${result[index].id_vet}" class="checkbox_"><i class="icon-checkmark"></i></label>
							</div>
							<h1 class="name_">Consultorio</h1>
							<p class="text_location">Barrio</p>
							<strong class="text_location">${result[index].neit}</strong>	
							
						</div>
						<div class="panel_body">
							<p class="name_">Información de contacto</p>
							<p class="description_short">Ubicación: ${result[index].address}</p>
							<p class="description_short">Telefono: ${result[index].telefono}</p>
							<p class="description_short">Email: ${result[index].email}</p>
						</div>
					</div>
				</a>`;
				 });	
					
				document.getElementById('content_veterinarians').innerHTML = dom;
			}


				
		});

		function show_input_check(items){
			[].forEach.call(items,inputs => {
				inputs.style.visibility = 'visible';
				
						
			});
		}
		document.querySelector('.btn_drop').addEventListener('click', function(e){
			e.preventDefault();
			show_input_check(document.querySelectorAll('.input_checkbox'));
		});

		function select_(e){
			//e.parentNode.parentNode.parentNode.remove();
			$('.sub_controls_').hide();
			document.querySelector('.window_modal').style.visibility = "visible";
			console.log(e.parentNode.parentNode.parentNode);
		}
		document.querySelector('.btn_delete_').addEventListener('click', function(e){
			e.preventDefault();

			$.each($('.checkbox_'), function(index,item_){
				if($(this).css('background-color') == 'rgb(65, 187, 95)'){
					$(this).parent().parent().parent().remove();
					
					console.log($(this).parent().children().eq(0).data('id'));
					
					let data = new FormData();
					data.append('id_vet',$(this).parent().children().eq(0).data('id'));
					document.querySelector('.window_modal').style.visibility = "hidden";
					fetch('/centerdoggy/veterinarians_/delete/',{
						method:'POST',
						body:data	
					})
					.then(response => {
							return response.text();
					})

					.then(result => {
						console.log(result);
						if(result.process == "failed"){

						}else{

						}
					});
				}
			});

		});

	</script>
</body>
</html>