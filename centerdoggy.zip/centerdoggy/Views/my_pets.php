<?php 
session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header" style="border-bottom:1px solid #dedede; height: 80px;">
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section c_green">Premium</a></li>
			<li class="list_"><a href="#" class="link_section">Como funciona</a></li>
			<li class="list_"><a href="signin.html" class="link_section button_ b_green btn_option_user">Mi perfil</a>
				<div class="sub_options_ sub_user" style="z-index: 500;">
                <div class="list_option">
                    <a href="/centerdoggy/profile/view_owner/<?php echo $_SESSION['id_user']; ?>/" class="link_">Mis perfil</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/my_pets/" class="link_">Mis mascotas</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Configuraciones</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/signout/close_sesion/<?php echo $_SESSION['id_user'];?>/" class="link_">Salir</a>
                </div>
            </div>
			</li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_">
		<div class="content_info">
			<div class="content_title center p-x30 m_bottomx60">
				<h2 class="title_ t_green">Estos son las mascotas que has registrado</h2>
				<p class="info_">Administra la información de las mascotas que tienes en tu responsabilidad!</p>
			</div>
			<div class="container_search">
				<div class="input_group">
					<input type="text" name="" id="" class="textfield" placeholder="Busca a un cuidador...">
				</div>
				<div class="input_controls">
					<button type="button" class="controls_ btn_controls"><span aria-label="Más acciones" class="recents-item__actions-button button-secondary mc-overflow-button mc-button mc-button-secondary"><span class="mc-button-content"><svg width="32" height="32" viewBox="0 0 32 32" class="mc-icon-template-actionable mc-overflow-button-icon"><g fill="none" fill-rule="evenodd"><g fill="#637282"><circle cx="10.5" cy="16.5" r="1.5"></circle><circle cx="15.5" cy="16.5" r="1.5"></circle><circle cx="20.5" cy="16.5" r="1.5"></circle></g></g></svg></span></span></button>
					<div class="sub_options_ sub_controls_">
		                <div class="list_option">
		                    <a href="/centerdoggy/my_pets/add/" class="link_">Agregar</a>
		                </div>
		                <div class="list_option">
		                  <a href="#" class="link_">Eliminar</a>
		                </div>
            		</div>
				</div>
				<div class="input_button">
					<button type="button" class="button_ b_green">Buscar</button>
				</div>
			</div>
			<div class="content_box flex wrap" id="content_pets" style="width: 70%;">
				
				<div class="DiscussionLoader DiscussionLoader-background">
					<div class="DiscussionLoader-background"></div>
				</div>
				
			</div>
		</div>
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>
		document.querySelector('.btn_option_user').addEventListener("click", function(e){
			e.preventDefault();
			$('.sub_user').toggle();
		});
		document.querySelector('.btn_controls').addEventListener("click", function(e){
			e.preventDefault();
			$('.sub_controls_').toggle();
		});

		fetch('/centerdoggy/my_pets/load_all_pets/',{
			method:'POST'	
		})
		.then(response => {
				return response.json();
		})
		.then(result => {
			if(result.hasOwnProperty("data")){
				if(result.data == "empty"){
					console.log('No hay datos');
					document.getElementById('content_pets').innerHTML = "Aun no has registrado tu o tus mascotas";
				}
			}else{
				console.log(result);
				var dom = "";
				 result.map((item,index) => {
				 		dom += `<a href="/centerdoggy/my_pets/view/${result[index].id_pet}/" class="box_ b_mtx30">
					<div class="box_info  box_service">
						<div class="panel_head">
							<div class="input_checkbox">
								<input type="checkbox" name="check_select" id="select_this">
								<label for="select_this" class="checkbox_"></label>
							</div>
							<div class="container_image_">
								<img src="http://localhost:8089/centerdoggy/Views/${result[index].picture}" alt="" class="image_avatar">
							</div>
						</div>
						<div class="panel_body">
							<p class="name_">${result[index].name_pet}</p>
							<p class="description_short">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Numquam, assumenda.</p>
						</div>
					</div>
				</a>`;
				 });	
					
				document.getElementById('content_pets').innerHTML = dom;
			}


				
		});
	</script>
</body>
</html>