<?php 
session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header" style="border-bottom:1px solid #dedede; height: 80px;">
    <a href="<?php $url = ($_SESSION['location'] == "admin") ? '/centerdoggy/pets/' : '/centerdoggy/my_pets/'; echo $url; ?>" type="button" class="btn_prev"><svg width="44" height="44" viewBox="0 0 24 24" class="mc-icon mc-icon-template-stateless mc-icon-template-stateless--right left-icon spectrum-hack-rotate-icon" style="transform: rotate(180deg);"><path d="M10.414 7.05l4.95 4.95-4.95 4.95L9 15.534 12.536 12 9 8.464z" fill="#637282" fill-rule="evenodd"></path></svg></a>
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section c_green">Premium</a></li>
			<li class="list_"><a href="#" class="link_section">Como funciona</a></li>
			<li class="list_"><a href="signin.html" class="link_section button_ b_green btn_option_user">Mi perfil</a>
				<div class="sub_options_">
                <div class="list_option">
                    <a href="/centerdoggy/profile/<?php echo $_SESSION['id_owner']; ?>" class="link_">Mis perfil</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Mis mascotas</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Configuraciones</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/signout/close_sesion/1/" class="link_">Salir</a>
                </div>
            </div>
			</li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_info_profile">
            <div class="container_center_">
                <div class="container_info_lender_current" style="margin-top: 10px; width: 75%;">
                        <div class="container_division_info_user">
                          <div class="panel_left">
                            <div class="container_image"><img src="http://localhost:8089/centerdoggy/Views/<?php echo $this->list()['image']; ?>" alt="" class="image_user" style="position: relative; top:10px;"></div>
                          </div>
                          <div class="panel_right">
                            <a href="#" class="direction_profile name_user"><?php echo $this->list()['name_pet']; ?></a>
                            <p class="short_description_user" style="margin-bottom: 10px;">Este prestador es apasionado y ama lo que hace, por eso te lo recomendamos para los serviciós</p>
                            </div>
                          </div>
                    </div>
                     <div class="panel_body">
                      <div class="container_form form_white" style="margin-top:0px; height:510px; <?php $this->display_form(); ?>">
                         <form action="/centerdoggy/medical_history_/add_v/" class="form_ form_rgone form_info_v">
                           <h2 class="title_" style="position:relative;top:-85px; color:#41BB5F; font-family: 'Poppins Bold'; left:25px;" >Informacion basica del veterinario</h2>
                            <div class="division_fields" style="top:-30px;">
                               <div class="input_group" style="">
                                   <input type="text" name="name_v" id="" class="textfield name_v" value="<?php echo $this->list()["name_v"]; ?>" autofocus="On">
                                   <label for="name_complete" class="lb_info">Nombres y Apellidos</label>
                               </div>
                                <div class="input_group" style="">
                                   <input type="text" name="sex_v" id="sex_v" class="textfield sex_v" value="<?php echo $this->list()['sex_v']; ?>">
                                   <label for="number_phone" class="lb_info">Sexo</label>
                               </div>
                            </div>

                            <div class="division_fields" style="top:-30px;">
                               <div class="input_group" style="">
                                 <input type="text" name="phone_v" id="phone_v" class="textfield phone_v" value="<?php echo $this->list()['telefono_v']; ?>">
                                   <label for="email_" class="lb_info">Telefono</label>
                               </div>
                               <div class="input_group">
                                     <input type="text" name="city_v" id="city_v" class="textfield city_v" value="<?php echo $this->list()['city_v']; ?>">
                                     <label for="code_indentify" class="lb_info">Ciudad</label>
                                 </div>
                              </div>
                            <div class="division_fields" style="top:-30px;">
                               <div class="input_group" style="">
                                   <input type="text" name="direccion_v" id="" class="textfield direccion_v" value="<?php echo $this->list()['direccion_v']; ?>">
                                   <label for="name_complete" class="lb_info">Dirección</label>
                               </div>
                               <div class="input_group">
                                 <input type="text" name="email_v" id="email_v" class="textfield email_v" value="<?php echo $this->list()['email_v']; ?>">
                                 <label for="number_phone" class="lb_info">Correo electronico</label>
                             </div>

                            </div>
                            <div class="division_fields" style="top:-30px; display: block;">
                                <div class="input_group" style="float:left;left:12px;right:0px;">
                                   <input type="text" name="whatsapp_v" id="" class="textfield whatsapp_v" value="<?php echo $this->list()['whatsapp']; ?>" style="position: relative;display: inline-block;">
                                   <label for="name_complete" class="lb_info">WhatsApp (+57)</label>
                               </div>
                               
                            </div>  
                            <div class="division_fields" style="justify-content: start; top:-60px;">
                              <div class="input_button" style="left:10px;">
                                 <button type="submit" class="button_ b_green btn_save_main_info">Guardar información</button>
                               </div>
                            </div>
                         </form>
                         <div class="form_loader form_luno">
                             <div class="container_loader" style="top:60px;">
                                 <div class="bar_loader">
                                   <div class="loader"></div>
                                     <img src="img/padlock.svg" alt="">
                                 </div>
                                 <p class="info_">Guardando la informacion ...</p>
                             </div>
                         </div>
                     </div>
                     <div class="container_form form_white" style="margin-top: 80px;">
                         <form action="/centerdoggy/medical_history_/update_add/" class="form form_rgone">
                              <h2 class="title_" style="position:relative;top:-85px; color:#41BB5F; font-family: 'Poppins Bold'; left:25px;" >Datos basicos de la historia clinica</h2>   
                             <div class="division_fields" style="top:-30px;">
                              <div class="input_group" style="">
                                    <select name="cer_v" class="textfield sv__" id="">
                                        <option value="Y">Si</option>
                                        <option value="N">No</option>
                                    </select>
                                   <label for="name_complete" class="lb_info">Certificado de Vacunación</label>
                               </div>
                               
                                 <div class="input_group">
                                 <select name="hemo" class="textfield hemo" id="">
                                        <option value="Y">Si</option>
                                        <option value="N">No</option>
                                    </select>
                                 <label for="number_phone" class="lb_info">Hemograma</label>
                             </div>
                            </div>
                            <div class="division_fields" style="top:-30px;">  
                              <div class="input_group">
                                   <select name="hemop" class="textfield hemop" id="">
                                          <option value="Y">Si</option>
                                          <option value="N">No</option>
                                      </select>
                                   <label for="number_phone" class="lb_info">Hemoparasitos</label>
                              </div>
                              <div class="input_group">
                                 <select name="con_in" class="textfield s_sp" id="">
                                        <option value="Y">Si</option>
                                        <option value="N">No</option>
                                    </select>
                                 <label for="number_phone" class="lb_info">Servicio de Salud portal</label>
                             </div>
                            </div>
                            <div class="division_fields" style="top:-30px;">
                              <div class="input_group">
                                 <select name="con_in" class="textfield cv__" id="">
                                        <option value="Y">Si</option>
                                        <option value="N">No</option>
                                    </select>
                                 <label for="number_phone" class="lb_info">Control veterinario</label>
                             </div>
                              <div class="input_group">
                                 <select name="con_in" class="textfield con_in" id="">
                                        <option value="Y">Si</option>
                                        <option value="N">No</option>
                                    </select>
                                 <label for="number_phone" class="lb_info">Consulta de ingreso</label>
                             </div>
                            </div>
                            <div class="division_fields" style="top:-30px;">
                              <div class="input_group">
                                 <select name="p_mantenimiento" class="textfield plan_m" id="">
                                        <option value="Y">Si</option>
                                        <option value="N">No</option>
                                    </select>
                                 <label for="number_phone" class="lb_info">Plan de mantenimiento</label>
                             </div> 
                              <div class="input_group">
                                 <select name="aeps" class="textfield aeps" id="">
                                        <option value="Y">Si</option>
                                        <option value="N">No</option>
                                    </select>
                                 <label for="number_phone" class="lb_info">Afiliación EPS</label>
                             </div>

                            </div>
                            <div class="division_fields" style="justify-content: start; top:-60px;">
                              <div class="input_button" style="left:10px;">
                                 <button type="submit" class="button_ b_green btn_edit_info">Guardar información</button>
                               </div>
                            </div>
                         </form>
                     </div>
                     </div>
      </div>
      <div class="toast"></div>
        </div>
    <script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
    <script>
        document.querySelector('.btn_option_user').addEventListener("click", function(e){
            e.preventDefault();
            $('.sub_options_').toggle();
        });

       

        function toast(text){
            var t = document.querySelector('.toast');
            t.innerHTML = text;
            t.classList.add('active');

            setTimeout(function(){
                t.classList.remove('active');   
            }, 6000);
        }

        function getParameterByName(name){
            name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
            var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
            return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
        }

        function getId(){
            const URL = window.location.href;
            let data = URL.split('/');
            if(data.length >= 8){
                console.log(data[6]);
               return data[6];    
            }
            
        }   
        
        document.querySelector('.btn_save_main_info').addEventListener('click', e =>{
            e.preventDefault();
            
            console.log('Estas presionandome....');
           
           var name_v     = document.querySelector('.name_v'),
                sexo      = document.querySelector('.sex_v'),
                telefono  = document.querySelector('.phone_v'),
                ciudad    = document.querySelector('.city_v'),
                direccion = document.querySelector('.direccion_v'),
                correo    = document.querySelector('.email_v'),
                whatsapp  = document.querySelector('.whatsapp_v'),
                cv__      = document.querySelector('.cv__'),
                hemo      = document.querySelector('.hemo'),
                hemop     = document.querySelector('.hemop');

           
           //URL
           const request = document.querySelector('.form_info_v').getAttribute('action');     

                if(name_v.value.length > 0 && sexo.value.length > 0 && telefono.value.length > 0 && ciudad.value.length > 0 &&  direccion.value.length > 0 && correo.value.length > 0 && whatsapp.value.length > 0){

                      let data_ = new FormData($('.form_info_v')[0]);
                      let pet = getParameterByName('pet');
                      data_.append('id_pet',pet);

                      $.ajax({
                      url:request,
                      type:'POST',
                      data:data_,
                      processData:false,
                      cache:false,
                      contentType:false,
                      beforeSend:function(){
                        document.querySelector('.form_luno').style.visibility = 'visible';
                      },
                      complete: function(){
                        document.querySelector('.form_luno').style.visibility = 'hidden';
                      },

                      success: function(data){
                        console.log(data);
                        if(data == "failed"){
                           toast('Ha ocurrido un error al registrar el veterinario :(');
                        }else{
                          toast('Hemos registrado tu veterinario correctamente!!');
                        }
                      }


                    }).done(function(){
                      $('input').val('');
                    });
                  
                }else{
                  toast('Erro! no puedes dejar los campos vacios  :(');
                }
              
        });
        
        // document.querySelector('.btn_edit_info').addEventListener('click', e => {
        //   e.preventDefault();
        //     let sv_   = document.querySelector('.sv__');
        //     let s_sp  = document.querySelector('.s_sp');
        //     let hemo  = document.querySelector('.hemo');
        //     let hemop = document.querySelector('.hemop');
        //     let cv_   = document.querySelector('.cv__');
        //     let en_co = document.querySelector('.en_co');
        //     let domi_ = document.querySelector('.domi__');
        //     let cin   = document.querySelector('.con_in');
        //     let planm = document.querySelector('.plan_m');
        //     let aeps  = document.querySelector('.aeps');

        //     if(sv_.value.length > 0 && s_sp.value.length > 0 && hemo.value.length > 0 && hemop.value.length > 0 && cv_.value.length > 0 && cv_.value.length > 0 && en_co.value.length > 0 && domi_.value.length > 0 && cin.value.length > 0 && planm.value.string && aeps.value.length > 0){

        //     }else{
        //       toast('Erro! no puedes dejar los campos vacios  :(');
        //     }

        //   });


    </script>
</body>
</html>