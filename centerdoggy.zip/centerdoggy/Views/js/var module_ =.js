var module_ = (function(){

	var obj = {};

	var init = function(){
		staritems();
		add_events();
	};


	var staritems = function(){
		obj.btn_snd  = document.querySelector('.btn_send_');
		obj.btn_snd_ = document.querySelector('.btn_send__');
		obj.fields = {
			codes: document.querySelector('.field_codes'),
			name_user:  document.querySelector('.field_name'),
			sex:   document.querySelector('.field_sex'),
			email: document.querySelector('.field_email'),
			pass:  document.querySelector('.field_password'),
			phone: document.querySelector('.field_phone'),
			city:  document.querySelector('.field_city'),
			neit: document.querySelector('.field_neit'),
			rol:  document.querySelector('.field_rol')

		};
		obj.alert = document.querySelector('.alert_');

	};

	var add_events = function(){
		if(typeof(document.querySelector('.btn_send_')) == "undefined" || obj.btn_snd == null){
		}else{
			obj.btn_snd.addEventListener("click",events.register_owner);
		}
		
		obj.btn_snd_.addEventListener("click",events.register_lender);
	};

	function http_request(url_,method,data_,before_s,com_,success_){
		$.ajax({url:url_,type:method,data:data_,beforeSend: before_s,complete:com_,success: success_});
	}

	function before_s(){
		//obj.btn_snd.disabled = true;
		document.querySelector('.form_loader').style.visibility = 'visible';

	}

	function com_(){
		//obj.btn_snd.disabled = false;
		document.querySelector('.form_loader').style.visibility = 'hidden';		
	}

	function success_(data){
		console.log(data);
		if(data == "failed"){
			obj.alert.innerHTML = "<strong>Upps!</strong> Ah ocurrido un error en tu peticion, por favor intente de nuevo mas tarde";
			obj.alert.classList.remove('alert_success');
			obj.alert.classList.add('alert_error');
		}else{
			obj.alert.innerHTML = "<strong>Felicidades!</strong> Tu registro, se ha realizado de manera exitosa, hemos enviado a tu correo un mensaje de bienvenida";
			obj.alert.classList.remove('alert_error');
			obj.alert.classList.add('alert_success');
			$('input').val('');
			$('select').val('');
		}
	}

	function success__(data){
		console.log(data);
		if(data == "failed"){
			obj.alert.innerHTML = "<strong>Upps!</strong> Ah ocurrido un error en tu peticion, por favor intente de nuevo mas tarde";
			obj.alert.classList.remove('alert_success');
			obj.alert.classList.add('alert_error');
		}else{
			//window.location = "http://localhost:8089/centerdoggy/calendar/?code="+obj.fields.codes;
		}
	}

	var events = {
		register_owner: function(e){
			e.preventDefault();
			if(obj.fields.name_user.value == "" && obj.fields.sex.value == "defult" && obj.fields.email.value == "" && obj.fields.pass.value == ""){
				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				obj.alert.classList.add('alert_error');
			}else if(obj.fields.name_user.value == ""){
				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				obj.alert.classList.add('alert_error');
			}else if(obj.fields.sex.value == "defult"){
				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				obj.alert.classList.add('alert_error');
			}else if(obj.fields.email.value == ""){
				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				obj.alert.classList.add('alert_error');
			}else if(obj.fields.pass.value == ""){
				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				obj.alert.classList.add('alert_error');
			}else{
				obj.alert.classList.remove('alert_error');
				let url_ = document.querySelector('.form_').getAttribute('action');
				let data_ = {
					code_lender:obj.fields.codes.value,
					name_lender:obj.fields.name_user.value,
					sex: obj.fields.sex.value,
					email:obj.fields.email.value,
					password:obj.fields.pass.value,
					city_owner: "no se",
					neit_owner: "no se",
					phone:0

				};  
				http_request(url_,"POST",data_,before_s,com_,success_);
			}
		},

		register_lender: function(e){
			e.preventDefault();
			if(obj.fields.name_user.value == "" && obj.fields.sex.value == "defult" && obj.fields.email.value == "" && obj.fields.pass.value == ""){
				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				obj.alert.classList.add('alert_error');
			}else if(obj.fields.name_user.value == ""){
				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				obj.alert.classList.add('alert_error');
			}else if(obj.fields.sex.value == "defult"){
				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				obj.alert.classList.add('alert_error');
			}else if(obj.fields.email.value == ""){
				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				obj.alert.classList.add('alert_error');
			}else if(obj.fields.pass.value == ""){
				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				obj.alert.classList.add('alert_error');
			}else{
				obj.alert.classList.remove('alert_error');
				let url_ = document.querySelector('.form_').getAttribute('action');
				let data_ = {
					code_lender: obj.fields.codes.value,
					name_lender:obj.fields.name_user.value,
					sex: obj.fields.sex.value,
					email:obj.fields.email.value,
					password:obj.fields.pass.value,
					city_lender: obj.fields.city.value,
					neit_lender: obj.fields.neit.value,
					phone:obj.fields.phone.value,
					rol:obj.fields.rol.value

				};  
				http_request(url_,"POST",data_,before_s,com_,success__);
			}
		}
	}


	return {
		__construct:init
	}


}());

module_.__construct();