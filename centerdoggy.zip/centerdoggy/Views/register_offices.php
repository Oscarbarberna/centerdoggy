<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon_/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header border-bottom">
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_ right-30"><div class="input_button"><a href="signin.html" class=" button_  b_notification"><i class="icon-bell"></i></a></div></li>
			<li class="list_ right-30"><a href="#" class="link_section">Jhon Murillo Mendez</a></li>		
		</ul>
	</nav>
</header>
<body>
	<div class="window_modal">
		<div class="container_select" style="height:170px;">
			<button type="button" class="btn_close">x</button>
			<p class="info_select">¿Deseas eliminar esta mascota?</p>
			<div class="container_button" style="width: 90%; display: flex; justify-content: center;">
				<div class="input_button">
					<a href="#drop" class="button_ b_green direction_info btn_delete_">Eliminar</a>
				</div>
				<div class="input_button">
					<a href="#cancel" class="button_ b_wgreen load_schedule">Cancelar</a>
				</div>
			</div>
		</div>
	</div>
	<div class="container_">
		<div class="pane_menu_navigation">
			<div class="section_logo">
				<a href="#" class="logo_portal"><i class="icon-dog-paw"></i></a>
			</div>
			<div class="navigation">
				<li class="list_"><a href="/centerdoggy/portal_admin/" class="section_"><i class="icon-home"></i></a></li>
				<li class="list_"><a href="/centerdoggy/lenders/" class="section_"><i class="icon-avatar"></i></a></li>
				<li class="list_"><a href="/centerdoggy/pets/" class="section_"><i class="icon-zynga-logotype"></i></a></li>
				<li class="list_"><a href="/centerdoggy/veterinarians_/" class="section_"><i class="icon-pet"></i></a></li>
				<li class="list_"><a href="/centerdoggy/offices_/" class="section_ active"><i class="icon-hotel"></i></a></li>
			</div>
		</div>
		<div class="content_info pane_section">
			<div class="content_title center p-x30 m_bottomx60">
				<h2 class="title_ t_green">Agrega nuevos consultorios</h2>
				<p class="info_">Administra los consultorios que estan dentro del portal</p>
			</div>
			<span class="alert_">Upps! Ha ocurrido un error dificilisimo</span>
			<div class="container_form form_center form_white form_shadow" style="width:80%;">
				<form action="/centerdoggy/register_carer/add_lender/" class="form_" method="POST">
					<div class="input_group"><input type="text" name="id_vet" id="field_vet" class="textfield field_vet" placeholder="Busca un veterinario" data-vet="0" onkeyup="search_veterinarians();"><div class="sub_options_ sub_controls_">
            		</div>
            		</div>
					<div class="input_group"><input type="text" name="address" id="field_address" class="textfield field_address" placeholder="Direccion del consultorio"></div>
					<div class="input_group"><input type="text" name="hours" id="field_hours" class="textfield field_hours" placeholder="Horas del servicio"></div>
					<div class="input_group">
						<select name="em" id="field_emergency" class="textfield field_emergency">
							<option value="default">¿Urgencias 24 horas?</option>
							<option value="Y">Si</option>
							<option value="N">No</option>
						</select>
					</div><div class="input_group">
						<select  name="home_service" id="field_servicehome" class="textfield field_servicehome">
							<option value="default">¿Consulta domiciliaria?</option>
							<option value="Y">Si</option>
							<option value="N">No</option>
						</select>
					</div>
					<div class="input_group"><input type="text" name="telefono" id=" field_phone" class="textfield field_phone" placeholder="Telefono"></div>
					<div class="input_group"><input type="text" name="email" id="field_email" class="textfield field_email" placeholder="Correo electronico"></div>
					<div class="input_group">
						<select name="ciudad" id="field_city" class="textfield field_city">
							<option value="default">Ciudad de tu ubicación</option>
							<option value="Cali">Santiago de Cali</option>
							<option value="Bogota">Bogota</option>
							<option value="Medellin">Medellin</option>
						</select>
					</div>
					<div class="input_group"><input type="text" name="barrio" id=" field_neit" class="textfield field_neit" placeholder="Barrio de influencia"></div>
					<div class="input_group">
						<div class="input_button">
							<button type="submit" class="button_ b_green btn_snd btn_send__">Guardar</button>
						</div>
					</div>
				</form>
				<div class="form_loader">
	              <div class="container_loader">
	                  <div class="bar_loader">
	                    <div class="loader"></div>
	                      <img src="<?php echo rute__folder;?>img/padlock.svg" alt="">
	                  </div>
	                  <p class="info_">Estamos registrandote...</p>
	              </div>
          		</div>
			</div>
		</div>
		
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>
		

		function choose(e){
			console.log(e);
			var id_vet = e.dataset.id;
			e.parentNode.parentNode.parentNode.children[0].value = e.textContent;
			e.parentNode.parentNode.parentNode.children[0].dataset.vet = e.dataset.id;
			console.log(e.parentNode.parentNode.parentNode.children[0]);
			document.querySelector('.sub_controls_').style.display = 'none';
		}

		function search_veterinarians(e){

			var text_to_search = document.querySelector('.field_vet').value;
			
			
			$('.sub_controls_').css({
				'display' :'block',
				'width'   : '100%',
				'left'    : '0px',
				'right'   : '0px'
			});

			if(text_to_search == "" || text_to_search.length == 0){

			}else{
				$.ajax({
					url:'/centerdoggy/veterinarians_/search_for_name/',
					type:"POST",
					data:{name:text_to_search},
					success: function(response){
						
						if(response == "empty"){
							$('.sub_controls_').html('<div class="list_option"><a href="/centerdoggy/offices/add/" class="link_" onclick="choose(this); return false;">No existen veterinarios con este nombre, intenta colocando el nombre completo</a></div>');
						}else{
							var data_ = JSON.parse(response);
							let dom = "";
							data_.map(function(item,index){
								
								dom += `<div class="list_option"><a href="/centerdoggy/offices/add/" class="link_" data-id="${item.id_vet}" onclick="choose(this); return false;">${item.nombre_completo}</a></div>`;
								
							});
							$('.sub_controls_').html(dom);
						}
						
					}
				})	
			}
			
		}


		document.querySelector('.btn_send__').addEventListener('click', function(e){
			e.preventDefault();
			var vet = document.querySelector('.field_vet'),
				address = document.querySelector('.field_address').value,
				hours = document.querySelector('.field_hours').value,
				urgency = document.querySelector('.field_emergency').value,
				home_querys = document.querySelector('.field_servicehome').value,
				phone = document.querySelector('.field_phone').value,
				email = document.querySelector('.field_email').value,
				city = document.querySelector('.field_city').value,
				neit = document.querySelector('.field_neit').value;

			if(vet.value == "" && address == "" && hours == "" && urgency == "default" && home_querys == "default" && phone == "" && email == "" && city == "" && neit == ""){

			}else if(vet.value == ""){

			}else if(address == ""){

			}else if(hours == ""){

			}else if(urgency == "default"){

			}else if(home_querys == "default"){

			}else if(phone == ""){

			}else if(email == ""){

			}else if(city == ""){

			}else if(neit == ""){

			}else{
				var data_ = new FormData();
				data_.append('id_vet',vet.dataset.vet);
				data_.append('address',address);
				data_.append('hours',hours);
				data_.append('home_service',home_querys);
				data_.append('em',urgency);
				data_.append('telefono',phone);
				data_.append('email',email);
				data_.append('ciudad',city);
				data_.append('barrio',neit);

				$.ajax({
					url:'/centerdoggy/offices_/register/',
					type:'POST',
					data:data_,
					contentType: false,
					processData: false,
					beforeSend: function(){
						document.querySelector('.form_loader').style.visibility = 'visible';
					},

					complete: function(){
						document.querySelector('.form_loader').style.visibility = 'hidden';
					},

					success: function(response){
						console.log(response);
						if(response == "failed"){

						}else{
							document.querySelector('.alert_').innerHTML = '<strong>Felicidades</strong> El consultorio de ha agregado correctamente!';
							document.querySelector('.alert_').classList.add('success');

						}
					}
				})
			}	

		});	
	</script>
</body>
</html>