<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header" style="border-bottom:1px solid #dedede; height: 80px;">
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section c_green">Premium</a></li>
			<li class="list_"><a href="#" class="link_section">Como funciona</a></li>
			<li class="list_"><a href="signin.html" class="link_section button_ b_green btn_option_user">Mi perfil</a>
				<div class="sub_options_">
                <div class="list_option">
                    <a href="/centerdoggy/profile/<?php echo $_SESSION['id_owner']; ?>" class="link_">Mis perfil</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Mis mascotas</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Configuraciones</a>
                </div>
                <div class="list_option">
                  <a href="http://localhost:8089/center_doggy/Controllers/sign_out.php?sesion_close=3" class="link_">Salir</a>
                </div>
            </div>
			</li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_">
    <div class="content_title center m_bottomx60">
        <h2 class="title_ t_green">Registrar tus mascotas</h2>
        <p class="info_">En esta sección puedes matricular a tus mascotas!</p>
      </div>
		<div class="container_info_profile">
       <div class="panel_center">
         <div class="container_form form_white" style="margin-top:3px; height:auto;">
             <form action="" class="form_ form_rgone form_view_info_user" data-url="/centerdoggy/my_pets/add_pet/">
                 <div class="input_group">
                     <input type="text" name="name_pet" id="name_pet" class="textfield name_pet">
                     <label for="name_complete" class="lb_info">Nombre de la mascota</label>
                 </div>
                 <div class="input_group">
                     <input type="date" name="date_pet" id="date_pet" class="textfield date_pet">
                     <label for="date_pet" class="lb_info">Fecha de nacimiento</label>
                 </div>
                 <div class="input_group">
                     <input type="text" name="color_pet" id="color_pet" class="textfield color_pet">
                       <label for="color_pet" class="lb_info">Color</label>
                 </div>
                 <div class="input_group">
                    <div class="input_button">
                        <input type="file" name="picture_pet" id="picture_pet" style="display: none;" class="picture_pet">  
                        <label for="picture_pet" class="button_ b_wgreen" style="cursor: pointer;">Añadir una foto</label>
                    </div>
                     <label for="code_indentify" class="lb_info" style="left:0px;">Foto</label>
                 </div>
                <!--   <div class="input_group">
                     <input type="text" name="short_description" id="short_description" class="textfield short_description" autofocus="On">
                     <label for="short_description" class="lb_info">Descripción corta</label>
                 </div> -->
                 <div class="input_group" style="top:-25px;">
                   <div class="input_button">
                     <button type="submit" class="button_ b_green btn_snd">Agregar mascota</button>
                   </div>
                 </div>
             </form>
             <div class="form_loader">
                 <div class="container_loader" style="top:60px;">
                     <div class="bar_loader">
                       <div class="loader"></div>
                         <img src="img/padlock.svg" alt="">
                     </div>
                     <p class="info_">cargando la informacion ...</p>
                 </div>
             </div>
         </div>
       </div>
     </div>
     <div class="toast">Hemos registrado tu servicio correctamente!!</div>
	</div>
    <script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
    <script>
        document.querySelector('.btn_option_user').addEventListener("click", function(e){
            e.preventDefault();
            $('.sub_options_').toggle();
        });

        var file = "img/dog_service.png";
        //add_pet
        document.querySelector('.picture_pet').addEventListener('change', e =>{
           file = this.files[0];
        });

        function toast(text){
            var t = document.querySelector('.toast');
            t.innerHTML = text;
            t.classList.add('active');

            setTimeout(function(){
                t.classList.remove('active');   
            }, 6000);
        }   
        
        document.querySelector('.btn_snd').addEventListener('click', e =>{
            e.preventDefault();
            var url      = document.querySelector('.form_view_info_user').dataset.url;
            var name     = document.querySelector('.name_pet').value;
            var date_pet = document.querySelector('.date_pet').value;
            var color    = document.querySelector('.color_pet').value;
            var picture  = file;
            
            if(name == "" && date_pet == "" && color == ""){
                console.log("emptys");
            }else if(name == ""){

            }else if(date_pet == ""){
                console.log('date empty');
            }else if(color == ""){
                console.log('color empty');
            }else{
                console.log('send data...');
                 $.ajax({
                    url:url,
                    type:"POST",
                    data:{name:name,date:date_pet,color:color,picture:file},
                    beforeSend:function(){
                        document.querySelector('.form_loader').style.visibility = 'visible';
                    },
                    complete: function(){
                        document.querySelector('.form_loader').style.visibility = 'hidden';
                    },
                    success: function(data){
                        console.log(data);
                        if(data == "failed"){

                        }else{
                            toast("<b>Felicidades!</b> Tu mascota fue registrada con exito");
                        }
                    }

                }).done(function(){
                    $('input').val('');
                });
            }
           
              
        });
        

    </script>
</body>
</html>