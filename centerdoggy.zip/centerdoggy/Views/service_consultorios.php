<?php 
session_start();

// if(isset($_SESSION['email']) || isset($_SESSION['id_user'])){
// 	//$info = $this->getinfo($_SESSION['id_user'],"owners");
// }else{
// 	header('Location: http://localhost:8089/centerdoggy/signin/');
// }


 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header" style="border-bottom:1px solid #dedede; height: 80px;">
	<a href="/centerdoggy/portal_owner/" class="logo_icono" style="position:absolute;left:15px;top:10px;z-index: 200;">
		<h1 class="name_company">PET_CENTER</h1>
	</a>
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section c_green">Premium</a></li>
			<li class="list_"><a href="#" class="link_section">reservas</a></li>
			<li class="list_"><a href="signin.html" class="link_section btn_option_user">Mi perfil</a><div class="sub_options_">
                <div class="list_option">
                    <a href="/centerdoggy/profile/<?php echo $_SESSION['id_user']; ?>/" class="link_">Mis perfil</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/my_pets/" class="link_">Mis mascotas</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Configuraciones</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/signout/close_sesion/<?php echo $_SESSION['id_user'];?>" class="link_">Salir</a>
                </div>
            </div></li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_">
		<div class="content_info pane_section">
			<div class="content_title center p-x30 m_bottomx60">
				<h2 class="title_ t_green">Serviciós en Consultorios registradas en nuestro portal</h2>
				<p class="info_">Selecciona el servicio de tu interes!</p>
			</div>
			<div class="container_search">
				<div class="input_group">
					<input type="text" name="" id="" class="textfield" placeholder="Busca a un servicio...">
				</div>
				<div class="input_button">
					<button type="button" class="button_ b_green">Buscar</button>
				</div>
			</div>
			<div class="content_info flex wrap" id="content_veterinarians" style="justify-content: center; margin-top: 80px;">
				<div class="container_table" style="box-shadow: none;">
					<div class="panel_head" style="background: none; height:45px;">
						<div class="head_table">
							<li class="list_ list_id">
								<p class="info_">ID</p>
							</li>
							<li class="list_">
								<p class="info_">Servicio</p>
							</li>
							<li class="list_">
								<p class="info_">Tipo servicio</p>
							</li>
							<li class="list_">
								<p class="info_">Horario</p>
							</li>
							<li class="list_">
								<p class="info_">Precio</p>
							</li>
							<li class="list_">
								<p class="info_">Acciones</p>
							</li>
						</div>
					</div>
					<div class="panel_body" id="pane_body">
						

					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>
		
		
		// $.post('/centerdoggy/portal_salud/consultas_consultorio/', function(response){

		// }
		fetch('/centerdoggy/portal_salud/consultas_consultorio/',{
			method:'POST'	
		})
		.then(response => {
				return response.json();
		})
		.then(result => {
			console.log(result);
			if(result.hasOwnProperty("data")){
				if(result.data == "empty"){
					console.log('No hay datos');
					document.getElementById('content_veterinarians').innerHTML = '<div style="display:block; padding:25px;"><p>Aun no has registrado tu o tus mascotas</p></div>';
				}
			}else{

				var dom = "";
				 result.map((item,index) => {
				 		dom += `<div class="list_info">
							<li class="list_ list_id">
								<p class="info_">${(index+1)}</p>
							</li>
							<li class="list_">
								<p class="info_">Domicilio</p>
							</li>
							<li class="list_">
								<p class="info_">${result[index].nombre_servicio}</p>
							</li>
							<li class="list_">
								<p class="info_">${result[index].hora_servicio}</p>
							</li>
							<li class="list_">
								<p class="info_">${result[index].precio}</p>
							</li>
							<li class="list_">
								<div class="input_button">
									<button type="button" class="button_ b_wgreen_" data-id="${result[index].id_sconsultorio}">Solicitar</button>
								</div>
							</li>
						</div>`;
				 });	
					
				document.getElementById('pane_body').innerHTML = dom;
			}


				
		});

		
		

		
		

	</script>
</body>
</html>
