<?php 
session_start();

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon/style.css">
	<link href='<?php echo rute__folder;?>fullcalendar-3.10.0/fullcalendar.min.css' rel='stylesheet' />
	<link href='<?php echo rute__folder;?>fullcalendar-3.10.0/fullcalendar.print.min.css' rel='stylesheet' media='print' />
</head>
<header class="main_header" style="border-bottom:1px solid #dedede; height: 80px;">
	<a href="/centerdoggy/portal_owner/" class="logo_icono" style="position:absolute;left:15px;top:10px;z-index: 200;">
		<h1 class="name_company">PET_CENTER</h1>
	</a>
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section c_green">Premium</a></li>
			<li class="list_"><a href="#" class="link_section">Como funciona</a></li>
			<li class="list_"><a href="signin.html" class="link_section btn_option_user btn_option_user">Mi perfil</a><div class="sub_options_">
                <div class="list_option">
                    <a href="/centerdoggy/profile/<?php echo $_SESSION['id_user']; ?>" class="link_">Mis perfil</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/my_pets/" class="link_">Mis mascotas</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Configuraciones</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/signout/close_sesion/<?php echo $_SESSION['id_user'];?>" class="link_">Salir</a>
                </div>
            </div></li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="window_modal">
		<div class="container_view_price_to_pay">
            <img src="http://localhost:8089/center_doggy/Views/img/cash.svg" alt="" class="image_price">
            <h1 class="title_">Esta es la tarifa de tu servició solicitado</h1>
            <p class="info_">No es obligación que tomes este servició, si no lo deseas hacer da click en el boton cancelar</p>
            <p class="price_">$50.000</p>
            <div class="container_button">
              <div class="input_button">
                <button type="button" class="button_ b_green btn_next_buy">Continuar</button>
              </div>
              <div class="input_button">
                <button type="button" name="button" class="button_ b_wgreen btn_close btn_cancel">Cancelar</button>
              </div>
            </div>
        </div>
	</div>
	<div class="container_" style="height:auto;">
		<div class="content_info">
			<div class="container_info_lender_current">
			<div class="container_division_info_user">
              <div class="panel_left">
                <div class="container_image"><img src="https://cdn-images-1.medium.com/fit/c/120/120/1*RjtxJVETiqFVHZiHkjuOKg.png" alt="" class="image_user"></div>
              </div>
              <div class="panel_right">
                <a href="#" class="direction_profile name_user"><?php echo $this->info_lender_current($_GET["lender"])["name_lender"]; ?></a>
                <p class="short_description_user" style="margin-bottom: 10px;">Le gusta prestar su servició con nosotros, y a nosotros tambien nos gusta la pasión y el amor que le pone a su trabajo,este prestador se desempeña en los siguientes roles</p>
                <div class="container_button">
                	<div class="input_button"><a href="#" class="button_ btn_small b_wgreen">Cuidador</a></div>
                	<div class="input_button"><a href="#" class="button_ btn_small b_wgreen">Paseador</a></div>
                	<div class="input_button"><a href="#" class="button_ btn_small b_wgreen">Grooming</a></div>
                </div>
              </div>
            </div>
		</div>
		</div>
		<span class="alert_" style="width:90%;margin:auto; margin-bottom: 30px;">Upps! Ha ocurrido un error dificilisimo</span>
		<!-- <div class="content_info"  style="height:1100px;">
			<div class="container_months">
				<button type="button" class="btn_slide btn_prev" data-direction="prev"><</button>
				<div class="slide_months">
					<li class="month_">
						<p class="month" data-month="0">Enero</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="1">
						<p class="month">Febrero</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="2">
						<p class="month">Marzo</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="3">
						<p class="month">Abril</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="4">
						<p class="month">Mayo</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="5">
						<p class="month">Junio</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="6">
						<p class="month">Julio</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="7">
						<p class="month">Agosto</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="8">
						<p class="month">Septiembre</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="9">
						<p class="month">Octubre</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="10">
						<p class="month">Noviembre</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="11">
						<p class="month">Diciembre</p>
						<p class="year_current">0</p>
					</li>
				</div>
				<button type="button" class="btn_slide btn_next" data-direction="next">></button>
			</div>
			<div class="container_calendar">
				<div class="panel_head" style="background: #fff;">
					<div class="list_days">
						<p class="name_day">Lunes</p>
					</div>
					<div class="list_days">
						<p class="name_day">Martes</p>
					</div>
					<div class="list_days">
						<p class="name_day">Miercoles</p>
					</div>
					<div class="list_days">
						<p class="name_day">Jueves</p>
					</div>
					<div class="list_days">
						<p class="name_day">Viernes</p>
					</div>
					<div class="list_days">
						<p class="name_day">Sabado</p>
					</div>
					<div class="list_days">
						<p class="name_day">Domingo</p>
					</div>
				</div>
				<div class="panel_body list_btn_days">
					
				</div>
				<div class="pane_options_select">
					<div class="li_content_option">
						<input type="checkbox" name="select_one" class="select_days" id="select_one" data-row="0">
						<label for="select_one"><i class="icon-checkmark"></i></label>
					</div>
					<div class="li_content_option">
						<input type="checkbox" name="select_two" class="select_days" id="select_two" data-row="1">
						<label for="select_two"><i class="icon-checkmark"></i></label>
					</div>
					<div class="li_content_option">
						<input type="checkbox" name="select_tree" class="select_days" id="select_tree" data-row="2">
						<label for="select_tree"><i class="icon-checkmark"></i></label>
					</div>
					<div class="li_content_option">
						<input type="checkbox" name="select_four" class="select_days" id="select_four" data-row="3">
						<label for="select_four"><i class="icon-checkmark"></i></label>
					</div>
					<div class="li_content_option">
						<input type="checkbox" name="select_five" class="select_days" id="select_five" data-row="4">
						<label for="select_five"><i class="icon-checkmark"></i></label>
					</div>
				</div>
			</div>
			<div class="container_time">
				<div class="input_group">
					<label for="" class="lb_info">Horas disponibles</label>
					<input type="tiext" name="" id="field_starttime" class="textfield field_choose_sc input_hours"data-id="0" placeholder="Horas disponibles" readonly="On" style="cursor: pointer;">
					<div class="sub_options_ sub_controls_ sub_extends sub_hours">
		                
            		</div>
				</div>
				<div class="input_group">
					<label for="" class="lb_info">Selecciona una de tus mascotas</label>
					<input type="text" name="" id="field_endtime" class="textfield field_endtime field_choose_sc input_pets" data-id="0"placeholder="Selecciona una mascota" readonly="On" style="cursor: pointer;">
					<div class="sub_options_ sub_controls_ sub_extends sub_pets">
		                
            		</div>
				</div>
			</div>
			<div class="input_group w-x70">
				<div class="input_button" style="margin-left: 10px;">
					<button type="submit" class="button_ b_green btn_send_">Solicitar servicío</button>
				</div>
			</div>
		</div> -->
		<!-- <div class="container_calendar_" style="width: 90%; margin:auto; overflow: hidden;">
			
		</div> -->
		<div class="calendar" id="calendar"></div>
		<div class="form_loader">
	         <div class="container_loader">
	               <div class="bar_loader">
	               <div class="loader"></div>
	                <img src="<?php echo rute__folder;?>img/padlock.svg" alt="">
	          </div>
	            <p class="info_">Estamos registrandote...</p>
	          </div>
        </div>
        <div class="toast">Hemos registrado tu servicio correctamente!!</div>
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script src='<?php echo rute__folder;?>fullcalendar-3.10.0/lib/moment.min.js'></script> <script src='<?php echo rute__folder;?>fullcalendar-3.10.0/lib/jquery.min.js'></script> <script src='<?php echo rute__folder;?>fullcalendar-3.10.0/fullcalendar.min.js'></script> <script>
	$(document).ready(function(){
		$('#calendar').fullCalendar({

      header: {
        left: 'prev,next today',
        center: 'title',
        right: 'month,agendaWeek,agendaDay,listWeek'
      },
      defaultDate: '2019-01-12',
      navLinks: true, // can click day/week names to navigate views
      editable: true,
      eventLimit: true, // allow "more" link when too many events
      events:  function(start, end, timezone, callback){
        $.ajax({
            url: '/centerdoggy/pruebacalendario/load_info/',
            type: 'POST',
            dataType: 'json',
            data: {
                start: start.format(),
                end: end.format()
            },
            success: function(doc) {
                var events = [];
                console.log(doc);
                if(!!doc.result){
                    
                }

               doc.map(function(item,index){
               		events.push({
	                    id: item.id_evento,
	                    title: item.titulo,
	                    start: item.date_start,
	                    end: item.date_end
                	});
               }); 	
                

                callback(events);
            }
        });
    }
    });
	});
		// var mes_text = [
		// 	 "Enero",
		// 	 "Febrero",
		// 	 "Marzo",
		// 	 "Abril",
		// 	 "Mayo",
		// 	 "Junio",
		// 	 "Julio",
		// 	 "Agosto",
		// 	 "Septiembre",
		// 	 "Octubre",
		// 	 "Noviembre", 
		// 	 "Diciembre"
		//  ];

		// var dias = ["d", "l", "m", "mi", "j", "v", "s"];
		// var days_ = ["DOMINGO","LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES", "SABADO"];
		// var fecha_calendar = new Date();
		
		
		
    	

		// function fechaPorDia(año, dia) {
 	// 			 var date = new Date(año, 0);
  // 					return new Date(date.setDate(dia));
		// }
		

		// var slide_months = 12;
		// var index = 0;

	

		// var current = "";
		
		// var ano = 0;

		// function day_week_init(boolean,current_month,direction){
			 
		// 	if(boolean == false){
		// 		ano = fecha_calendar.getFullYear();
		// 	}else{
		// 		fecha_calendar.setMonth(current_month);
				
		// 		if(mes_text[fecha_calendar.getMonth()]=="Enero"){
		// 			if(direction == "next"){
		// 				ano = fecha_calendar.getFullYear()+1;
		// 				fecha_calendar.setFullYear(fecha_calendar.getFullYear());
						
		// 				var years = document.querySelectorAll('.year_current');

		// 				for(let i of years){
		// 					i.textContent = ano;
		// 				}
		// 			}else{
		// 				//ano = ano;
		// 				ano = fecha_calendar.getFullYear();
		// 				var years = document.querySelectorAll('.year_current');

		// 				for(let i of years){
		// 					i.textContent = ano;
		// 				}
		// 			}
		// 		}else if(mes_text[fecha_calendar.getMonth()]=="Diciembre"){

		// 			if(direction == "prev"){
		// 				ano = fecha_calendar.getFullYear()-1;
		// 				fecha_calendar.setFullYear(ano);
						
		// 				var years = document.querySelectorAll('.year_current');

		// 				for(let i of years){
		// 					i.textContent = ano;
		// 				}

		// 				console.log('Prev para el retrazo de anio ' + ano);
		// 			}else{
		// 				console.log('Current year --> ' + ano + ' anio actual segun pc --> ' + fecha_calendar.getFullYear());
		// 				if(ano > fecha_calendar.getFullYear()){
		// 					console.log('si es mayor');
		// 				}else{
		// 					console.log('No es mayor');
		// 				}
		// 				//ano = fecha_calendar.getFullYear();
		// 				fecha_calendar.setFullYear(ano);

		// 				console.log('Next para el avance de anio '+ ano + ' hola ' + fecha_calendar.getFullYear());
		// 				var years = document.querySelectorAll('.year_current');

		// 				for(let i of years){
		// 					i.textContent = ano;
		// 				}
		// 			}
		// 		}else{

		// 			if(direction == "next"){
		// 				//ano = fecha_calendar.getFullYear()+1;
		// 				fecha_calendar.setFullYear(ano);
		// 				//console.log("Es momento de cambiar de anio:" + ano);
		// 				var years = document.querySelectorAll('.year_current');

		// 				for(let i of years){
		// 					i.innerText = ano;
		// 				}
		// 				console.log('Next para los demas meses ' + ano);
		// 				current = ano;
		// 			}else{
		// 				//ano = fecha_calendar.getFullYear();
		// 				//console.log('no se: ' + ano);
		// 				fecha_calendar.setFullYear(ano);
		// 				var years = document.querySelectorAll('.year_current');

		// 				for(let i of years){
		// 					i.innerText = ano;
		// 				}
		// 				console.log('Prev para los demas meses ' + ano);
		// 			}
		// 		}
				
				
				
				
				
		// 	}
			 

		// 	 var mes = fecha_calendar.getMonth()+1; //obteniendo mes
		// 	 var dia = 1;
		//      //obteniendo año
		// 	if(dia<10)
		// 		  dia='0'+dia; //agrega cero si el menor de 10
		// 	if(mes<10)
		// 		 mes='0'+mes //agrega cero si el menor de 10
		// 		 var fec = (mes+"/"+dia+"/"+ano);
		// 		 var day = new Date(fec).getDay();
		// 	return dias[day];	

		// }

		// function day_week_init_days(boolean,current_month,direction,day_init_){
			 
			 
			 
		// 	if(boolean == false){
		// 		ano = fecha_calendar.getFullYear();
		// 	}else{
		// 		fecha_calendar.setMonth(current_month);
				
		// 		if(mes_text[fecha_calendar.getMonth()]=="Enero"){
		// 			if(direction == "next"){
		// 				ano = fecha_calendar.getFullYear()+1;
		// 				fecha_calendar.setFullYear(fecha_calendar.getFullYear());
						
		// 				var years = document.querySelectorAll('.year_current');

		// 				for(let i of years){
		// 					i.textContent = ano;
		// 				}
		// 			}else{
		// 				//ano = ano;
		// 				ano = fecha_calendar.getFullYear();
		// 				var years = document.querySelectorAll('.year_current');

		// 				for(let i of years){
		// 					i.textContent = ano;
		// 				}
		// 			}
		// 		}else if(mes_text[fecha_calendar.getMonth()]=="Diciembre"){

		// 			if(direction == "prev"){
		// 				ano = fecha_calendar.getFullYear()-1;
		// 				fecha_calendar.setFullYear(ano);
						
		// 				var years = document.querySelectorAll('.year_current');

		// 				for(let i of years){
		// 					i.textContent = ano;
		// 				}

		// 				console.log('Prev para el retrazo de anio ' + ano);
		// 			}else{
		// 				console.log('Current year --> ' + ano + ' anio actual segun pc --> ' + fecha_calendar.getFullYear());
		// 				if(ano > fecha_calendar.getFullYear()){
		// 					console.log('si es mayor');
		// 				}else{
		// 					console.log('No es mayor');
		// 				}
		// 				//ano = fecha_calendar.getFullYear();
		// 				fecha_calendar.setFullYear(ano);

		// 				console.log('Next para el avance de anio '+ ano + ' hola ' + fecha_calendar.getFullYear());
		// 				var years = document.querySelectorAll('.year_current');

		// 				for(let i of years){
		// 					i.textContent = ano;
		// 				}
		// 			}
		// 		}else{

		// 			if(direction == "next"){
		// 				//ano = fecha_calendar.getFullYear()+1;
		// 				fecha_calendar.setFullYear(ano);
		// 				//console.log("Es momento de cambiar de anio:" + ano);
		// 				var years = document.querySelectorAll('.year_current');

		// 				for(let i of years){
		// 					i.innerText = ano;
		// 				}
		// 				console.log('Next para los demas meses ' + ano);
		// 				current = ano;
		// 			}else{
		// 				//ano = fecha_calendar.getFullYear();
		// 				//console.log('no se: ' + ano);
		// 				fecha_calendar.setFullYear(ano);
		// 				var years = document.querySelectorAll('.year_current');

		// 				for(let i of years){
		// 					i.innerText = ano;
		// 				}
		// 				console.log('Prev para los demas meses ' + ano);
		// 			}
		// 		}
				
				
				
				
				
		// 	}
			 

			 

		// 	 var mes = fecha_calendar.getMonth()+1; //obteniendo mes
		// 	 var dia = day_init_;
		//      //obteniendo año
		// 	if(dia<10)
		// 		  dia='0'+dia; //agrega cero si el menor de 10
		// 	if(mes<10)
		// 		 mes='0'+mes //agrega cero si el menor de 10
		// 		 var fec = (mes+"/"+dia+"/"+ano);
		// 		 var day = new Date(fec).getDay();
		// 	return dias[day];	
		// }

		// function get_limit_run(day__){

		// 	var size_d = 0;

		// 	switch (day__) {
		// 		case "l":
		// 			size_d = 1;
		// 			break;
		// 		case "m":
		// 			size_d = 2;
		// 			break;
		// 		case "mi":
		// 			size_d = 3;
		// 			break;
		// 		case "j":
		// 			size_d = 4;
		// 			break;
		// 		case "v":
		// 			size_d = 5;
		// 			break;	
		// 		case "s":
		// 			size_d = 6;
		// 			break;
		// 		case "d":
		// 			size_d = 7;
		// 			break;					
		// 		default:
		// 			size_d = 0;
		// 			break;
		// 	}
				
		// 	return size_d;	
		// }

		// function get_total_days_months(modify,position_month){
			
		// 	let size_days = 0;
		// 	let new_date = 0;

		// 	if(modify == true){
		// 		fecha_calendar.setMonth(position_month);
		// 	}
		// 	if(mes_text[fecha_calendar.getMonth()] == "Enero" || mes_text[fecha_calendar.getMonth()] == "Marzo" || mes_text[fecha_calendar.getMonth()] == "Mayo" || mes_text[fecha_calendar.getMonth()] == "Julio" || mes_text[fecha_calendar.getMonth()] == "Enero" || mes_text[fecha_calendar.getMonth()] == "Agosto" || mes_text[fecha_calendar.getMonth()] == "Octubre" || mes_text[fecha_calendar.getMonth()] == "Diciembre"){
		// 		size_days = 32;
		// 	}else if(mes_text[fecha_calendar.getMonth()] == "Abril" || mes_text[fecha_calendar.getMonth()] == "Junio" || mes_text[fecha_calendar.getMonth()] == "Septiembre" || mes_text[new Date().getMonth()] == "Noviembre"){
		// 		size_days = 31;
				
		// 	}else{
		// 		size_days = 29;
		// 	}
			
		// 	return size_days;
		// }

		// var years = document.querySelectorAll('.year_current');

		// 	for(let i of years){
		// 		i.textContent = fecha_calendar.getFullYear();
		// 	}
		
		// function getParameterByName(name){
		//     name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
		//     var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
		//     results = regex.exec(location.search);
		//     return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
		// }

		// function render_day_init(day_init_){
		// 	 var mes = fecha_calendar.getMonth()+1; //obteniendo mes
		// 	 var dia = day_init_;
		//      //obteniendo año
		// 	if(dia<10)
		// 		  dia='0'+dia; //agrega cero si el menor de 10
		// 	if(mes<10)
		// 		 mes='0'+mes //agrega cero si el menor de 10
		// 		 var fec = (mes+"/"+dia+"/"+ano);
		// 		 var day = new Date(fec).getDay();
		// 	return days_[day];
		// }

		// function writeMonth(boolean,init_day,init_month){
		// 	var table_content_months = document.querySelector('.list_btn_days');
		// 	var all_months 			 = document.querySelectorAll('.month_');
		// 	var size                 = get_limit_run(init_day);
		// 	var size_months          = (boolean == true) ? get_total_days_months(true,init_month) : get_total_days_months(false,0);
		// 	var dom  				 = "";
		// 	table_content_months.innerHTML = "";
			
		// 	for(let ji = 0; ji < all_months.length; ji++ ){
		// 			if(all_months[ji].getAttribute('data-month') == fecha_calendar.getMonth()){
		// 				index = ji;
		// 				$('.slide_months').animate({
		// 					'margin-left':'-'+index+'00%'
		// 				});
		// 			}
		// 	}

		// 	for(let i = 1; i < size; i++){
		// 		table_content_months.innerHTML += `<div class="list_days box_day"><a href="#" class="btn_day day_nactive" data-day="0" onclick="choose_day_service(this); return false;"></a></div>`;	
		// 	}

		// 	for(let j = 1; j < size_months; j++){
		// 		table_content_months.innerHTML += `<div class="list_days box_day"><a href="#" class="btn_day day_active" data-day="${j}" onclick="choose_day_service(this); return false;"><p class="number_day">${j}</p><span class="days_disabled_">ocupado</span></a></div>`;		
						
		// 	}

			
			
			
		// 	fetch('/centerdoggy/calendar_lender/getschedule_current_lender/'+getParameterByName("lender")+'/',{
		// 		method:'GET'

		// 	})
		// 	.then(response => {
		// 		return response.json();
		// 	})
		// 	.then(result => {
		// 		var cont = 0;
				
				
		// 		var current_day = new Date().getDate();
			
		// 		var contador = 1;
		// 		for(let i =0; i < document.querySelectorAll(".day_active").length; i++){

					
		// 			document.querySelectorAll('.btn_day')[i].dataset.day = contador;
		// 			contador++;
		// 			if(document.querySelectorAll('.btn_day')[i].dataset.day < current_day){
		// 				document.querySelectorAll('.day_active')[i].classList.add('day_disabled');		
		// 			}
					
		// 			if(document.querySelectorAll('.btn_day')[i].dataset.day == current_day){
		// 				document.querySelectorAll('.day_active')[i].classList.add('day_current');
		// 			}

		// 			for(let j = 0; j < result.length; j++){
						
		// 				if(days_[result[j].day_week] == render_day_init((contador-1))){
							
		// 					document.querySelectorAll('.btn_day')[contador+1].classList.add('day_select');
		// 				}	
		// 			}
		
		// 		}
				
		// 	});


			


		// }

		
		// writeMonth(false,day_week_init(false,0),0);
		
		// function slidemonths(direction,child){

		// 	index = (direction == "next") ? index + 1 : index - 1;
		// 	index = (index >= slide_months) ?  0 : index;
		// 	index = (index < 0) ? slide_months-1 : index;
			
			
		// 	$('.slide_months').animate({
		// 		'margin-left':'-'+index+'00%'
		// 	});	
			
		// 	var date_ = new Date();
		// 	date_.setMonth(index)
			
		// 	writeMonth(true,day_week_init(true,index,direction),index);
		// }
		// $('.btn_slide').on('click', function(e){
		// 	e.preventDefault();
			
		// 	slidemonths($(this).attr('data-direction'));

		// });


		// function iterator_days(items,init,final,action){
		// 	if(action == 'enabled'){
		// 		var valid = false;
		// 		for(let count = init; count < final; count++ ){

		// 			try {
		// 				if(typeof(items[count].children[0]) != "undefined"){
		// 					valid = true;
		// 				}
		// 			} catch(e) {
		// 				valid = false;
		// 			}

		// 			if(valid==true){
		// 				items[count].children[0].classList.add('day_select');	
		// 			}
					
					
		// 		}
		// 	}else{
		// 		for(let count = init; count < final; count++ ){
					
		// 			try {
		// 				if(typeof(items[count].children[0]) != "undefined"){
		// 					valid = true;
		// 				}
		// 			} catch(e) {
		// 				valid = false;
		// 			}

		// 			if(valid==true){
		// 				items[count].children[0].classList.remove('day_select');	
		// 			}
						
		// 		}
		// 	}
			
			
		// }

		// function choose_all_rows(index,action){

		// 	var all_days = document.querySelectorAll('.box_day');
		// 	var indice = (7*index);

		// 	if(index == 0){
		// 		iterator_days(all_days,indice,7,action);
		// 	}else if(index == 1){
		// 		iterator_days(all_days,indice,7*2,action);
		// 	}else if(index == 2){
		// 		iterator_days(all_days,indice,7*3,action);
		// 	}else if(index == 3){
		// 		iterator_days(all_days,indice,7*4,action);
		// 	}else if(index == 4){
		// 		iterator_days(all_days,indice,7*5,action);
		// 	}else{
				
		// 	}
			
		// }


		// $.each($('.select_days'), function(iterator,item){
		// 	$(item).on('change', function(){
		// 		if($(item).prop('checked')){
		// 			$(item).parent().children('label').css('background','#41BB5F');
		// 			choose_all_rows($(item).attr('data-row'),'enabled');
		// 		}else{
		// 			$(item).parent().children('label').css('background','#FFF');
		// 			choose_all_rows($(item).attr('data-row'),'disabled');
		// 		}
		// 	});
		// });

		

		// var contador = "";
		// var days_init = "";

		

		// document.querySelector('.btn_option_user').addEventListener("click", function(e){
		// 	e.preventDefault();
		// 	$('.sub_options_').toggle();
		// });

		

		// document.querySelector('.btn_close').addEventListener('click', function(e){
		// 	e.preventDefault();
		// 	document.querySelector('.window_modal').style.visibility = "hidden";
			
		// 	//
		// });

		// document.querySelector('.btn_cancel').addEventListener('click', function(e){
		// 	e.preventDefault();
		// 	document.querySelector('.window_modal').style.visibility = "hidden";
			
		// 	//
		// });

		// var showSubmenu = function(){
			
		// 	this.parentNode.children[2].style.display = 'block';
		// };


		// [].forEach.call(document.querySelectorAll('.field_choose_sc'),fields => {
		// 	// statements
		// 	fields.addEventListener('focus', showSubmenu);
			
		// });
		
		// var hideSubmenu = function(e){
		// 	e.parentNode.parentNode.parentNode.children[1].value = e.innerText;
		// 	e.parentNode.parentNode.parentNode.children[1].dataset.id = e.dataset.day;
		// 	e.parentNode.parentNode.style.display = 'none';
		// 	//console.log(e);
		// };

		// var render = function(month,day){
		// 	 var data = "";
		// 	 var id_current_lender = "";
		// 	 var day_current_ = "";
		// 	 const pane_ = document.querySelector('.sub_hours');
			 
		// 	if(month == "default" && day == "default"){
		// 		 data = new FormData();
		// 		 id_current_lender = getParameterByName('lender');
		// 		 day_current_ = render_day_init(new Date().getDate());
		// 		 data.append('id_lender',id_current_lender);
		// 		 data.append('month',(index+1));
		// 		 data.append('day',day_current_); 
		// 	}else{
		// 		data = new FormData();
		// 		id_current_lender = getParameterByName('lender');
		// 		day_current_ = render_day_init(day);
		// 		data.append('id_lender',id_current_lender);
		// 		data.append('month',(index+1));
		// 		data.append('day',day_current_); 
		// 	}

		// 	fetch('/centerdoggy/calendar_lender/getschedule_hours_days_available/',{
		// 		method:'POST',
		// 		body:data

		// 	})
		// 	.then(response => {
		// 		return response.text();
		// 	})
		// 	.then(result => {
		// 		//console.log(result);
		// 		if(result == "empty"){

		// 		}else{
		// 			var data = JSON.parse(result);
		// 			var dom = "";
		// 			data.map((item,index) => {
		// 				//console.log(item.range_time);
		// 				dom += `<div class="list_option">
		//                     		<a href="#" class="link_ days_choosed hour_choosed" data-day="${item.id_schedule}" onclick="hideSubmenu(this); return false;">${item.range_time}</a>
		//                       </div>`;
		//                  if(index == 0){
		//                  	document.querySelector('.input_hours').value = item.range_time;
		//                  }
		// 			});

		// 			pane_.innerHTML = dom;
		// 		}
				
		// 	});
		// }

		// render("default","default");
			 	
		// const panedos_ = document.querySelector('.sub_pets');
		// 	fetch('/centerdoggy/calendar_lender/load_all_pets/',{
		// 		method:'GET'

		// 	})
		// 	.then(response => {
		// 		return response.text();
		// 	})
		// 	.then(result => {
		// 		//console.log(result);
		// 		if(result == "empty"){

		// 		}else{
		// 			var data = JSON.parse(result);
		// 			var dom = "";
		// 			data.map((item,index) => {
		// 				console.log(item.name_pet);
		// 				dom += `<div class="list_option">
		//                     		<a href="#" class="link_ days_choosed pet_choosed" data-day="${item.id_pet}" onclick="hideSubmenu(this); return false;">${item.name_pet}</a>
		//                       </div>`;
		//                 if(index == 0){
		//                  	document.querySelector('.input_pets').value = item.name_pet;
		//                  }      
		// 			});

		// 			panedos_.innerHTML = dom;
		// 		}
				


				
		// 	});	

		// 	[].forEach.call(document.querySelectorAll('.hour_choosed'), btn_days => {
		// 		// statements
		// 		btn_days.addEventListener('click',hideSubmenu);
		// 	});

		// 	[].forEach.call(document.querySelectorAll('.pet_choosed'), btn_range => {
		// 		// statements
		// 		btn_range.addEventListener('click',hideSubmenu_);
		// 	});
		// 	var day = 0;

		// 	function choose_day_service(e){
		// 		console.log(e.getAttribute("class"));
		// 		day = 0;
		// 		if(e.getAttribute("class") == "btn_day day_active day_disabled day_select" || e.getAttribute("class") == "btn_day day_active day_disabled"){
		// 			console.log("No se puede seleccionar ese dia");
		// 		}else if(e.getAttribute("class") ==  "btn_day day_active day_ydisabled day_current day_select" || e.getAttribute("class") == "btn_day day_active day_current day_select day_ydisabled" || e.getAttribute("class") == "btn_day day_active day_ydisabled"){
		// 			console.log("Este dia esta ocupado");
		// 			document.querySelector('.window_modal').style.visibility = "visible";
		// 			var dom = "";
					
					
		// 		}else{

		// 			[].forEach.call(document.querySelectorAll('.btn_day'),BTN_ => {
		// 				if(BTN_.className == "btn_day day_active day_current day_selected" || BTN_.className == "btn_day day_active day_selected"){
		// 					BTN_.classList.remove('day_selected');
		// 				}
		// 			});
		// 			e.classList.add('day_selected');
		// 			day = e.children[0].innerHTML;
		// 			render("default",day);
					

		// 		}
		// 	};

		// 	var hours = 0,
		// 		pet = 0,
		// 		date_current_ = 0; 	
		// 	document.querySelector('.btn_send_').addEventListener('click', function(e){
		// 	e.preventDefault();
		// 	contador = "";
		// 	days_init = "";
		// 	hours 	   = document.querySelector('.input_hours').dataset.id;
		// 	pet   = document.querySelector('.input_pets').dataset.id;
		// 	day_current_ = 0;
		// 	if(hours == 0 && pet == 0){

		// 	}else if(hours == 0){

		// 	}else if(pet == 0){

		// 	}else{
		// 		//console.log(hours + " - " + pet);
		// 		date_current_ = day+'/'+(index+1)+'/'+new Date().getFullYear();
		// 		document.querySelector('.window_modal').style.visibility = 'visible';
		// 		document.querySelector('.container_view_price_to_pay').classList.add('view_price_active');
				
		// 	}
			
			
			
		// });

		// function toast(){
		// 	var t = document.querySelector('.toast');
		// 	t.classList.add('active');
		// 	setTimeout(function(){
		// 		t.classList.remove('active');	
		// 	}, 6000);
		// }	

		// document.querySelector('.btn_next_buy').addEventListener('click', e => {
		//    e.preventDefault();
		//    document.querySelector('.window_modal').style.visibility = 'hidden';
		//    document.querySelector('.container_view_price_to_pay').classList.remove('view_price_active');
		//    var id_s = getParameterByName('service');
		//    $.ajax({
		// 		url:"/centerdoggy/calendar_lender/add_schedule_service/",
		// 		type:"POST",
		// 		data:{id_pet:pet,day:date_current_,id_suser:hours,id_service:id_s},
		// 		beforeSend: function(){
		// 			$('.form_loader').css('visibility','visible');
		// 		},

		// 		complete: function(){
		// 			$('.form_loader').css('visibility','hidden');
		// 		},
		// 		success: function(response){
		// 			console.log(response);
					
		// 			if(response == "failed"){
		// 				document.querySelector('.alert_').innerHTML = "<strong>Upps!</strong> Se ha producido un error al agendar tu solicitud, por favor vuelva e intenta mas tarde";
		// 				document.querySelector('.alert_').classList.remove('alert_success');
		// 				document.querySelector('.alert_').classList.add('alert_error');
		// 			}else{
		// 				document.querySelector('.alert_').innerHTML = "<strong>Felicidades!</strong> Hemos agendado tu servició exitosamente";
		// 				document.querySelector('.alert_').classList.remove('alert_error');
		// 				document.querySelector('.alert_').classList.add('alert_success');
		// 				toast();
		// 				//window.location = response;
		// 			}
		// 		}

		// 	});
	 //    });
	</script>
	<style>

  body {
   
    padding: 0;
    font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
    font-size: 14px;
  }

  #calendar {
    max-width: 900px;
    margin: 0 auto;
  }

</style>
</body>
</html>