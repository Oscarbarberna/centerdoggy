<?php 
session_start();

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header" style="border-bottom:1px solid #dedede; height: 80px;">
  <a href="<?php $destino = ($_SESSION['location'] == 'admin') ? '/centerdoggy/lenders/' : '/centerdoggy/portal_lenders/'; echo $destino; ?>" type="button" class="btn_prev"><svg width="44" height="44" viewBox="0 0 24 24" class="mc-icon mc-icon-template-stateless mc-icon-template-stateless--right left-icon spectrum-hack-rotate-icon" style="transform: rotate(180deg);"><path d="M10.414 7.05l4.95 4.95-4.95 4.95L9 15.534 12.536 12 9 8.464z" fill="#637282" fill-rule="evenodd"></path></svg></a>
  <h3 class="title_section">Horario del usuario</h3>
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section c_green">Premium</a></li>
			<li class="list_"><a href="#" class="link_section">reservas</a></li>
			<li class="list_"><a href="signin.html" class="link_section button_ b_green btn_option_user">Mi perfil</a>
				    <div class="sub_options_ sub_user">
                <div class="list_option">
                    <a href="/centerdoggy/profile/view/<?php echo $_SESSION['id_user']; ?>/" class="link_">Mis perfil</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/my_pets/" class="link_">Mis mascotas</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Configuraciones</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/signout/close_sesion/<?php echo $_SESSION['id_user']; ?>/" class="link_">Salir</a>
                </div>
            </div>
			</li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_">
    <div class="container_info_profile">
      <div class="container_center_">
        <div class="container_info_lender_current" style="margin-top: 10px; width: 75%;">
                <div class="container_division_info_user">
                  <div class="panel_left">
                    <div class="container_image"><img src="http://localhost:8089/centerdoggy/Views/<?php echo $this->get_info_owner()['picture']; ?>" alt="" class="image_user"></div>
                  </div>
                  <div class="panel_right">
                    <a href="#" class="direction_profile name_user"><?php echo $this->get_info_lenders()["name_lender"]; ?></a>
                    <p class="short_description_user" style="margin-bottom: 10px;">Este prestador es apasionado y ama lo que hace, por eso te lo recomendamos para los serviciós</p>
                    </div>
                  </div>
            </div>
         <div class="panel_body" > 
         	<div class="container_calendar" style="margin-bottom: 25px; border-bottom: 1px solid #dedede; padding-bottom: 20px;width:80%; left:45px;">
				<div class="panel_head" style="border-bottom: 1px solid transparent; margin-top: 14px; letter-spacing: 0;px; background: #fff;">
					<div class="list_days">
						<div class="input_button">
							<button class="button_ b_wgreen b_wgreen_" data-day="1-">Lunes</button>
						</div>
					</div>
					<div class="list_days">
						<div class="input_button">
							<button class="button_ b_wgreen b_wgreen_" data-day="-2">Martes</button>
						</div>
					</div>
					<div class="list_days">
						<div class="input_button">
							<button class="button_ b_wgreen b_wgreen_" data-day="-3">Miercoles</button>
						</div>
					</div>
					<div class="list_days">
						<div class="input_button">
							<button class="button_ b_wgreen b_wgreen_" data-day="-4">Jueves</button>
						</div>
					</div>
					<div class="list_days">
						<div class="input_button">
							<button class="button_ b_wgreen b_wgreen_" data-day="-5">Viernes</button>
						</div>
					</div>
					<div class="list_days">
						<div class="input_button">
							<button class="button_ b_wgreen b_wgreen_" data-day="-6">Sabado</button>
						</div>
					</div>
					<div class="list_days">
						<div class="input_button">
							<button class="button_ b_wgreen b_wgreen_" data-day="-6">Domingo</button>
						</div>
					</div>
				</div>
			</div>
         </div>
         <div class="content_info"  style="height:620px; padding-bottom: 10px;">
			
			<div class="container_time">
				<div class="input_group" style="width: 290px;">
					<label for="" class="lb_info">Desde</label>
					<input type="text"  name="" id="start_time" class="textfield  start_time" data-id="0" placeholder="0:00">
					
				</div>
				<div class="input_group" style="width: 290px;">
					<label for="" class="lb_info">Hasta</label>
					<input type="text"  name="" id="field_endtime" class="textfield  end_time" data-id="0" placeholder="0:00">
					
				</div>
			</div>
			<div class="input_group w-x70" style="margin:auto; left: -5px;">
				<div class="input_button" style="display: block;">
					<button type="submit" class="button_ b_green btn_send_">Editar</button>
				</div>
			</div>
		</div>
      </div>
       
     </div>
  </div>
  <script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
  <script>
    
    var state = 0;

    function show_info(time_star,time_end){
    	if(time_star.split(':')[0] < 10){
    		document.querySelector('.start_time').value = '0'+time_star;
    		console.log('0'+time_star);
    		document.querySelector('.end_time').value = '0'+time_end;	
    	}else{
    		document.querySelector('.start_time').value = time_star;
    		document.querySelector('.end_time').value = time_end;
    	}
    	
    	
    }

    function remove_style(items){
    	let list_days = document.querySelectorAll('.list_days');
    	let size = list_days.length;
    	for (var i = 0; i < size; i++) {
    		list_days[i].children[0].children[0].style.background = '#fff';
    		list_days[i].children[0].children[0].style.color = '#41BB5F';
    	}
    }
    var load_hours_working = function(e){
    	console.log(this.children[0].children[0].dataset.day.replace('-',' '));
    	let day_ = this.children[0].children[0].dataset.day.replace('-',' ');

    	if(state == 0){
    		this.children[0].children[0].style.background = '#41BB5F';
    		this.children[0].children[0].style.color = '#fff';
    		state = 1;	
    	}else{
    		state = 0;
    		this.children[0].children[0].style.background = '#fff';
    		this.children[0].children[0].style.color = '#41BB5F';
    		remove_style();
    	}
    	
    	$.post('/centerdoggy/profile/load_horario',{day:day_},
    		function(data){
    				
    				if(data == "indefined" || data == null){
    						console.log('hola');
    				}else{
    					let info = JSON.parse(data);
    					console.log(info[0].range_time.split('-')[0].replace(' AM',' ').replace(' PM',' '));
    					let time_ini = info[0].range_time.split('-')[0];
    					let time_end = info[info.length-1].range_time.split('-')[1].replace(" ",'');
    					show_info(time_ini,time_end);
    				}
    		});
    };

    function event_days_working(){
    	let list_days = document.querySelectorAll('.list_days');
    	let size = list_days.length;

    	for (var i = 0; i < size; i++) {
    		list_days[i].addEventListener('click',load_hours_working);
    	}
    }

    event_days_working();

    // document.querySelector('.btn_edit_').addEventListener("click", e=>{
    //   e.preventDefault();
    //   const URL = form.getAttribute("action");
    //   let data = new FormData($('.form_view_info_user')[0]);
    //   data.append('id_user',id_vet());
    //   console.log(data.get("code_us"));

    //   if(validarInputs()){

    //      $.ajax({
    //         url:URL,
    //         type:"POST",
    //         data:data,
    //         processData:false,
    //         cache:false,
    //         contentType: false,
    //         beforeSend: function(){

    //         },
    //         complete: function(){

    //         },

    //         success: function(response){
    //           console.log(response);
    //         }
    //      }) 
    //   }else{
    //     console.log("campos incompletos...");
    //   }
    // });
  </script>
</body>
</html>
