<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon/style.css">
</head>
<!-- <header class="main_header">
	<a href="/centerdoggy/" class="logo_icono" style="position:absolute;left:15px;top:10px;z-index: 200;">
		<h1 class="name_company">PET_CENTER</h1>
	</a>
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="/centerdoggy/" class="link_section">Nuestros servicios</a></li>
			<li class="list_"><a href="/centerdoggy/" class="link_section">Como funciona</a></li>
			<li class="list_"><div class="input_button"><a href="/centerdoggy/signin/" class=" button_ b_green">Iniciar Sesión</a></div></li>
			
		</ul>
	</nav>
</header> -->
<body>
	<div class="container_ bg_container_gray ">
		<div class="content_info mb-x50">
			<span class="alert_">Upps! Ha ocurrido un error dificilisimo</span>
			<h1 class="title_center_ borderb">¿Quieres prestar tus servicio?</h1>
			<p class="description_center_">Te invitamos a que hagas parte de nosotros sin ningun costo y de una manera sencilla</p>
			<div class="container_form form_center form_white form_shadow w-x50 ">
				<form action="/centerdoggy/register_carer/add_lender/" class="form_" method="POST">
					<div class="division_fields">
						<div class="input_group"><input type="text" name="" id="field_codes" class="textfield field_codes" placeholder="CC:"></div>
					<div class="input_group"><input type="text" name="" id="field_name" class="textfield field_name" placeholder="Nombre y apellido"></div>
					</div>
					<div class="input_group">
						<select name="" id="field_sex" class="textfield field_sex">
							<option value="default">Selecciona tu sexo</option>
							<option value="Hombre">Hombre</option>
							<option value="Mujer">Mujer</option>
						</select>
					</div>
					<div class="division_fields">	
						<div class="input_group"><input type="text" name="" id=" field_phone" class="textfield field_phone" placeholder="Telefono celular"></div>
						<div class="input_group"><input type="text" name="" id="field_email" class="textfield field_email" placeholder="Correo electronico"></div>
					</div>
					<div class="input_group"><input type="password" name="" id=" field_password" class="textfield field_password" placeholder="Password"></div>
					<div class="input_group" style="display: flex; align-items: center;">
						<div class="input_checkbox input_auto" style="visibility: visible;"><input type="checkbox" name="select_one" class="select_days_" id="select_one" data-rol="-1"><label for="select_one" class="checkbox_"><i class="icon-checkmark"></i></label>Cuidador</div>
						<div class="input_checkbox input_auto" style="visibility: visible;"><input type="checkbox" name="select_one" class="select_days_" id="select_two" data-rol="-2"><label for="select_two" class="checkbox_"><i class="icon-checkmark"></i></label>Paseador</div>
						<div class="input_checkbox input_auto" style="visibility: visible;"><input type="checkbox" name="select_one" class="select_days_" id="select_three" data-rol="-3"><label for="select_three" class="checkbox_"><i class="icon-checkmark"></i></label>Grooming</div>
						<!-- <select name="" id=" field_rol" class="textfield field_rol">
							<option value="1">Cuidador</option>
		                    <option value="2">Paseador</option>
		                    <option value="3">Spa Grooming</option>
		                    <option value="4">Ciudador, Paseador, Grooming</option>
		                    <option value="5">Paseador, Grooming</option>
		                    <option value="6">Ciudador, Grooming</option>
		                    <option value="8">Ciudador, Paseador</option>
						</select> -->
					</div>
					<div class="division_fields">	
						<div class="input_group">
									<select name="" id="field_city" class="textfield field_city">
											<option value="default">Ciudad de tu ubicación</option>
											<option value="Cali">Santiago de Cali</option>
											<option value="Bogota">Bogota</option>
											<option value="Medellin">Medellin</option>
									</select>
						</div>
						<div class="input_group"><input type="text" name="" id=" field_neit" class="textfield field_neit" placeholder="Barrio de influencia"></div>
					</div>
					<div class="input_group">
						<div class="input_button">
							<button type="submit" class="button_ b_green btn_snd btn_send__">Registrarme</button>
						</div>
					</div>
				</form>
				<div class="form_loader">
	              <div class="container_loader">
	                  <div class="bar_loader">
	                    <div class="loader"></div>
	                      <img src="<?php echo rute__folder;?>img/padlock.svg" alt="">
	                  </div>
	                  <p class="info_">Estamos registrandote...</p>
	              </div>
          		</div>
			</div>
		</div>
		<div class="content_info bg_gray bg_container_gray">
			<footer class="footer">
				<div class="pane_info">
					<a href="#" class="logo_icono">
						<h1 class="name_company">PET_CENTER</h1>
					</a>
					<p class="short_info">Derechos reservados 2018 SeitConsultores. Hecho con ♥ en Colombia</p>
				</div>
				<div class="pane_info pane_division">
					<div class="panes_">
						<h4 class="type_">Producto</h4>
						<li class="list_option"><a href="#" class="section">¿Por que Pet_center?</a></li>
						<li class="list_option"><a href="#" class="section">Planes y precios</a></li>
					</div>
					<div class="panes_">
						<h4 class="type_">Recursos</h4>
						<li class="list_option"><a href="#" class="section">Centro de ayuda</a></li>
						<li class="list_option"><a href="#" class="section">Guias</a></li>
					</div>
					<div class="panes_">
						<h4 class="type_">Compañia</h4>
						<li class="list_option"><a href="#" class="section">Acerca de</a></li>
						<li class="list_option"><a href="#" class="section">Empleo</a></li>
					</div>
				</div>
			</footer>
		</div>
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>	
	<script src="<?php echo rute__folder;?>js/module_init.js"></script>
</body>
</html>