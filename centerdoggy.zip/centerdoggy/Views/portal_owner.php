<?php 
// session_start();

// if(isset($_SESSION['email']) || isset($_SESSION['id_user'])){
// 	$info = $this->getinfo($_SESSION['id_user'],"owners");
// }else{
// 	header('Location: http://localhost:8089/centerdoggy/signin/');
// }


 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header" style="border-bottom:1px solid #dedede; height: 80px;">
	<a href="/centerdoggy/portal_owner/" class="logo_icono" style="position:absolute;left:15px;top:10px;z-index: 200;">
		<h1 class="name_company">PET_CENTER</h1>
	</a>
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section c_green">Premium</a></li>
			<li class="list_"><a href="#" class="link_section">reservas</a></li>
			<li class="list_"><a href="signin.html" class="link_section btn_option_user">Mi perfil</a><div class="sub_options_">
                <div class="list_option">
                    <a href="/centerdoggy/profile/<?php echo $_SESSION['id_user']; ?>/" class="link_">Mis perfil</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/my_pets/" class="link_">Mis mascotas</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Configuraciones</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/signout/close_sesion/<?php echo $_SESSION['id_user'];?>" class="link_">Salir</a>
                </div>
            </div></li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_">
		<div class="content_info">
			<div class="content_title center p-x30 m_bottomx60">
				<h2 class="title_ t_green">Hola <strong style="color:#898989;"><?php echo $mensaje = (isset($info["name_owner"])) ? info["name_owner"] : ""; ?></strong> Bienvenido</h2>
				<p class="info_">Estos son los disponibles dentro de pet_center, disfrutalos!</p>
			</div>
			<div class="content_box flex">
				<a href="/centerdoggy/lenders_/?type_service=paseador&nsrv=2" class="box_">
					<div class="box_info  box_service">
					<img src="<?php echo rute__folder;?>img/collar.png" alt="" class="image_">
					<h3 class="title_info">Paseador</h3>
					</div>
				</a>
				<a href="/centerdoggy/lenders_/?type_service=cuidador&nsrv=1" class="box_">
					<div class="box_info  box_service">
					<img src="<?php echo rute__folder;?>img/food_dog.png" alt="" class="image_">
					<h3 class="title_info">Cuidador</h3>
					</div>
				</a>
				<a href="/centerdoggy/lenders_/?type_service=grooming&nsrv=3" class="box_">
					<div class="box_info  box_service">
					<img src="<?php echo rute__folder;?>img/grooming_dog.png" alt="" class="image_">
					<h3 class="title_info">Grooming</h3>
					</div>
				</a>
			</div>
		</div>
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>
		document.querySelector('.btn_option_user').addEventListener("click", function(e){
			e.preventDefault();
			$('.sub_options_').toggle();
		});
	</script>
</body>
</html>