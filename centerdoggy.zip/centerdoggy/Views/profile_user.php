<?php 
session_start();

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header" style="border-bottom:1px solid #dedede; height: 80px;">
  <a href="<?php $destino = ($_SESSION['location'] == 'admin') ? '/centerdoggy/lenders/' : '/centerdoggy/portal_lenders/'; echo $destino; ?>" type="button" class="btn_prev"><svg width="44" height="44" viewBox="0 0 24 24" class="mc-icon mc-icon-template-stateless mc-icon-template-stateless--right left-icon spectrum-hack-rotate-icon" style="transform: rotate(180deg);"><path d="M10.414 7.05l4.95 4.95-4.95 4.95L9 15.534 12.536 12 9 8.464z" fill="#637282" fill-rule="evenodd"></path></svg></a>
  <h3 class="title_section">Perfil del usuario</h3>
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section c_green">Premium</a></li>
			<li class="list_"><a href="#" class="link_section">reservas</a></li>
			<li class="list_"><a href="signin.html" class="link_section button_ b_green btn_option_user">Mi perfil</a>
				    <div class="sub_options_ sub_user">
                <div class="list_option">
                    <a href="/centerdoggy/profile/view/<?php echo $_SESSION['id_user']; ?>/" class="link_">Mis perfil</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/my_pets/" class="link_">Mis mascotas</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Configuraciones</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/signout/close_sesion/<?php echo $_SESSION['id_user']; ?>/" class="link_">Salir</a>
                </div>
            </div>
			</li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_">
    <div class="container_info_profile">
      <div class="container_center_">
        <div class="container_info_lender_current" style="margin-top: 10px; width: 75%;">
                <div class="container_division_info_user">
                  <div class="panel_left">
                    <div class="container_image"><img src="http://localhost:8089/centerdoggy/Views/<?php echo $this->get_info_owner()['picture']; ?>" alt="" class="image_user"></div>
                  </div>
                  <div class="panel_right">
                    <a href="#" class="direction_profile name_user"><?php echo $this->get_info_lenders()["name_lender"]; ?></a>
                    <p class="short_description_user" style="margin-bottom: 10px;">Este prestador es apasionado y ama lo que hace, por eso te lo recomendamos para los serviciós</p>
                    </div>
                  </div>
            </div>
         <div class="panel_body">
          <div class="container_form form_white" style="margin-top:0px; height:620px;">
             <form action="/centerdoggy/profile/edit_lender/" class="form_ form_rgone form_view_info_user">
               <h2 class="title_" style="position:relative;top:-85px; color:#41BB5F; font-family: 'Poppins Bold'; left:25px;" >Informacion breve</h2>
                <div class="division_fields" style="top:-30px;">
                   <div class="input_group" style="">
                       <input type="text" name="name_us" id="" class="textfield name_us" value="<?php echo $this->get_info_lenders()["name_lender"]; ?>">
                       <label for="name_complete" class="lb_info">Nombres y Apellidos</label>
                   </div>
                    <div class="input_group" style="">
                       <input type="text" name="sex_us" id="number_phone" class="textfield" value="<?php echo $this->get_info_lenders()["sexo"]; ?>">
                       <label for="number_phone" class="lb_info">Sexo</label>
                   </div>
                </div>

                <div class="division_fields" style="top:-30px;">
                   <div class="input_group" style="">
                     <input type="text" name="email_us" id="email_" class="textfield email_us" value="<?php echo $this->get_info_lenders()["email"]; ?>">
                       <label for="email_" class="lb_info">Correo electronico</label>
                   </div>
                   <div class="input_group">
                         <input type="text" name="city_us" id="code_indentify" class="textfield city_us" value="<?php echo $this->get_info_lenders()["city_lender"]; ?>">
                         <label for="code_indentify" class="lb_info">Ciudad</label>
                     </div>
                  </div>
                <div class="division_fields" style="top:-30px;">
                   <div class="input_group" style="">
                       <input type="text" name="neit_us" id="" class="textfield neit_us" value="<?php echo $this->get_info_lenders()["neit_lender"]; ?>">
                       <label for="name_complete" class="lb_info">Barrio de influencia</label>
                   </div>
                   <div class="input_group">
                     <input type="text" name="phone_us" id="number_phone" class="textfield phone_us" value="<?php echo $this->get_info_owner()["phone_"]; ?>">
                     <label for="number_phone" class="lb_info">Telefono Celular</label>
                 </div>

                </div>
                <div class="input_button input_mhistory" style="margin-top:-10px; margin-bottom: 0px; top:-55px; float: right; right: 30px;z-index: 200;">
                     <a href="/centerdoggy/profile/view_horario/" class="button_ b_wgreen btn_ch">Horario laboral</a>
                 </div>
                <div class="division_fields" style="justify-content: start; top:-110px;">
                  <div class="input_button" style="left:10px;">
                     <button type="submit" class="button_ b_green btn_edit_">Editar información</button>
                   </div>
                </div>
             </form>
             <div class="form_loader">
                 <div class="container_loader" style="top:60px;">
                     <div class="bar_loader">
                       <div class="loader"></div>
                         <img src="img/padlock.svg" alt="">
                     </div>
                     <p class="info_">cargando la informacion ...</p>
                 </div>
             </div>
         </div>
         </div>
      </div>
       
     </div>
  </div>
  <script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
  <script>
    document.querySelector('.btn_option_user').addEventListener("click", function(e){
      e.preventDefault();
      $('.sub_user').toggle();
    });
    var form = document.querySelector('.form_view_info_user'),
        childs = form.elements;

     function validarInputs(){
      let decision = false;

        for(let i = 0; i < childs.length; i++){
            if(childs[i].type == "text"){
              if(childs[i].value.length == 0){
                decision = false;
                return false;
              }else{
                decision = true;
              }
            }
        }


        return decision;
     }   
     function id_vet(){
        let url = window.location.href;
        let index = url.split('/');
        if(index.length >= 8){
          return index[6];
        }
       
     }  
    document.querySelector('.btn_edit_').addEventListener("click", e=>{
      e.preventDefault();
      const URL = form.getAttribute("action");
      let data = new FormData($('.form_view_info_user')[0]);
      data.append('id_user',id_vet());
      console.log(data.get("code_us"));

      if(validarInputs()){

         $.ajax({
            url:URL,
            type:"POST",
            data:data,
            processData:false,
            cache:false,
            contentType: false,
            beforeSend: function(){

            },
            complete: function(){

            },

            success: function(response){
              console.log(response);
            }
         }) 
      }else{
        console.log("campos incompletos...");
      }
    });
  </script>
</body>
</html>