<?php namespace Models;


class Connection{

	private $host = "localhost;";
	private $user = "root";
	private $pass = "";
	private $database = "doggy_center_db";
	private $connect;


	public function __construct(){


		$this->connect = new \PDO("mysql:host=".$this->host."dbname=".$this->database,$this->user,$this->pass);

	}


	public function prepare($sql){
		if($this->connect){
			$data = $this->connect->prepare($sql);
			return $data;	
		}
		
	}

	public function proteccion($text){
		if($this->connect){
			$string = $this->connect->quote($text);
			return $string;
		}
	}


} 



 ?>