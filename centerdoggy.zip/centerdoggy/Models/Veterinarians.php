<?php namespace Models;



class Veterinarians{

	private $conexion;

	//Attributes
	private $id_vet;
	private $codigo;
	private $nombre;
	private $genero;
	private $telefono;
	private $direccion;
	private $email;
	private $password;
	private $ciudad;
	private $barrio;
	private $comentarios;
	private $picture;

	#Method construct
	public function  __construct(){
		$this->conexion = new Connection();
	}


	public function set($attr,$value){
		$this->$attr = $value;
	}

	public function get($attr){
		return $this->$attr;
	}


	public function add(){

		$sql = 'INSERT INTO veterinarians VALUES(NULL,:code,:name,:sex,:phone,:address,:email,:password,:city,:neit,:com,:picture)';

		$stmt = $this->conexion->prepare($sql);
		$stmt->bindParam(':code',$this->codigo,\PDO::PARAM_INT);
		$stmt->bindParam(':name',$this->nombre,\PDO::PARAM_STR);
		$stmt->bindParam(':sex',$this->genero,\PDO::PARAM_STR);
		$stmt->bindParam(':phone',$this->telefono,\PDO::PARAM_INT);
		$stmt->bindParam(':address',$this->direccion,\PDO::PARAM_STR);
		$stmt->bindParam(':email',$this->email,\PDO::PARAM_STR);
		$stmt->bindParam(':password',$this->password,\PDO::PARAM_STR);
		$stmt->bindParam(':city',$this->ciudad,\PDO::PARAM_STR);
		$stmt->bindParam(':neit',$this->barrio,\PDO::PARAM_STR);
		$stmt->bindParam(':com',$this->comentarios,\PDO::PARAM_STR);
		$stmt->bindParam(':picture',$this->picture,\PDO::PARAM_STR);
		$stmt->execute();

		return $stmt;
	}

	public function list(){

		$sql = 'SELECT * FROM veterinarians';
		$stmt = $this->conexion->prepare($sql);
		$stmt->execute();

		return $stmt;
	}


	public function list_for_id(){

		$sql = 'SELECT * FROM veterinarians WHERE id_vet =:id';
		$stmt = $this->conexion->prepare($sql);
		$stmt->bindParam(':id',$this->id_vet,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
	}


	public function search_for_name(){

		$sql = 'SELECT vet.id_vet,vet.nombre_completo FROM veterinarians vet WHERE vet.nombre_completo LIKE :name';
		$stmt = $this->conexion->prepare($sql);
		$filter = '%'.$this->nombre.'%';
		$stmt->bindParam(':name',$filter,\PDO::PARAM_STR);
		$stmt->execute();

		return $stmt;
	}	

	public function edit_info(){
		$sql = 'UPDATE veterinarians SET nombre_completo =:name,genero=:sex,email=:email,ciudad=:city,barrio=:neit,telefono=:phone WHERE id_vet =:id';
		$stmt = $this->conexion->prepare($sql);
		$stmt->bindParam(':id',$this->id_vet,\PDO::PARAM_INT);
		$stmt->bindParam(':name',$this->nombre,\PDO::PARAM_STR);	
		$stmt->bindParam(':sex',$this->genero,\PDO::PARAM_STR);
		$stmt->bindParam(':email',$this->email,\PDO::PARAM_STR);
		$stmt->bindParam(':city',$this->ciudad,\PDO::PARAM_STR);
		$stmt->bindParam(':neit',$this->barrio,\PDO::PARAM_STR);
		$stmt->bindParam(':phone',$this->telefono,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;

	}


	public function delete(){
		$sql = 'DELETE FROM veterinarians WHERE id_vet =:id';
		$stmt = $this->conexion->prepare($sql);
		$stmt->bindParam(':id',$this->id_vet,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
	}
}


 ?>