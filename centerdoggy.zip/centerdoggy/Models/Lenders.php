<?php namespace Models;

class Lenders{
	


	private $id;
	private $code;
	private $name;
	private $sex;
	private $email;
	private $password;
	private $city_lender;
	private $neit_lender;
	private $phone;
	private $picture;
	private $status;
	private $rol;
	private $type_user;
	private $state;

	private $conn;

	public function __construct(){
		$this->conn = new Connection();
	}

	public function set($attr,$value){
		$this->$attr = $value;
	}


	public function get($attr){
		return $this->$attr;
	}

	

	public function list($param){

		$stmt = "";

		if($param == "nothing"){
			$sql = 'SELECT * FROM lenders';
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();

		}else{
			$sql = 'SELECT * FROM lenders WHERE id_lender =:id';
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':id',$this->id,\PDO::PARAM_INT);
			$stmt->execute();
		}
		
		return $stmt;
	}


	public function listcode($param){

		$sql = 'SELECT * FROM lenders WHERE code_lender =:code';
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':code',$param,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt->fetch();

	}


	public function add(){

		$sql = 'INSERT INTO lenders VALUES(NULL,:code,:name_lender,:sex,:email,:password,:city_lender,:neit_lender,:phone,:picture,:status,:Cuidador,:Paseador,:Grooming,:type_user,:state)';

		
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':code',$this->code,\PDO::PARAM_STR);
		$stmt->bindParam(':name_lender',$this->name,\PDO::PARAM_STR);
		$stmt->bindParam(':sex',$this->sex,\PDO::PARAM_STR);
		$stmt->bindParam(':email',$this->email,\PDO::PARAM_STR);
		$stmt->bindParam(':password',$this->password,\PDO::PARAM_STR);
		$stmt->bindParam(':city_lender',$this->city_lender,\PDO::PARAM_STR);
		$stmt->bindParam(':neit_lender',$this->neit_lender,\PDO::PARAM_STR);
		$stmt->bindParam(':phone',$this->phone,\PDO::PARAM_INT);
		$stmt->bindParam(':picture',$this->picture,\PDO::PARAM_STR);
		$stmt->bindParam(':status',$this->status,\PDO::PARAM_STR);
		$stmt->bindParam(':Cuidador',$this->rol["Cuidador"],\PDO::PARAM_INT);
		$stmt->bindParam(':Paseador',$this->rol["Paseador"],\PDO::PARAM_INT);
		$stmt->bindParam(':Grooming',$this->rol["Grooming"],\PDO::PARAM_INT);
		$stmt->bindParam(':type_user',$this->type_user,\PDO::PARAM_INT);
		$stmt->bindParam(':state',$this->state,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
	}

	public function edit(){

		$sql = 'UPDATE FROM lenders SET name_lender =:name WHERE id_lender =:id';
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':name_owner',$this->name,\PDO::PARAM_STR);
		$stmt->bindParam(':id_owner',$this->id,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;

	}

	public function delete(){
		$sql = 'DELETE FROM lenders WHERE id_lender =:id';
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':id',$this->id,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
		
	}


	public function all_user_service($param){
		$stmt  = "";
		if($param == "paseador"){
			$sql = 'SELECT * FROM lenders 	WHERE  Paseador =:dos ';
			$stmt = $this->conn->prepare($sql);
			$dos = 2;
			$stmt->bindParam(':dos',$dos,\PDO::PARAM_INT);
			$stmt->execute();
					
		}else if($param == "cuidador"){
			$sql = 'SELECT * FROM lenders 	WHERE  Cuidador =:uno ';
			$stmt = $this->conn->prepare($sql);
			$uno = 1;
			
			$stmt->bindParam(':uno',$uno,\PDO::PARAM_INT);
			$stmt->execute();
		}else if($param == "grooming"){
			
			$sql = 'SELECT * FROM lenders 	WHERE  Grooming =:tres ';
			$stmt = $this->conn->prepare($sql);
			$tres = 3;
			$stmt->bindParam(':tres',$tres,\PDO::PARAM_INT);
			$stmt->execute();
		}

		return $stmt;
	}


	public function getschedule_lender(){
		$sql = "SELECT  scs.weekdays as day_week,scs.id_months FROM lenders ls INNER JOIN schedule_users scs ON ls.id_lender = scs.id_user WHERE ls.id_lender =:id";
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':id',$this->id,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
	}


	public function day_disabled(){

		$sql = 'SELECT sle.day as day,sle.id_months as month,sle.star_time,sle.end_time FROM `service_schedule` sle INNER JOIN lenders ls ON sle.id_lender = ls.id_lender WHERE ls.id_lender = 1';
		$stmt = $this->conn->prepare($sql);
		$stmt->execute();

		return $stmt;

	}

	public function update_lenders(){
		$sql = 'UPDATE lenders SET code_lender =:code,name_lender =:name,sexo =:sex,email =:email,city_lender =:city,neit_lender =:neit,phone_ =:phone_ WHERE id_lender =:id';
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':code',$this->code,\PDO::PARAM_INT);
		$stmt->bindParam(':name',$this->name,\PDO::PARAM_STR);
		$stmt->bindParam(':sex',$this->sex,\PDO::PARAM_STR);
		$stmt->bindParam(':email',$this->email,\PDO::PARAM_STR);
		$stmt->bindParam(':city',$this->city_lender,\PDO::PARAM_STR);
		$stmt->bindParam(':neit',$this->neit_lender,\PDO::PARAM_STR);
		$stmt->bindParam(':phone_',$this->phone,\PDO::PARAM_INT);
		$stmt->bindParam(':id',$this->id,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
	}



	
}

 ?>