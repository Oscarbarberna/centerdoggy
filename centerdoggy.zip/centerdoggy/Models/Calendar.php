<?php namespace Models;


use Models\Calendar as Calendar;

class Calendar{

	private $id_schedule;
	private $id_user;
	private $id_weekdays;
	private $id_month;
	private $start_time;
	private $end_time;
	private $day;
	private $date_create;
	private $date_update;
	private $id_pet;
	private $id_service;
	private $con_;

	public function __construct(){
		$this->con_ = new Connection();
	}	


	public function set($attr,$value){
		$this->$attr = $value;
	}

	public function get($attr){
		return $this->$attr;
	}

	public function getweekday($days){
		$total_days = explode("-",$days);
		print_r(array_filter($total_days));
	}


	public function getMonth($month){
		switch ($month) {
			case 'Enero':
				return 1;
				break;
			case 'Febrero':
				return 2;
				break;
			case 'Marzo':
				return 3;
				break;
			case 'Abril':
				return 4;
				break;
			case 'Mayo':
				return 5;
				break;
			case 'Junio':
				return 6;
				break;
			case 'Enero':
				return 7;
				break;
			case 'Julio':
				return 8;
				break;
			case 'Agosto':
				return 9;
				break;
			case 'Septiembre':
				return 10;
				break;
			case 'Noviembre':
				return 11;
				break;
			case 'Diciembre':
				return 12;
				break;										
			default:
				return 1;
				break;
		}
	}


	public function addDays(){

		$sql = 'INSERT INTO days_ VALUES(NULL,:id_lender,:id_weekdays,:day_status)';
		$stmt = $this->con_->prepare($sql);
		$dstatus = 1;

		foreach ($this->id_weekdays as $value){
			$stmt->bindParam(':id_lender',$this->id_user,\PDO::PARAM_INT);
			$stmt->bindParam(':id_weekdays',$value,\PDO::PARAM_INT);
			$stmt->bindParam(':day_status',$dstatus,\PDO::PARAM_INT);
			$stmt->execute();	
		}
		

		return $stmt;
	}

	public function get_total_work_hours(){
		$sql = 'SELECT * FROM hours';
		$stmt = $this->con_->prepare($sql);
		$stmt->execute();
		return $stmt;
	}

	public function getIdDays($id_user){
		$sql = 'SELECT d.id_day FROM days_ d INNER JOIN lenders ln ON ln.id_lender = d.id_lender';
		$stmt = $this->con_->prepare($sql);
		$stmt->bindParam(':id_lender',$id_user,\PDO::PARAM_INT);
		$stmt->execute();
		return json_encode($stmt->fetchAll(\PDO::FETCH_ASSOC));
	}

	public function list_days_work_lender(){
		$sql = 'SELECT d.id_day,ws.name_weekday FROM days_ d INNER JOIN lenders ls ON d.id_lender = ls.id_lender INNER JOIN weekdays ws ON d.id_weekdays = ws.id_weekday WHERE ls.id_lender =:id AND d.day_status = 1';
		$stmt = $this->con_->prepare($sql);
		$stmt->bindParam(':id',$this->id_user,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
	}


	public function update_state_day($IdDay){

		$sql = 'UPDATE days_ SET day_status =:status WHERE id_day =:id_day';
		$newstate = 2;
		$stmt = $this->con_->prepare($sql);
		$stmt->bindParam(':status',$newstate);
		$stmt->bindParam(':id_day',$IdDay);
		$stmt->execute();

		return $stmt;

	}
	
	public function addslender(){

		$sql = 'INSERT INTO schedule_users VALUES(NULL,:id_days,:id_month,:id_hour,:date_create,:available)';
		$stmt = $this->con_->prepare($sql);
		$month_ = $this->getMonth($this->id_month);
		$status = 'y';
		//print_r($this->start_time);
		if($this->update_state_day($this->id_weekdays)){
			for ($i = $this->start_time[0]; $i <= $this->start_time[1]; $i++) {
				 $stmt->bindParam(':id_days',$this->id_weekdays,\PDO::PARAM_INT);
				 $stmt->bindParam(':id_month',$this->id_month,\PDO::PARAM_INT);
				 $stmt->bindParam(':id_hour',$i,\PDO::PARAM_INT);
			     $stmt->bindParam(':date_create',$this->date_create,\PDO::PARAM_STR);
			     $stmt->bindParam(':available',$status,\PDO::PARAM_STR);
			     $stmt->execute();
		     //echo $i; 
			}	
		}
		
		// $stmt->bindParam(':id_days',$this->id_weekdays,\PDO::PARAM_INT);
		// $stmt->bindParam(':id_month',$this->id_month,\PDO::PARAM_INT);
		// $stmt->bindParam(':id_hour',$this->start_time,\PDO::PARAM_INT);
		// $stmt->bindParam(':date_create',$this->date_create,\PDO::PARAM_STR);
		// $stmt->bindParam(':available',$status,\PDO::PARAM_STR);
		// $stmt->execute();
		
		
		
		return $stmt;

	}


	public function getschedule_hours_days_available(){
		$sql = 'SELECT sc.id_schedule,sc.id_months,sc.id_days,ds.id_weekdays,ls.name_lender,ls.id_lender,h.range_time FROM schedule_users sc INNER JOIN days_ ds ON sc.id_days = ds.id_day INNER JOIN lenders ls ON ds.id_lender = ls.id_lender INNER JOIN hours h ON sc.id_hour = h.id_hour WHERE sc.id_months =:month AND ds.id_weekdays =:day AND ls.id_lender =:lender AND sc.available = "y"';
		$stmt = $this->con_->prepare($sql);
		$stmt->bindParam(':month',$this->id_month,\PDO::PARAM_INT);
		$stmt->bindParam(':day',$this->id_weekdays,\PDO::PARAM_INT);
		$stmt->bindParam(':lender',$this->id_user,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
	}

	public function add_schedule_service(){
		$sql_init = 'UPDATE schedule_users SET available =:status WHERE id_schedule =:id_sc';
		$stmt_ = $this->con_->prepare($sql_init);
		$new_state = 'n';
		$stmt_->bindParam(':status',$new_state,\PDO::PARAM_STR);
		$stmt_->bindParam(':id_sc',$this->id_user,\PDO::PARAM_INT);
		$stmt_->execute();

		if($stmt_){
			if($stmt_->rowcount() > 0){
				$sql = 'INSERT INTO service_schedule VALUES(NULL,:id_pet,:day_service,:id_suser,:id_service,:date_c,:date_up)';
				$stmt = $this->con_->prepare($sql);
				$stmt->bindParam(':id_pet',$this->id_pet,\PDO::PARAM_INT);
				$stmt->bindParam(':day_service',$this->day,\PDO::PARAM_INT);
				$stmt->bindParam(':id_suser',$this->id_user,\PDO::PARAM_INT);
				$stmt->bindParam(':id_service',$this->id_service,\PDO::PARAM_INT);
				$stmt->bindParam(':date_c',$this->date_create,\PDO::PARAM_STR);
				$stmt->bindParam(':date_up',$this->date_update,\PDO::PARAM_STR);
				$stmt->execute();

				return $stmt;

			}else{
				return false;
			}
		}
		

	}


	public function list_request_service(){

		$sql = 'SELECT os.name_owner,p.name_pet,sc.day_service,ls.name_lender FROM service_schedule sc INNER JOIN pets p ON p.id_pet = sc.id_pet INNER JOIN owners os ON p.id_owner = os.id_owner INNER JOIN schedule_users scu ON sc.id_schedule_user = scu.id_schedule INNER JOIN days_ ds ON scu.id_days = ds.id_day INNER JOIN lenders ls ON ds.id_lender = ls.id_lender WHERE ls.id_lender =:id_user AND sc.id_service_ =:id_service_';

		$stmt = $this->con_->prepare($sql);
		$stmt->bindParam(':id_user',$this->id_user,\PDO::PARAM_INT);
		$stmt->bindParam(':id_service_',$this->id_service,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;


	}



	public function get_horario_user(){
		$sql = 'SELECT days.id_lender,wdays.name_weekday,h.range_time FROM days_ days INNER JOIN schedule_users susers ON susers.id_days = days.id_day INNER JOIN hours h ON h.id_hour = susers.id_hour INNER JOIN weekdays wdays ON wdays.id_weekday = days.id_weekdays WHERE days.id_lender =:user AND days.id_weekdays =:day';
		$stmt = $this->con_->prepare($sql);
		$stmt->bindParam(':user',$this->id_user,\PDO::PARAM_INT);
		$stmt->bindParam(':day',$this->day,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
	}


	public function load_info(){

		// $data = [array('id' => 1,'title' => 'Cita paseador' , 'date_start' => '2019-02-27T13:13:55.008','date_end' => '2019-02-28T13:13:55.008','result' => true),array('id' => 1,'title' => 'Cita prestador' , 'date_start' => '2019-02-25T13:13:55.008','date_end' => '2019-02-26T13:13:55.008','result' => true)];

		// echo json_encode($data);

		$sql = 'SELECT * FROM tabla_eventos';
		$stmt = $this->con_->prepare($sql);
		$stmt->execute();


		return $stmt;
	}



}




 ?>