<?php namespace Models;

class Owners{
	


	private $id;
	private $name;
	private $sex;
	private $email;
	private $password;
	private $city_owner;
	private $neit_owner;
	private $phone;
	private $picture;
	private $status;
	private $type_user;

	private $conn;

	public function __construct(){
		$this->conn = new Connection();
	}

	public function set($attr,$value){
		$this->$attr = $value;
	}


	public function get($attr){
		return $this->$attr;
	}

	

	public function list($param){

		$stmt = "";

		if($param == "nothing"){
			$sql = 'SELECT * FROM owners';
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();

		}else{
			$sql = 'SELECT * FROM owners WHERE id_owner =:id';
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':id',$param,\PDO::PARAMT_INT);
			$stmt->execute();
		}
		
		return $stmt;
	}


	public function add(){

		$sql = 'INSERT INTO owners VALUES(NULL,:name_owner,:sex,:email,:password,:city_owner,:neit_owner,:phone,:picture,:status,:type_user)';
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':name_owner',$this->name,\PDO::PARAM_STR);
		$stmt->bindParam(':sex',$this->sex,\PDO::PARAM_STR);
		$stmt->bindParam(':email',$this->email,\PDO::PARAM_STR);
		$stmt->bindParam(':password',$this->password,\PDO::PARAM_STR);
		$stmt->bindParam(':city_owner',$this->city_owner,\PDO::PARAM_STR);
		$stmt->bindParam(':neit_owner',$this->neit_owner,\PDO::PARAM_STR);
		$stmt->bindParam(':phone',$this->phone,\PDO::PARAM_INT);
		$stmt->bindParam(':status',$this->status,\PDO::PARAM_STR);
		$stmt->bindParam(':picture',$this->picture,\PDO::PARAM_STR);
		$stmt->bindParam(':type_user',$this->type_user,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
	}

	public function edit(){

		$sql = 'UPDATE FROM owners SET name_owner =:name WHERE id_owner =:id';
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':name_owner',$this->name,\PDO::PARAMT_STR);
		$stmt->bindParam(':id_owner',$this->id,\PDO::PARAMT_INT);
		$stmt->execute();

		return $stmt;

	}

	public function delete(){
		$sql = 'DELETE FROM owners WHERE id_owner =:id';
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':id',$this->id,\PDO::PARAMT_INT);
		$stmt->execute();

		return $stmt;
		
	}


	public function update_owners(){
		$sql = 'UPDATE owners SET name_owner =:name,sexo =:sex,email =:email,city_owner =:city,neit_owner =:neit,phone_ =:phone_ WHERE id_owner =:id';
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':name',$this->name,\PDO::PARAM_STR);
		$stmt->bindParam(':sex',$this->sex,\PDO::PARAM_STR);
		$stmt->bindParam(':email',$this->email,\PDO::PARAM_STR);
		$stmt->bindParam(':city',$this->city_owner,\PDO::PARAM_STR);
		$stmt->bindParam(':neit',$this->neit_owner,\PDO::PARAM_STR);
		$stmt->bindParam(':phone_',$this->phone,\PDO::PARAM_INT);
		$stmt->bindParam(':id',$this->id,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
	}



	
}

 ?>